# BorrowBond

Peer-to-peer **borrowing** (not money lending) of physical items and digital resources: a rental fee plus refundable collateral held in escrow on **NEAR testnet**.

> **Prototype status.** Unaudited NEAR **testnet** prototype for NEAR Hackathon 2026. It runs in **simulated mode** by default (no blockchain, no funds) and every simulated booking is labelled as such. The Rust contract in `contracts/borrowbond` has **not** been deployed by this repository, and the web app does **not** yet send transactions to it. Never use it with real value.

## Run

```bash
npm install
cp .env.example .env       # then fill in SESSION_SECRET (see below). Never commit .env.
npm run dev                # http://localhost:3000
npm test                   # 23 tests: state machine, identity, API
npm run lint && npm run build
```

`SESSION_SECRET` (32+ random chars) signs login cookies. Generate: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`. In development without it a random per-process secret is used (logins reset on restart); production refuses to start without it.

## Sign-in (changed in this version)

Identity now comes from a signed, HttpOnly cookie issued by the **server**, never from a wallet name sent by the browser.

- **Real wallet:** NEP-413 message signature from the user's NEAR testnet wallet (`@hot-labs/near-connect`), verified on the server, plus an on-chain check that the signing key belongs to the account. A connected wallet proves control of an account, not real-world identity.
- **Demo personas:** four labelled, simulated accounts (borrower, two providers, resolver) for walking through every role without a wallet. Disable with `DEMO_MODE=false`.
- Spending policies are per account. New accounts start with zero history (nothing is invented).

## What was verified

- `npm test`: 23 tests pass (8 original state-machine/AI tests, 5 identity/NEP-413 tests, 10 API tests against the running server: anonymous access, forged/tampered cookies, body-identity ignored, cross-origin blocked, per-account policy, no downloadable project zip).
- `tsc`, and `vite build` pass. UI checked with screenshots at desktop and 390 px mobile.

## NOT verified / not built yet

- **No deployed contract and no on-chain transactions from the UI.** Checkout creates simulated bookings. Wiring `signAndSendTransaction` to a deployed contract, and re-reading chain state on the server, is the main remaining work.
- The real-wallet sign-in path is untested against a live wallet and RPC (only its cryptography and failure paths are tested).
- The Rust contract has no unit tests in this repo.
- Gemini integration is untested live; the rules-based agent is what the tests cover.
- State is in memory and resets on restart. The Supabase schema is a reference, not wired in.
- Email and Google sign-in were removed (they were not real identity). Only wallet and demo personas remain.

## Limitations

A single human resolver decides disputes; no appeals or timeout recovery. Item values are owner-estimated. NEAR/USD price is shown only as "est." when no live feed is reachable.
