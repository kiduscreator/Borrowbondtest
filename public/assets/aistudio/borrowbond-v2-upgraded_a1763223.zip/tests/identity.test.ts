import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import bs58 from 'bs58';
process.env.SESSION_SECRET = 'unit-test-secret-0123456789abcdef0123456789abcdef';
const id = await import('../server/identity');

function wallet() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  const raw = publicKey.export({ format: 'der', type: 'spki' }).subarray(-32);
  return { privateKey, pk: 'ed25519:' + bs58.encode(raw) };
}

test('sessions round-trip, reject tampering and expiry', () => {
  const t = id.createSessionToken({ account: 'a.testnet', kind: 'demo' }, 1000);
  assert.deepEqual(id.readSessionToken(t, 1001), { account: 'a.testnet', kind: 'demo' });
  assert.equal(id.readSessionToken(t, 1000 + id.SESSION_TTL_SECONDS + 1), null);
  const [body, mac] = t.split('.');
  const forged = Buffer.from(JSON.stringify({ a: 'resolver.borrowbond.testnet', k: 'wallet', exp: 9e9 })).toString('base64url');
  assert.equal(id.readSessionToken(`${forged}.${mac}`, 1001), null);
  assert.equal(id.readSessionToken(`${body}.deadbeef`, 1001), null);
  assert.equal(id.readSessionToken(undefined), null);
});

test('NEP-413: valid signature verifies; wrong message, nonce or key fails', () => {
  const w = wallet();
  const ch = id.createChallenge();
  const payload = { message: ch.message, nonce: Buffer.from(ch.nonceB64, 'base64'), recipient: ch.recipient };
  const sig = crypto.sign(null, id.nep413Hash(payload), w.privateKey).toString('base64');
  assert.equal(id.verifyNep413(payload, w.pk, sig), true);
  assert.equal(id.verifyNep413({ ...payload, message: 'other' }, w.pk, sig), false);
  assert.equal(id.verifyNep413({ ...payload, nonce: crypto.randomBytes(32) }, w.pk, sig), false);
  assert.equal(id.verifyNep413(payload, wallet().pk, sig), false);
  assert.equal(id.verifyNep413(payload, w.pk, Buffer.alloc(64).toString('base64')), false);
  assert.equal(id.verifyNep413(payload, 'secp256k1:xyz', sig), false);
});

test('challenges expire and cannot be forged', () => {
  const c = id.createChallenge(1000);
  assert.ok(id.readChallenge(c.token, 1100));
  assert.equal(id.readChallenge(c.token, 1000 + 301), null);
  assert.equal(id.readChallenge('x.y', 1100), null);
});

test('only testnet account ids are accepted', () => {
  for (const ok of ['alice.testnet', 'a-b.c_d.testnet']) assert.ok(id.TESTNET_ACCOUNT_RE.test(ok), ok);
  for (const bad of ['alice.near', 'alice', '.testnet', 'A.testnet', 'a b.testnet', 'x'.repeat(70) + '.testnet']) assert.ok(!id.TESTNET_ACCOUNT_RE.test(bad), bad);
});

test('access-key check trusts only a positive RPC answer', async () => {
  const ok = (async () => new Response(JSON.stringify({ result: { nonce: 1 } }))) as unknown as typeof fetch;
  const nokey = (async () => new Response(JSON.stringify({ error: { name: 'x' } }))) as unknown as typeof fetch;
  const nokey2 = (async () => new Response(JSON.stringify({ result: { error: 'UNKNOWN_ACCESS_KEY' } }))) as unknown as typeof fetch;
  assert.equal(await id.hasAccessKey('a.testnet', 'ed25519:x', ok), true);
  assert.equal(await id.hasAccessKey('a.testnet', 'ed25519:x', nokey), false);
  assert.equal(await id.hasAccessKey('a.testnet', 'ed25519:x', nokey2), false);
});

test('degenerate all-zero public keys are rejected outright', () => {
  const ch = id.createChallenge();
  const payload = { message: ch.message, nonce: Buffer.from(ch.nonceB64, 'base64'), recipient: ch.recipient };
  assert.equal(id.verifyNep413(payload, 'ed25519:' + bs58.encode(Buffer.alloc(32)), Buffer.alloc(64).toString('base64')), false);
});
