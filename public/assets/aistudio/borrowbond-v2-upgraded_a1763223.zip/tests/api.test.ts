import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import bs58 from 'bs58';
import { spawn, type ChildProcess } from 'node:child_process';

const PORT = 3111;
const BASE = `http://127.0.0.1:${PORT}`;
let child: ChildProcess;

before(async () => {
  child = spawn('npx', ['tsx', 'server.ts'], {
    env: { ...process.env, PORT: String(PORT), NODE_ENV: 'production', SESSION_SECRET: 'api-test-secret-0123456789abcdef0123456789abcdef', DEMO_MODE: 'true', GEMINI_API_KEY: '' },
    stdio: 'ignore',
  });
  for (let i = 0; i < 60; i++) {
    try { if ((await fetch(`${BASE}/api/session`)).ok) return; } catch { /* not up yet */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error('server did not start');
});
after(() => { child?.kill(); });

async function login(account: string): Promise<string> {
  const r = await fetch(`${BASE}/api/session/demo`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ account }) });
  assert.equal(r.status, 200);
  return r.headers.get('set-cookie')!.split(';')[0];
}
const call = (method: string, path: string, cookie?: string, body?: unknown, extra: Record<string, string> = {}) =>
  fetch(`${BASE}${path}`, { method, headers: { 'content-type': 'application/json', ...(cookie ? { cookie } : {}), ...extra }, body: body ? JSON.stringify(body) : undefined });

test('anonymous callers cannot act', async () => {
  for (const [m, p] of [['POST', '/api/bookings/create'], ['POST', '/api/listings'], ['PUT', '/api/security/policy'], ['POST', '/api/agent/assist'], ['POST', '/api/escrow/withdraw'], ['POST', '/api/bookings/x/accept'], ['POST', '/api/bookings/x/resolve'], ['POST', '/api/user/profile'], ['POST', '/api/digital/issue-token']] as const) {
    assert.equal((await call(m, p, undefined, {})).status, 401, `${m} ${p}`);
  }
});

test('an identity in the request body is ignored; only the signed cookie counts', async () => {
  const alex = await login('alex-builder.testnet');
  // Alex claims to be the resolver in the body: still just Alex.
  const r = await call('POST', '/api/bookings/bk-demo-camera-102/resolve', alex, { callerWallet: 'resolver.borrowbond.testnet', damageDeductionNear: 0.05 });
  assert.equal(r.status, 400);
  assert.match((await r.json()).error, /Unauthorized|Only|resolve|DISPUTED/i);
});

test('forged or tampered cookies are rejected', async () => {
  const forged = Buffer.from(JSON.stringify({ a: 'resolver.borrowbond.testnet', k: 'wallet', exp: 9e9 })).toString('base64url');
  assert.equal((await call('POST', '/api/escrow/withdraw', `bb_session=${forged}.deadbeef`, {})).status, 401);
  const good = await login('alex-builder.testnet');
  const tampered = good.replace(/.$/, (c) => (c === 'a' ? 'b' : 'a'));
  assert.equal((await call('POST', '/api/escrow/withdraw', tampered, {})).status, 401);
});

test('unknown demo personas and cross-origin writes are refused', async () => {
  const bad = await call('POST', '/api/session/demo', undefined, { account: 'attacker.testnet' });
  assert.equal(bad.status, 400);
  const x = await call('POST', '/api/session/demo', undefined, { account: 'alex-builder.testnet' }, { origin: 'https://evil.example' });
  assert.equal(x.status, 403);
});

test('wallet sign-in refuses non-testnet ids, bad signatures and expired challenges', async () => {
  const ch = await (await call('POST', '/api/auth/wallet/challenge')).json();
  assert.ok(ch.nonce && ch.token);
  const raw = crypto.generateKeyPairSync('ed25519').publicKey.export({ format: 'der', type: 'spki' }).subarray(-32);
  const body = { token: ch.token, accountId: 'victim.testnet', publicKey: 'ed25519:' + bs58.encode(raw), signature: crypto.randomBytes(64).toString('base64') };
  assert.equal((await call('POST', '/api/auth/wallet/verify', undefined, { ...body, accountId: 'victim.near' })).status, 400);
  assert.equal((await call('POST', '/api/auth/wallet/verify', undefined, body)).status, 401);
  assert.equal((await call('POST', '/api/auth/wallet/verify', undefined, { ...body, token: 'junk' })).status, 400);
});

test('state is public data plus ONLY the caller’s private data', async () => {
  const anon = await (await call('GET', '/api/state')).json();
  assert.deepEqual(anon.myDigitalCredentials, []);
  assert.deepEqual(anon.notifications.filter((n: { recipientWallet?: string }) => n.recipientWallet && n.recipientWallet !== 'all'), []);
  const alex = await login('alex-builder.testnet');
  const mine = await (await call('GET', '/api/state', alex)).json();
  assert.ok(mine.myDigitalCredentials.every((c: { borrowerWallet: string }) => c.borrowerWallet === 'alex-builder.testnet'));
  const other = await login('optics-lab.testnet');
  const theirs = await (await call('GET', '/api/state', other)).json();
  assert.ok(theirs.myDigitalCredentials.every((c: { borrowerWallet: string }) => c.borrowerWallet !== 'alex-builder.testnet'));
});

test('spending policy is per account and cannot be set by a stranger', async () => {
  const a = await login('alex-builder.testnet');
  const b = await login('optics-lab.testnet');
  assert.equal((await call('PUT', '/api/security/policy', a, { maxRentalFeeNear: 0.01 })).status, 200);
  const sa = await (await call('GET', '/api/state', a)).json();
  const sb = await (await call('GET', '/api/state', b)).json();
  assert.equal(sa.policy.maxRentalFeeNear, 0.01);
  assert.notEqual(sb.policy.maxRentalFeeNear, 0.01);
  assert.equal((await call('PUT', '/api/security/policy', a, { maxRentalFeeNear: -5 })).status, 400);
});

test('new accounts start with zero history, not invented reputation', async () => {
  const alex = await login('alex-builder.testnet');
  await call('POST', '/api/user/profile', alex, { displayName: 'Alex Builder' });
  const st = await (await call('GET', '/api/state', alex)).json();
  assert.ok(st.nearMarketPrice.live === true || st.nearMarketPrice.live === false);
  if (st.nearStatus.connected === false) assert.equal(st.nearStatus.latestBlockHeight, null);
});

test('the project zip is not downloadable', async () => {
  for (const p of ['/borrowbond-full-project.zip', '/api/export/borrowbond-folder.zip']) {
    const r = await fetch(`${BASE}${p}`);
    assert.ok(!(r.headers.get('content-type') ?? '').includes('zip'), p);
  }
});
