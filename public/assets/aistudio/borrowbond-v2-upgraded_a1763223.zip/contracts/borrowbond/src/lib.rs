// BorrowBond NEAR Programmable Escrow Smart Contract (near-sdk-rs v5)
// Target Account: borrowbondtest.testnet (Testnet) / borrowbond.near (Mainnet)
//
// Security & 24/7 Autonomous Guarantees:
// 1. Runs 24/7 on NEAR Protocol validators: Once deployed from Termux to `borrowbondtest.testnet`,
//    this contract executes on the NEAR blockchain forever—even when Termux is closed or your phone is off.
// 2. Checked 128-bit yoctoNEAR Arithmetic & Reentrancy Protection:
//    Balances are zeroed BEFORE any external `Promise::new(caller).transfer(...)` call.
// 3. Minimum Storage Reserve Guard (`MIN_STORAGE_RESERVE_YOCTO`):
//    Ensures withdrawals never drain the contract's NEAR state-storage staking reserve.
// 4. Emergency Circuit Breaker (`is_paused`):
//    Allows the owner/BorrowBond Team to pause new bookings in an emergency without freezing withdrawals.
// 5. Anti-Scam Product Identity Registry (`ProductIdentityRecord`):
//    Locks Brand & Model, TIN / Serial / IMEI / NFT Token ID, specs, and 2–10 photo SHA-256 hashes.
// 6. BorrowBond Team Damage-Deduction Arbitration (`resolve_dispute_with_damage_deduction`):
//    Deducts `rental_fee + capped_damage` for the Lender and automatically redirects the
//    remaining collateral (`collateral - capped_damage`) back to the Borrower's account.

use near_sdk::borsh::{BorshDeserialize, BorshSerialize};
use near_sdk::collections::UnorderedMap;
use near_sdk::serde::{Deserialize, Serialize};
use near_sdk::{
    env, near_bindgen, AccountId, BorshStorageKey, NearToken, PanicOnDefault, Promise,
};

/// 0.5 NEAR reserved on the contract account at all times to cover NEAR state storage staking
const MIN_STORAGE_RESERVE_YOCTO: u128 = 500_000_000_000_000_000_000_000;

#[derive(BorshSerialize, BorshStorageKey)]
#[borsh(crate = "near_sdk::borsh")]
pub enum StorageKey {
    Bookings,
    ClaimableBalances,
}

#[derive(BorshDeserialize, BorshSerialize, Serialize, Deserialize, Clone, PartialEq, Debug)]
#[serde(crate = "near_sdk::serde")]
#[borsh(crate = "near_sdk::borsh")]
pub enum ResourceType {
    PhysicalHardware,
    DigitalAccount,
    NftAsset,
    DigitalProduct,
    MeteredApi,
}

#[derive(BorshDeserialize, BorshSerialize, Serialize, Deserialize, Clone, PartialEq, Debug)]
#[serde(crate = "near_sdk::serde")]
#[borsh(crate = "near_sdk::borsh")]
pub enum BookingStatus {
    Requested,
    Accepted,
    Active,
    ReturnRequested,
    Completed,
    Cancelled,
    Expired,
    Disputed,
    Resolved,
}

#[derive(BorshDeserialize, BorshSerialize, Serialize, Deserialize, Clone, PartialEq, Debug)]
#[serde(crate = "near_sdk::serde")]
#[borsh(crate = "near_sdk::borsh")]
pub enum DisputeStatus {
    None,
    Open,
    Resolved,
}

/// Anti-scam product identity locked on BorrowBond so borrowers cannot swap a physical
/// item or digital asset/account/NFT with a different item upon return.
#[derive(BorshDeserialize, BorshSerialize, Serialize, Deserialize, Clone, Debug)]
#[serde(crate = "near_sdk::serde")]
#[borsh(crate = "near_sdk::borsh")]
pub struct ProductIdentityRecord {
    pub brand_and_model: String,
    pub tin_or_serial_number: String,
    pub spec_summary: String,
    pub photos_sha256_hash: String,
    pub return_verified_same_item: bool,
}

#[derive(BorshDeserialize, BorshSerialize, Serialize, Deserialize, Clone, Debug)]
#[serde(crate = "near_sdk::serde")]
#[borsh(crate = "near_sdk::borsh")]
pub struct SettlementInfo {
    pub rental_fee_paid_yocto: u128,
    pub damage_deduction_yocto: u128,
    pub lender_total_payout_yocto: u128,
    pub borrower_collateral_refund_yocto: u128,
    pub settled_at_ns: u64,
    pub resolved_by: AccountId,
    pub resolution_note: String,
}

#[derive(BorshDeserialize, BorshSerialize, Serialize, Deserialize, Clone, Debug)]
#[serde(crate = "near_sdk::serde")]
#[borsh(crate = "near_sdk::borsh")]
pub struct Booking {
    pub booking_id: String,
    pub listing_id: String,
    pub lender: AccountId,
    pub borrower: AccountId,
    pub resource_type: ResourceType,
    pub product_identity: ProductIdentityRecord,
    pub rental_fee_yocto: u128,
    pub collateral_yocto: u128,
    pub total_escrowed_yocto: u128,
    pub created_at_ns: u64,
    pub acceptance_deadline_ns: u64,
    pub rental_start_ns: u64,
    pub rental_end_ns: u64,
    pub status: BookingStatus,
    pub dispute_status: DisputeStatus,
    pub lender_handover_confirmed: bool,
    pub borrower_receipt_confirmed: bool,
    pub borrower_return_confirmed: bool,
    pub lender_safe_return_confirmed: bool,
    pub settlement: Option<SettlementInfo>,
}

#[near_bindgen]
#[derive(BorshDeserialize, BorshSerialize, PanicOnDefault)]
#[borsh(crate = "near_sdk::borsh")]
pub struct BorrowBondEscrow {
    pub owner: AccountId,
    pub borrowbond_team_agent: AccountId,
    pub is_paused: bool,
    pub total_locked_escrow_yocto: u128,
    pub bookings: UnorderedMap<String, Booking>,
    pub claimable_balances: UnorderedMap<AccountId, u128>,
}

#[near_bindgen]
impl BorrowBondEscrow {
    #[init]
    pub fn new(owner: AccountId, borrowbond_team_agent: AccountId) -> Self {
        assert!(!env::state_exists(), "Already initialized");
        Self {
            owner,
            borrowbond_team_agent,
            is_paused: false,
            total_locked_escrow_yocto: 0,
            bookings: UnorderedMap::new(StorageKey::Bookings),
            claimable_balances: UnorderedMap::new(StorageKey::ClaimableBalances),
        }
    }

    /// Emergency circuit breaker: owner or BorrowBond Team can pause new bookings if needed.
    /// Existing active bookings and withdrawals remain 100% accessible.
    pub fn set_paused(&mut self, paused: bool) {
        let caller = env::predecessor_account_id();
        assert!(
            caller == self.owner || caller == self.borrowbond_team_agent,
            "Only owner or BorrowBond Team Agent can toggle pause"
        );
        self.is_paused = paused;
    }

    /// Step 1: Borrower locks exact (rental_fee + collateral) in NEAR escrow.
    /// Stores the anti-scam product TIN/serial number, brand, specs, and photo hash.
    #[payable]
    #[allow(clippy::too_many_arguments)]
    pub fn create_booking(
        &mut self,
        booking_id: String,
        listing_id: String,
        lender: AccountId,
        resource_type: ResourceType,
        brand_and_model: String,
        tin_or_serial_number: String,
        spec_summary: String,
        photos_sha256_hash: String,
        rental_fee_yocto: u128,
        collateral_yocto: u128,
        acceptance_deadline_ns: u64,
        rental_start_ns: u64,
        rental_end_ns: u64,
    ) -> Booking {
        assert!(!self.is_paused, "Contract is temporarily paused for maintenance");
        assert!(
            self.bookings.get(&booking_id).is_none(),
            "Booking ID already exists"
        );
        assert!(
            !brand_and_model.trim().is_empty() && !tin_or_serial_number.trim().is_empty(),
            "Brand/Model and TIN/Serial/NFT ID are required for anti-scam protection"
        );

        let borrower = env::predecessor_account_id();
        assert_ne!(borrower, lender, "Borrower and lender must be distinct accounts");
        assert!(rental_fee_yocto > 0, "Rental fee must be positive");
        assert!(rental_end_ns > rental_start_ns, "Invalid rental deadline");

        let required_total = rental_fee_yocto
            .checked_add(collateral_yocto)
            .expect("Overflow computing total escrow");
        let attached = env::attached_deposit().as_yoctonear();
        assert_eq!(
            attached, required_total,
            "Attached deposit must equal exact rental_fee + collateral"
        );

        let now = env::block_timestamp();
        assert!(
            acceptance_deadline_ns > now,
            "Acceptance deadline must be in the future"
        );

        self.total_locked_escrow_yocto = self
            .total_locked_escrow_yocto
            .checked_add(required_total)
            .expect("Overflow updating total locked escrow");

        let booking = Booking {
            booking_id: booking_id.clone(),
            listing_id,
            lender,
            borrower,
            resource_type,
            product_identity: ProductIdentityRecord {
                brand_and_model,
                tin_or_serial_number,
                spec_summary,
                photos_sha256_hash,
                return_verified_same_item: false,
            },
            rental_fee_yocto,
            collateral_yocto,
            total_escrowed_yocto: required_total,
            created_at_ns: now,
            acceptance_deadline_ns,
            rental_start_ns,
            rental_end_ns,
            status: BookingStatus::Requested,
            dispute_status: DisputeStatus::None,
            lender_handover_confirmed: false,
            borrower_receipt_confirmed: false,
            borrower_return_confirmed: false,
            lender_safe_return_confirmed: false,
            settlement: None,
        };

        self.bookings.insert(&booking_id, &booking);
        booking
    }

    /// Step 2: Lender accepts the booking request.
    pub fn accept_booking(&mut self, booking_id: String) -> Booking {
        let mut booking = self.get_booking_or_panic(&booking_id);
        let caller = env::predecessor_account_id();
        assert_eq!(caller, booking.lender, "Only the lender can accept");
        assert_eq!(booking.status, BookingStatus::Requested, "Must be REQUESTED");

        booking.status = BookingStatus::Accepted;
        self.bookings.insert(&booking_id, &booking);
        booking
    }

    /// Step 3: Both Lender (handover) and Borrower (confirmed got the exact product/account/NFT)
    /// confirm handover. Once active, collateral & fee are locked until return or arbitration.
    pub fn confirm_handover(&mut self, booking_id: String) -> Booking {
        let mut booking = self.get_booking_or_panic(&booking_id);
        assert_eq!(booking.status, BookingStatus::Accepted, "Must be ACCEPTED");

        let caller = env::predecessor_account_id();
        if caller == booking.lender {
            booking.lender_handover_confirmed = true;
        } else if caller == booking.borrower {
            booking.borrower_receipt_confirmed = true;
        } else {
            env::panic_str("Only borrower or lender can confirm handover");
        }

        if booking.lender_handover_confirmed && booking.borrower_receipt_confirmed {
            booking.status = BookingStatus::Active;
        }

        self.bookings.insert(&booking_id, &booking);
        booking
    }

    /// Step 4: Borrower initiates return of the physical product or digital account/NFT.
    pub fn request_return(&mut self, booking_id: String) -> Booking {
        let mut booking = self.get_booking_or_panic(&booking_id);
        let caller = env::predecessor_account_id();
        assert_eq!(caller, booking.borrower, "Only borrower can initiate return");
        assert_eq!(booking.status, BookingStatus::Active, "Booking must be ACTIVE");

        booking.borrower_return_confirmed = true;
        booking.status = BookingStatus::ReturnRequested;
        self.bookings.insert(&booking_id, &booking);
        booking
    }

    /// Step 5: Lender confirms the exact product (matching TIN/Serial/Brand/NFT ID) was
    /// returned safely in good condition. Automatically releases Rental Fee to Lender
    /// and 100% of Collateral back to Borrower.
    pub fn confirm_satisfactory_return(
        &mut self,
        booking_id: String,
        verified_tin_or_serial: String,
    ) -> Booking {
        let mut booking = self.get_booking_or_panic(&booking_id);
        let caller = env::predecessor_account_id();
        assert_eq!(
            caller, booking.lender,
            "Only lender can confirm safe return after inspecting TIN/Serial & condition"
        );
        assert!(
            booking.status == BookingStatus::ReturnRequested
                || booking.status == BookingStatus::Active,
            "Booking must be ACTIVE or RETURN_REQUESTED"
        );
        assert_eq!(
            booking.dispute_status,
            DisputeStatus::None,
            "Cannot auto-release while disputed"
        );

        // Anti-swap verification: check that returned TIN/Serial matches locked registry
        if !booking.product_identity.tin_or_serial_number.is_empty() {
            assert_eq!(
                verified_tin_or_serial.trim(),
                booking.product_identity.tin_or_serial_number.trim(),
                "Returned item TIN/Serial does not match locked BorrowBond registry! Open a dispute."
            );
        }

        booking.product_identity.return_verified_same_item = true;
        booking.borrower_return_confirmed = true;
        booking.lender_safe_return_confirmed = true;

        let fee = booking.rental_fee_yocto;
        let collateral = booking.collateral_yocto;
        let locked = booking.total_escrowed_yocto;
        booking.total_escrowed_yocto = 0;
        booking.status = BookingStatus::Completed;

        self.total_locked_escrow_yocto = self.total_locked_escrow_yocto.saturating_sub(locked);

        booking.settlement = Some(SettlementInfo {
            rental_fee_paid_yocto: fee,
            damage_deduction_yocto: 0,
            lender_total_payout_yocto: fee,
            borrower_collateral_refund_yocto: collateral,
            settled_at_ns: env::block_timestamp(),
            resolved_by: caller.clone(),
            resolution_note:
                "Lender confirmed safe return & matching TIN/Serial. Fee paid to lender; 100% collateral refunded to borrower."
                    .to_string(),
        });

        self.credit_claimable(&booking.lender, fee);
        self.credit_claimable(&booking.borrower, collateral);
        self.bookings.insert(&booking_id, &booking);
        booking
    }

    /// Step 6: If the deadline passed, item is damaged, or someone attempted a product swap,
    /// either party opens a dispute. Collateral and fee are frozen for BorrowBond Team review.
    pub fn open_dispute(&mut self, booking_id: String) -> Booking {
        let mut booking = self.get_booking_or_panic(&booking_id);
        let caller = env::predecessor_account_id();
        assert!(
            caller == booking.borrower || caller == booking.lender,
            "Only borrower or lender can open a dispute"
        );
        assert!(
            booking.status == BookingStatus::Active
                || booking.status == BookingStatus::ReturnRequested,
            "Disputes can only be opened on ACTIVE or RETURN_REQUESTED bookings"
        );

        booking.status = BookingStatus::Disputed;
        booking.dispute_status = DisputeStatus::Open;
        self.bookings.insert(&booking_id, &booking);
        booking
    }

    /// Step 7: BorrowBond Team / Agent Arbitration (`borrowbond_team_agent`).
    /// Reviews the TIN/Serial, brand, photos, and damage evidence from both parties.
    /// Deducts the Rental Fee + verified Damage Cost from the locked escrow and automatically
    /// redirects the remaining Collateral back to the Borrower's account.
    pub fn resolve_dispute_with_damage_deduction(
        &mut self,
        booking_id: String,
        damage_deduction_yocto: u128,
        resolution_note: String,
    ) -> Booking {
        let mut booking = self.get_booking_or_panic(&booking_id);
        let caller = env::predecessor_account_id();
        assert!(
            caller == self.borrowbond_team_agent || caller == self.owner,
            "Only the BorrowBond Team / Arbitration Agent can execute dispute redirection"
        );
        assert_eq!(
            booking.status,
            BookingStatus::Disputed,
            "Booking must be DISPUTED"
        );
        assert!(booking.settlement.is_none(), "Booking already settled");

        let capped_damage = std::cmp::min(damage_deduction_yocto, booking.collateral_yocto);
        let lender_total_payout = booking
            .rental_fee_yocto
            .checked_add(capped_damage)
            .expect("Overflow calculating lender payout");
        let borrower_remaining_collateral = booking
            .collateral_yocto
            .checked_sub(capped_damage)
            .expect("Underflow calculating borrower remaining collateral");

        let locked = booking.total_escrowed_yocto;
        booking.total_escrowed_yocto = 0;
        booking.status = BookingStatus::Resolved;
        booking.dispute_status = DisputeStatus::Resolved;
        self.total_locked_escrow_yocto = self.total_locked_escrow_yocto.saturating_sub(locked);

        booking.settlement = Some(SettlementInfo {
            rental_fee_paid_yocto: booking.rental_fee_yocto,
            damage_deduction_yocto: capped_damage,
            lender_total_payout_yocto: lender_total_payout,
            borrower_collateral_refund_yocto: borrower_remaining_collateral,
            settled_at_ns: env::block_timestamp(),
            resolved_by: caller,
            resolution_note,
        });

        if lender_total_payout > 0 {
            self.credit_claimable(&booking.lender, lender_total_payout);
        }
        if borrower_remaining_collateral > 0 {
            self.credit_claimable(&booking.borrower, borrower_remaining_collateral);
        }

        self.bookings.insert(&booking_id, &booking);
        booking
    }

    pub fn cancel_booking(&mut self, booking_id: String) -> Booking {
        let mut booking = self.get_booking_or_panic(&booking_id);
        let caller = env::predecessor_account_id();
        assert!(
            caller == booking.borrower || caller == booking.lender,
            "Only borrower or lender may cancel before acceptance"
        );
        assert_eq!(
            booking.status,
            BookingStatus::Requested,
            "Only REQUESTED bookings can be cancelled"
        );

        let refund = booking.total_escrowed_yocto;
        booking.total_escrowed_yocto = 0;
        booking.status = BookingStatus::Cancelled;
        self.total_locked_escrow_yocto = self.total_locked_escrow_yocto.saturating_sub(refund);

        booking.settlement = Some(SettlementInfo {
            rental_fee_paid_yocto: 0,
            damage_deduction_yocto: 0,
            lender_total_payout_yocto: 0,
            borrower_collateral_refund_yocto: refund,
            settled_at_ns: env::block_timestamp(),
            resolved_by: caller,
            resolution_note: "Cancelled before acceptance; 100% refunded to borrower.".to_string(),
        });

        self.credit_claimable(&booking.borrower, refund);
        self.bookings.insert(&booking_id, &booking);
        booking
    }

    /// Allows anyone to expire an unaccepted booking after `acceptance_deadline_ns` has passed,
    /// automatically refunding 100% of the deposit to the borrower.
    pub fn expire_unaccepted_booking(&mut self, booking_id: String) -> Booking {
        let mut booking = self.get_booking_or_panic(&booking_id);
        assert_eq!(
            booking.status,
            BookingStatus::Requested,
            "Only REQUESTED bookings can expire"
        );
        assert!(
            env::block_timestamp() >= booking.acceptance_deadline_ns,
            "Acceptance deadline has not yet passed"
        );

        let refund = booking.total_escrowed_yocto;
        booking.total_escrowed_yocto = 0;
        booking.status = BookingStatus::Expired;
        self.total_locked_escrow_yocto = self.total_locked_escrow_yocto.saturating_sub(refund);

        booking.settlement = Some(SettlementInfo {
            rental_fee_paid_yocto: 0,
            damage_deduction_yocto: 0,
            lender_total_payout_yocto: 0,
            borrower_collateral_refund_yocto: refund,
            settled_at_ns: env::block_timestamp(),
            resolved_by: env::predecessor_account_id(),
            resolution_note: "Acceptance deadline expired; 100% refunded to borrower.".to_string(),
        });

        self.credit_claimable(&booking.borrower, refund);
        self.bookings.insert(&booking_id, &booking);
        booking
    }

    /// Reentrancy-safe pull withdrawal with storage reserve guard.
    pub fn withdraw_claimable(&mut self) -> Promise {
        let caller = env::predecessor_account_id();
        let balance = self.claimable_balances.get(&caller).unwrap_or(0);
        assert!(balance > 0, "No claimable balance available");

        let contract_balance = env::account_balance().as_yoctonear();
        assert!(
            contract_balance.saturating_sub(balance) >= MIN_STORAGE_RESERVE_YOCTO,
            "Contract storage reserve protection triggered"
        );

        // Zero balance before external transfer to prevent reentrancy
        self.claimable_balances.insert(&caller, &0);
        Promise::new(caller).transfer(NearToken::from_yoctonear(balance))
    }

    pub fn get_booking(&self, booking_id: String) -> Option<Booking> {
        self.bookings.get(&booking_id)
    }

    pub fn get_claimable_balance(&self, account_id: AccountId) -> u128 {
        self.claimable_balances.get(&account_id).unwrap_or(0)
    }

    fn get_booking_or_panic(&self, booking_id: &String) -> Booking {
        self.bookings
            .get(booking_id)
            .expect("Booking not found on-chain")
    }

    fn credit_claimable(&mut self, account: &AccountId, amount: u128) {
        if amount == 0 {
            return;
        }
        let current = self.claimable_balances.get(account).unwrap_or(0);
        let updated = current
            .checked_add(amount)
            .expect("Overflow crediting claimable balance");
        self.claimable_balances.insert(account, &updated);
    }
}
