/**
 * Server-side identity for BorrowBond.
 *
 * The browser is NOT trusted to say who it is. Identity comes from an HttpOnly, HMAC-signed cookie that is
 * issued only after either:
 *   1. a real NEP-413 wallet signature over a fresh server challenge, AND an on-chain check that the signing
 *      key belongs to that account (wallet connection proves control of a key, not a real-world identity), or
 *   2. choosing a clearly labelled DEMO PERSONA (simulated accounts; only while DEMO_MODE is not "false").
 */
import crypto from 'node:crypto';
import type { Express, Request, Response, NextFunction } from 'express';
import bs58 from 'bs58';

export const SESSION_COOKIE = 'bb_session';
export const SESSION_TTL_SECONDS = 60 * 60 * 8;
const CHALLENGE_TTL_SECONDS = 300;
const SIGN_IN_MESSAGE = 'Sign in to BorrowBond (testnet prototype). This signature does not move funds.';
const RECIPIENT = 'BorrowBond';

// ---------------------------------------------------------------- secrets
let cachedSecret: string | null = null;
export function getSecret(): string {
  if (cachedSecret) return cachedSecret;
  const s = process.env.SESSION_SECRET;
  if (s && s.length >= 32) return (cachedSecret = s);
  if (process.env.NODE_ENV === 'production') {
    throw new Error('SESSION_SECRET (32+ chars) must be set in production.');
  }
  // Dev only: random per process, so nothing guessable is ever baked into the source.
  console.warn('[identity] SESSION_SECRET not set; using a random per-process secret (sessions reset on restart).');
  return (cachedSecret = crypto.randomBytes(32).toString('hex'));
}
const hmacHex = (v: string) => crypto.createHmac('sha256', getSecret()).update(v).digest('hex');
function safeEq(a: string, b: string): boolean {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
const b64u = (s: string) => Buffer.from(s, 'utf8').toString('base64url');

// ---------------------------------------------------------------- sessions
export interface SessionInfo {
  account: string;
  kind: 'wallet' | 'demo';
}

export function createSessionToken(info: SessionInfo, nowSec = Math.floor(Date.now() / 1000)): string {
  const body = b64u(JSON.stringify({ a: info.account, k: info.kind, exp: nowSec + SESSION_TTL_SECONDS }));
  return `${body}.${hmacHex(`session:${body}`)}`;
}

export function readSessionToken(token: string | undefined, nowSec = Math.floor(Date.now() / 1000)): SessionInfo | null {
  if (!token) return null;
  const [body, mac] = token.split('.');
  if (!body || !mac || !safeEq(mac, hmacHex(`session:${body}`))) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (typeof p.a !== 'string' || typeof p.exp !== 'number' || p.exp < nowSec) return null;
    return { account: p.a, kind: p.k === 'demo' ? 'demo' : 'wallet' };
  } catch {
    return null;
  }
}

export function createChallenge(nowSec = Math.floor(Date.now() / 1000)) {
  const nonce = crypto.randomBytes(32);
  const nonceB64 = nonce.toString('base64');
  const body = b64u(JSON.stringify({ n: nonceB64, exp: nowSec + CHALLENGE_TTL_SECONDS }));
  return { nonceB64, token: `${body}.${hmacHex(`challenge:${body}`)}`, message: SIGN_IN_MESSAGE, recipient: RECIPIENT };
}

export function readChallenge(token: string, nowSec = Math.floor(Date.now() / 1000)): { nonce: Buffer } | null {
  const [body, mac] = String(token).split('.');
  if (!body || !mac || !safeEq(mac, hmacHex(`challenge:${body}`))) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as { n: string; exp: number };
    if (p.exp < nowSec) return null;
    const nonce = Buffer.from(p.n, 'base64');
    return nonce.length === 32 ? { nonce } : null;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------- NEP-413
const NEP413_TAG = 2147484061; // 2^31 + 413
const u32le = (n: number) => {
  const b = Buffer.alloc(4);
  b.writeUInt32LE(n);
  return b;
};
const borshString = (s: string) => {
  const d = Buffer.from(s, 'utf8');
  return Buffer.concat([u32le(d.length), d]);
};

export function nep413Hash(p: { message: string; nonce: Uint8Array; recipient: string }): Buffer {
  if (p.nonce.length !== 32) throw new Error('Nonce must be 32 bytes');
  const payload = Buffer.concat([borshString(p.message), Buffer.from(p.nonce), borshString(p.recipient), Buffer.from([0])]);
  return crypto.createHash('sha256').update(Buffer.concat([u32le(NEP413_TAG), payload])).digest();
}

const ED25519_SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');

export function verifyNep413(
  p: { message: string; nonce: Uint8Array; recipient: string },
  publicKey: string,
  signature: string
): boolean {
  try {
    if (!publicKey.startsWith('ed25519:')) return false;
    const raw = Buffer.from(bs58.decode(publicKey.slice(8)));
    if (raw.length !== 32 || raw.every((b) => b === 0)) return false; // reject degenerate keys
    const key = crypto.createPublicKey({ key: Buffer.concat([ED25519_SPKI_PREFIX, raw]), format: 'der', type: 'spki' });
    const sig = signature.startsWith('ed25519:') ? Buffer.from(bs58.decode(signature.slice(8))) : Buffer.from(signature, 'base64');
    if (sig.length !== 64) return false;
    return crypto.verify(null, nep413Hash(p), key, sig);
  } catch {
    return false;
  }
}

/** True only if `publicKey` is a registered access key of `accountId` on the configured NEAR RPC. */
export async function hasAccessKey(accountId: string, publicKey: string, fetchImpl: typeof fetch = fetch): Promise<boolean> {
  const rpc = process.env.VITE_NEAR_RPC_URL || 'https://rpc.testnet.near.org';
  const res = await fetchImpl(rpc, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '2.0', id: 'bb', method: 'query',
      params: { request_type: 'view_access_key', finality: 'final', account_id: accountId, public_key: publicKey },
    }),
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) throw new Error(`NEAR RPC HTTP ${res.status}`);
  const json = (await res.json()) as { error?: unknown; result?: { error?: unknown } };
  return !json.error && !json.result?.error;
}

// ---------------------------------------------------------------- helpers
export const TESTNET_ACCOUNT_RE = /^(?=.{2,64}$)[a-z0-9]+([-_.][a-z0-9]+)*\.testnet$/;

export function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of (header ?? '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function getSession(req: Request): SessionInfo | null {
  return readSessionToken(parseCookies(req.headers.cookie)[SESSION_COOKIE]);
}

/** The ONLY source of "who is calling". Never read a wallet name from the request body or query. */
export function getCaller(req: Request): string | null {
  return getSession(req)?.account ?? null;
}

export function requireCaller(req: Request, res: Response): string | null {
  const c = getCaller(req);
  if (!c) res.status(401).json({ error: 'Sign in first: connect a NEAR testnet wallet or choose a demo persona.' });
  return c;
}

function setSessionCookie(res: Response, info: SessionInfo) {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${SESSION_COOKIE}=${encodeURIComponent(createSessionToken(info))}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_TTL_SECONDS}${secure}`);
}

/** Blocks cross-origin state-changing requests when the browser sends an Origin header. */
export function sameOriginGuard(req: Request, res: Response, next: NextFunction) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.headers.origin;
  if (origin) {
    try {
      if (new URL(origin).host !== req.headers.host) return void res.status(403).json({ error: 'Cross-origin request blocked.' });
    } catch {
      return void res.status(403).json({ error: 'Bad origin.' });
    }
  }
  next();
}

const hits = new Map<string, { n: number; t: number }>();
function limited(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const h = hits.get(key);
  if (!h || now - h.t > windowMs) { hits.set(key, { n: 1, t: now }); return false; }
  h.n += 1;
  return h.n > max;
}

export const demoModeEnabled = () => process.env.DEMO_MODE !== 'false';

export interface DemoPersona { account: string; label: string; role: string }

// ---------------------------------------------------------------- routes
export function registerIdentityRoutes(app: Express, opts: { personas: DemoPersona[] }) {
  app.use(sameOriginGuard);

  app.get('/api/session', (req, res) => {
    const s = getSession(req);
    res.json({
      account: s?.account ?? null,
      kind: s?.kind ?? null,
      demoModeEnabled: demoModeEnabled(),
      personas: demoModeEnabled() ? opts.personas : [],
    });
  });

  app.post('/api/session/demo', (req, res) => {
    if (!demoModeEnabled()) return void res.status(403).json({ error: 'Demo personas are disabled on this server.' });
    const account = String(req.body?.account ?? '');
    const persona = opts.personas.find((p) => p.account === account);
    if (!persona) return void res.status(400).json({ error: 'Unknown demo persona.' });
    setSessionCookie(res, { account, kind: 'demo' });
    res.json({ account, kind: 'demo', label: persona.label });
  });

  app.post('/api/auth/wallet/challenge', (req, res) => {
    if (limited(`ch:${req.ip}`, 30, 60_000)) return void res.status(429).json({ error: 'Too many requests.' });
    const c = createChallenge();
    res.json({ nonce: c.nonceB64, token: c.token, message: c.message, recipient: c.recipient });
  });

  app.post('/api/auth/wallet/verify', async (req, res) => {
    if (limited(`vf:${req.ip}`, 10, 60_000)) return void res.status(429).json({ error: 'Too many attempts. Wait a minute.' });
    const { token, accountId, publicKey, signature } = req.body ?? {};
    if (![token, accountId, publicKey, signature].every((v) => typeof v === 'string' && v.length < 700)) {
      return void res.status(400).json({ error: 'Malformed sign-in request.' });
    }
    if (!TESTNET_ACCOUNT_RE.test(accountId)) {
      return void res.status(400).json({ error: 'Only NEAR testnet accounts (…testnet) are accepted.' });
    }
    const ch = readChallenge(token);
    if (!ch) return void res.status(400).json({ error: 'Sign-in challenge expired. Try again.' });
    if (!verifyNep413({ message: SIGN_IN_MESSAGE, nonce: ch.nonce, recipient: RECIPIENT }, publicKey, signature)) {
      return void res.status(401).json({ error: 'Signature is not valid.' });
    }
    let owns = false;
    try {
      owns = await hasAccessKey(accountId, publicKey);
    } catch {
      return void res.status(503).json({ error: 'Could not reach NEAR to verify the account. Try again shortly.' });
    }
    if (!owns) return void res.status(401).json({ error: 'That key is not registered on this account.' });
    setSessionCookie(res, { account: accountId, kind: 'wallet' });
    res.json({ account: accountId, kind: 'wallet' });
  });

  app.post('/api/auth/logout', (_req, res) => {
    res.setHeader('Set-Cookie', `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
    res.json({ ok: true });
  });
}
