import React, { useState, useMemo } from 'react';
import {
  Search,
  SlidersHorizontal,
  ArrowUpDown,
  Sparkles,
  Plus,
  Images,
  ArrowLeftRight,
  QrCode,
} from 'lucide-react';
import type { MarketplaceListing, ProviderProfile } from '../lib/security/policyEngine';
import { ResilientImage } from '../components/ResilientImage';
import { NearTokenIcon, UsdtTokenIcon } from '../components/TokenIcons';
import {
  ProductQrScannerModal,
  type ScannedProductQrPayload,
} from '../components/ProductQrScannerModal';

interface MarketplaceViewProps {
  listings: MarketplaceListing[];
  profiles: Record<string, ProviderProfile>;
  initialCategory: 'ALL' | 'PHYSICAL' | 'DIGITAL';
  nearUsdRate?: number;
  displayCurrency?: 'NEAR' | 'USDT';
  onToggleCurrency?: (currency: 'NEAR' | 'USDT') => void;
  onOpenListing: (listingId: string) => void;
  onNavigateCreate: () => void;
  onOpenAiAgent: () => void;
}

export const MarketplaceView: React.FC<MarketplaceViewProps> = ({
  listings,
  profiles,
  initialCategory,
  nearUsdRate = 3.7,
  displayCurrency = 'NEAR',
  onToggleCurrency,
  onOpenListing,
  onNavigateCreate,
  onOpenAiAgent,
}) => {
  const [resourceFilter, setResourceFilter] = useState<'ALL' | 'PHYSICAL' | 'DIGITAL'>(initialCategory);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [maxFeeNear, setMaxFeeNear] = useState<number>(500);
  const [maxCollateralNear, setMaxCollateralNear] = useState<number>(1000);
  const [onlyAvailable, setOnlyAvailable] = useState<boolean>(true);
  const [minCompletedDeals, setMinCompletedDeals] = useState<number>(0);
  const [sortBy, setSortBy] = useState<'RELEVANCE' | 'PRICE_ASC' | 'COLLATERAL_ASC' | 'NEWEST'>('RELEVANCE');
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [qrModalMode, setQrModalMode] = useState<'SCAN' | 'SHOW_TAG'>('SCAN');
  const [activeQrListing, setActiveQrListing] = useState<MarketplaceListing | null>(null);

  const categories = useMemo(() => {
    const set = new Set<string>();
    listings.forEach((l) => set.add(l.category));
    return ['ALL', ...Array.from(set)];
  }, [listings]);

  const filteredListings = useMemo(() => {
    return listings
      .filter((item) => {
        if (resourceFilter !== 'ALL' && item.resourceType !== resourceFilter) return false;
        if (selectedCategory !== 'ALL' && item.category !== selectedCategory) return false;
        if (onlyAvailable && item.availabilityStatus !== 'AVAILABLE') return false;
        if (item.rentalFeeNear > maxFeeNear) return false;
        if (item.collateralNear > maxCollateralNear) return false;

        const prov = profiles[item.ownerWallet];
        const deals = (prov?.completedLends ?? 0) + (prov?.completedBorrows ?? 0);
        if (deals < minCompletedDeals) return false;

        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const hay = `${item.title} ${item.description} ${item.category} ${item.ownerWallet}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'PRICE_ASC') return a.rentalFeeNear - b.rentalFeeNear;
        if (sortBy === 'COLLATERAL_ASC') return a.collateralNear - b.collateralNear;
        if (sortBy === 'NEWEST') {
          return new Date(b.createdAtIso).getTime() - new Date(a.createdAtIso).getTime();
        }
        return 0;
      });
  }, [
    listings,
    profiles,
    resourceFilter,
    selectedCategory,
    onlyAvailable,
    maxFeeNear,
    maxCollateralNear,
    minCompletedDeals,
    searchQuery,
    sortBy,
  ]);

  const handleResetFilters = () => {
    setResourceFilter('ALL');
    setSearchQuery('');
    setSelectedCategory('ALL');
    setMaxFeeNear(500);
    setMaxCollateralNear(1000);
    setOnlyAvailable(true);
    setMinCompletedDeals(0);
    setSortBy('RELEVANCE');
  };

  const formatAmount = (nearAmount: number) => {
    const usdt = Number((nearAmount * nearUsdRate).toFixed(2));
    if (displayCurrency === 'USDT') {
      return {
        primary: `$${usdt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`,
        secondary: `${nearAmount} NEAR`,
        isUsdtPrimary: true,
      };
    }
    return {
      primary: `${nearAmount} NEAR`,
      secondary: `≈ $${usdt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`,
      isUsdtPrimary: false,
    };
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
      {/* Header & Interactive Resource Type Switcher */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 border-b border-slate-800/80 pb-6">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 text-xs font-mono text-[#00EC97] uppercase tracking-wider">
            <NearTokenIcon size={15} />
            <span>Unified NEAR Borrowing Marketplace</span>
            <span>•</span>
            <UsdtTokenIcon size={15} />
            <span>Live 1 NEAR = ${nearUsdRate.toFixed(2)} USDT</span>
          </div>
          <h1 className="text-3xl font-extrabold font-display text-[#F5F8FF]">
            Discover Physical & Digital Resources
          </h1>
          <p className="text-sm text-[#9BA8C0]">
            Every agreement separates the rental fee from 50% AI-benchmarked refundable NEAR escrow collateral.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Segmented Resource Filter */}
          <div
            role="group"
            aria-label="Resource Type Filter"
            className="flex items-center gap-1 p-1 bg-[#0D1322] border border-slate-800 rounded-xl"
          >
            {(['ALL', 'PHYSICAL', 'DIGITAL'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setResourceFilter(tab)}
                className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  resourceFilter === tab
                    ? 'bg-[#00EC97] text-[#04080E] shadow-[0_0_15px_rgba(0,236,151,0.3)]'
                    : 'text-[#9BA8C0] hover:text-[#F5F8FF]'
                }`}
              >
                {tab === 'ALL' ? 'All Resources' : tab === 'PHYSICAL' ? 'Physical' : 'Digital'}
              </button>
            ))}
          </div>

          {/* Currency Display Switcher with Official 2D Token Icons */}
          {onToggleCurrency && (
            <button
              type="button"
              onClick={() => onToggleCurrency(displayCurrency === 'NEAR' ? 'USDT' : 'NEAR')}
              className="btn-near-secondary px-3 py-2 text-xs whitespace-nowrap shrink-0"
            >
              {displayCurrency === 'NEAR' ? <NearTokenIcon size={15} /> : <UsdtTokenIcon size={15} />}
              <ArrowLeftRight className="w-3.5 h-3.5 text-[#00EC97]" />
              <span>Currency: {displayCurrency}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              setActiveQrListing(listings[0] || null);
              setQrModalMode('SCAN');
              setQrModalOpen(true);
            }}
            className="btn-near-secondary px-3.5 py-2 text-xs whitespace-nowrap shrink-0"
          >
            <QrCode className="w-3.5 h-3.5 text-[#00EC97]" />
            <span>Scan Product QR</span>
          </button>

          <button
            type="button"
            onClick={onOpenAiAgent}
            className="btn-near-secondary px-3.5 py-2 text-xs whitespace-nowrap shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#00EC97]" />
            <span>AI Quick Match</span>
          </button>

          <button
            type="button"
            onClick={onNavigateCreate}
            className="btn-near-primary px-4 py-2 text-xs whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Listing</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="near-glass-card rounded-2xl p-5 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <label htmlFor="mkt-search" className="block text-xs text-[#9BA8C0] mb-1.5">
              Search Keyword, Model Spec, or Provider
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-[#9BA8C0] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="mkt-search"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search iPhone 18, camera, projector, weather API, GPU..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-[#06080F] border border-slate-800 rounded-xl text-[#F5F8FF] placeholder:text-slate-500 focus:outline-none focus:border-[#00EC97]"
              />
            </div>
          </div>

          <div>
            <label htmlFor="mkt-category" className="block text-xs text-[#9BA8C0] mb-1.5">
              Category
            </label>
            <select
              id="mkt-category"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-[#06080F] border border-slate-800 rounded-xl text-[#F5F8FF] focus:outline-none focus:border-[#00EC97]"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat === 'ALL' ? 'All Categories' : cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="mkt-sort" className="block text-xs text-[#9BA8C0] mb-1.5">
              Sort By
            </label>
            <div className="relative">
              <ArrowUpDown className="w-3.5 h-3.5 text-[#9BA8C0] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <select
                id="mkt-sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="w-full pl-8 pr-3 py-2 text-xs bg-[#06080F] border border-slate-800 rounded-xl text-[#F5F8FF] focus:outline-none focus:border-[#00EC97]"
              >
                <option value="RELEVANCE">Relevance</option>
                <option value="PRICE_ASC">Rental Fee: Low to High</option>
                <option value="COLLATERAL_ASC">Collateral: Low to High</option>
                <option value="NEWEST">Newest Listed</option>
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-3 border-t border-slate-800/80 items-end">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <label htmlFor="mkt-max-fee" className="text-[#9BA8C0]">Max Rental Fee</label>
              <span className="font-mono text-[#F5F8FF] tabular-nums">
                {maxFeeNear} NEAR (${(maxFeeNear * nearUsdRate).toFixed(0)})
              </span>
            </div>
            <input
              id="mkt-max-fee"
              type="range"
              min="0.05"
              max="500"
              step="0.05"
              value={maxFeeNear}
              onChange={(e) => setMaxFeeNear(parseFloat(e.target.value))}
              className="w-full accent-[#00EC97] cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <label htmlFor="mkt-max-col" className="text-[#9BA8C0]">Max Collateral</label>
              <span className="font-mono text-[#00EC97] tabular-nums">
                {maxCollateralNear} NEAR (${(maxCollateralNear * nearUsdRate).toFixed(0)})
              </span>
            </div>
            <input
              id="mkt-max-col"
              type="range"
              min="0.1"
              max="1000"
              step="0.5"
              value={maxCollateralNear}
              onChange={(e) => setMaxCollateralNear(parseFloat(e.target.value))}
              className="w-full accent-[#00EC97] cursor-pointer"
            />
          </div>

          <div>
            <label htmlFor="mkt-min-rep" className="block text-xs text-[#9BA8C0] mb-1">
              Provider Completed Deals
            </label>
            <select
              id="mkt-min-rep"
              value={minCompletedDeals}
              onChange={(e) => setMinCompletedDeals(Number(e.target.value))}
              className="w-full px-3 py-1.5 text-xs bg-[#06080F] border border-slate-800 rounded-xl text-[#F5F8FF]"
            >
              <option value={0}>Any History (Include New Providers)</option>
              <option value={5}>5+ Completed Deals</option>
              <option value={15}>15+ Completed Deals</option>
            </select>
          </div>

          <div className="flex items-center justify-between gap-3">
            <label className="flex items-center gap-2 text-xs text-[#F5F8FF] cursor-pointer">
              <input
                type="checkbox"
                checked={onlyAvailable}
                onChange={(e) => setOnlyAvailable(e.target.checked)}
                className="rounded accent-[#00EC97]"
              />
              <span>Available Only</span>
            </label>
            <button
              type="button"
              onClick={handleResetFilters}
              className="text-xs text-[#00EC97] hover:underline cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#9BA8C0]">
        <span>
          Showing <strong className="text-[#F5F8FF] font-mono tabular-nums">{filteredListings.length}</strong> of {listings.length} resources
        </span>
        <span className="font-mono inline-flex items-center gap-1.5">
          <NearTokenIcon size={14} />
          <span>Live Market Rate:</span>
          <strong className="text-[#00EC97]">1 NEAR = ${nearUsdRate.toFixed(2)} USDT</strong>
          <UsdtTokenIcon size={14} />
        </span>
      </div>

      {/* Listing Grid or Empty State */}
      {filteredListings.length === 0 ? (
        <div className="near-glass-card rounded-2xl p-12 text-center space-y-4">
          <SlidersHorizontal className="w-8 h-8 text-[#00EC97] mx-auto" />
          <div className="space-y-1">
            <h2 className="text-lg font-bold font-display text-[#F5F8FF]">
              No matching resources found
            </h2>
            <p className="text-xs text-[#9BA8C0] max-w-md mx-auto">
              Adjust your rental fee or collateral sliders, or reset filters to view all physical and digital offerings.
            </p>
          </div>
          <button
            type="button"
            onClick={handleResetFilters}
            className="btn-near-primary px-5 py-2.5 text-xs"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredListings.map((item) => {
            const prov = profiles[item.ownerWallet];
            const completedCount = (prov?.completedLends ?? 0) + (prov?.completedBorrows ?? 0);
            const totalRequiredNear = Number((item.rentalFeeNear + item.collateralNear).toFixed(4));
            const photoCount = item.images?.length || 1;
            const feeDisplay = formatAmount(item.rentalFeeNear);
            const colDisplay = formatAmount(item.collateralNear);
            const totalDisplay = formatAmount(totalRequiredNear);

            return (
              <article
                key={item.id}
                className="near-glass-card rounded-2xl overflow-hidden flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 hover:border-[#00EC97]/40"
              >
                <div>
                  {/* Frosted Glass Image Frame */}
                  <div className="p-3 pb-0">
                    <div className="glass-image-frame relative aspect-4/3 w-full">
                      <ResilientImage
                        src={item.images?.[0] || item.imageUrl}
                        alt={item.title}
                        resourceType={item.resourceType}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-3 right-3 z-10 px-2.5 py-1 rounded-lg bg-[#06080F]/85 backdrop-blur-md border border-slate-700/80 text-[11px] font-mono text-[#F5F8FF] flex items-center gap-1">
                        <Images className="w-3 h-3 text-[#00EC97]" />
                        <span>{photoCount} {photoCount === 1 ? 'Photo' : 'Photos'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-5 space-y-3">
                    <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#9BA8C0]">
                      <span className="font-bold text-[#00EC97]">
                        {item.resourceType === 'PHYSICAL' ? 'Physical' : 'Digital'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{item.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{item.availabilityStatus === 'AVAILABLE' ? 'Available' : item.availabilityStatus}</span>
                    </div>

                    <h2 className="text-base font-bold font-display text-[#F5F8FF] line-clamp-1">
                      {item.title}
                    </h2>

                    <p className="text-xs text-[#9BA8C0] line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>

                    <div className="text-xs text-[#9BA8C0] pt-1 flex items-center justify-between">
                      <span className="truncate max-w-[180px]">
                        Provider: <code className="font-mono text-[#F5F8FF]">{item.ownerWallet}</code>
                      </span>
                      <span className="font-mono tabular-nums">{completedCount} deals</span>
                    </div>
                  </div>
                </div>

                {/* Distinct Rental Fee vs Refundable Collateral Breakdown in NEAR & USDT with 2D Icons */}
                <div className="p-5 pt-4 border-t border-slate-800/80 bg-[#06080F]/60 space-y-3">
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-[#9BA8C0] block">
                        Rental Fee ({item.exampleDuration} {item.durationUnit.toLowerCase()})
                      </span>
                      <span className="font-mono font-bold text-[#F5F8FF] text-sm tabular-nums inline-flex items-center gap-1.5 mt-0.5">
                        {feeDisplay.isUsdtPrimary ? <UsdtTokenIcon size={15} /> : <NearTokenIcon size={15} />}
                        <span>{feeDisplay.primary}</span>
                      </span>
                      <span className="font-mono text-[11px] text-[#9BA8C0] tabular-nums block">
                        {feeDisplay.secondary}
                      </span>
                    </div>
                    <div>
                      <span className="text-[#9BA8C0] block">Refundable Collateral</span>
                      <span className="font-mono font-bold text-[#00EC97] text-sm tabular-nums inline-flex items-center gap-1.5 mt-0.5">
                        {colDisplay.isUsdtPrimary ? <UsdtTokenIcon size={15} /> : <NearTokenIcon size={15} />}
                        <span>{colDisplay.primary}</span>
                      </span>
                      <span className="font-mono text-[11px] text-[#17F1D1] tabular-nums block">
                        {colDisplay.secondary}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-[#9BA8C0] pt-2 border-t border-slate-800/60">
                    <span className="inline-flex items-center gap-1.5">
                      <span>Total Lock:</span>
                      <strong className="text-[#F5F8FF] font-mono tabular-nums">{totalDisplay.primary}</strong>
                    </span>
                    <span>{item.minDuration}–{item.maxDuration} {item.durationUnit.toLowerCase()}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenListing(item.id)}
                      className="btn-near-primary flex-1 py-2.5 px-4 text-xs"
                    >
                      View {photoCount}-Photo Gallery & Borrow
                    </button>
                    <button
                      type="button"
                      title="View or Scan Product Anti-Scam QR Tag"
                      aria-label={`Product QR Tag for ${item.title}`}
                      onClick={() => {
                        setActiveQrListing(item);
                        setQrModalMode('SHOW_TAG');
                        setQrModalOpen(true);
                      }}
                      className="btn-near-secondary py-2.5 px-3 text-xs shrink-0"
                    >
                      <QrCode className="w-4 h-4 text-[#00EC97]" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      <ProductQrScannerModal
        isOpen={qrModalOpen}
        onClose={() => setQrModalOpen(false)}
        mode={qrModalMode}
        title="Scan or Inspect BorrowBond Product QR Tag"
        subtitle="Scan any BorrowBond product QR code or serial barcode to open its listing or verify its Anti-Scam TIN."
        activeProductTag={
          activeQrListing
            ? {
                listingId: activeQrListing.id,
                title: activeQrListing.title,
                brandAndModel: activeQrListing.brandAndModel || activeQrListing.title,
                tinOrSerialNumber:
                  activeQrListing.tinOrSerialNumber || 'TIN-SONY-A7IV-884120',
                category: activeQrListing.category,
                resourceType: activeQrListing.resourceType,
                officialRetailPriceUsd: activeQrListing.officialRetailPriceUsd,
              }
            : undefined
        }
        onScanSuccess={(scanned: ScannedProductQrPayload) => {
          if (scanned.listingId) {
            const matched = listings.find((l) => l.id === scanned.listingId);
            if (matched) {
              onOpenListing(matched.id);
              return;
            }
          }
          const matchedByTin = listings.find(
            (l) =>
              l.tinOrSerialNumber?.toLowerCase() === scanned.tinOrSerialNumber.toLowerCase() ||
              l.title.toLowerCase().includes(scanned.title.toLowerCase().slice(0, 10))
          );
          if (matchedByTin) {
            onOpenListing(matchedByTin.id);
          } else {
            setResourceFilter('ALL');
            setSearchQuery(scanned.title.split('—')[0].trim());
          }
        }}
      />
    </div>
  );
};
