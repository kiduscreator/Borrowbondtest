// Initial production-structured marketplace data for BorrowBond on NEAR Protocol
// Includes Anti-Scam Product Identity (TIN/Serial Number, Brand/Model, Photo Hashes)
// and support for both Physical Hardware and Digital Products (Accounts, NFTs, APIs).

import type { MarketplaceListing, ProviderProfile, SpendingPolicy } from '../security/policyEngine';
import {
  createEscrowLedger,
  createBookingOnContract,
  acceptBookingOnContract,
  confirmHandoverOnContract,
  type EscrowLedgerState,
} from '../near/escrowStateMachine';
import {
  createDigitalGatewayStore,
  issueTemporaryCredential,
  type DigitalGatewayStore,
} from '../digital/accessGateway';

export const INITIAL_PROFILES: Record<string, ProviderProfile> = {
  'optics-lab.testnet': {
    walletAccountId: 'optics-lab.testnet',
    displayName: 'Zurich Optics Studio',
    bio: 'Verified cinema cameras, lenses, and projection hardware on NEAR Protocol.',
    profileStatus: 'COMMUNITY_MEMBER',
    completedBorrows: 4,
    completedLends: 19,
    disputesCount: 0,
    cancellationsCount: 1,
    accountCreatedIso: '2025-11-12T09:00:00.000Z',
  },
  'atmo-telemetry.testnet': {
    walletAccountId: 'atmo-telemetry.testnet',
    displayName: 'AtmoNode Digital Vault',
    bio: 'Provider of verified digital accounts, NFTs, and metered API access via NEAR escrow.',
    profileStatus: 'COMMUNITY_MEMBER',
    completedBorrows: 2,
    completedLends: 31,
    disputesCount: 0,
    cancellationsCount: 0,
    accountCreatedIso: '2025-09-04T14:20:00.000Z',
  },
  'tensor-rack.testnet': {
    walletAccountId: 'tensor-rack.testnet',
    displayName: 'Alpine Compute & NFTs',
    bio: 'On-demand GPU compute nodes, NFT passes, and digital product licenses.',
    profileStatus: 'COMMUNITY_MEMBER',
    completedBorrows: 6,
    completedLends: 14,
    disputesCount: 0,
    cancellationsCount: 0,
    accountCreatedIso: '2026-01-18T11:30:00.000Z',
  },
  'aero-survey.testnet': {
    walletAccountId: 'aero-survey.testnet',
    displayName: 'Helvetia Drone & Robotics',
    bio: 'Industrial quadcopters and LiDAR equipment with registered serial numbers.',
    profileStatus: 'WALLET_CONNECTED',
    completedBorrows: 1,
    completedLends: 7,
    disputesCount: 0,
    cancellationsCount: 0,
    accountCreatedIso: '2026-03-01T08:15:00.000Z',
  },
  'alex-builder.testnet': {
    walletAccountId: 'alex-builder.testnet',
    displayName: 'Alex Rivera',
    bio: 'Verified borrower and lender on NEAR Protocol.',
    profileStatus: 'WALLET_CONNECTED',
    completedBorrows: 8,
    completedLends: 3,
    disputesCount: 0,
    cancellationsCount: 0,
    accountCreatedIso: '2026-01-10T10:00:00.000Z',
  },
  'borrowbondtest.testnet': {
    walletAccountId: 'borrowbondtest.testnet',
    displayName: 'BorrowBond Official',
    bio: 'Primary NEAR account for BorrowBond escrow agreements and dispute arbitration.',
    profileStatus: 'COMMUNITY_MEMBER',
    completedBorrows: 5,
    completedLends: 5,
    disputesCount: 0,
    cancellationsCount: 0,
    accountCreatedIso: '2026-11-07T00:00:00.000Z',
  },
};

export const INITIAL_LISTINGS: MarketplaceListing[] = [
  {
    id: 'lst-phys-camera-01',
    ownerWallet: 'optics-lab.testnet',
    ownerDisplayName: 'Zurich Optics Studio',
    resourceType: 'PHYSICAL',
    title: 'Sony Alpha A1 Full-Frame Cinema Kit',
    brandAndModel: 'Sony Alpha 1 (ILCE-1) + 24-70mm GM II',
    tinOrSerialNumber: 'SN-SONY-3849201-CH',
    description:
      '50MP full-frame camera body with 24-70mm f/2.8 GM II lens, dual batteries, and Pelican case.',
    category: 'Cameras & Optics',
    imageUrl: '/src/assets/images/listing_sony_camera_1794103774108.jpg',
    images: [
      '/src/assets/images/listing_sony_camera_1794103774108.jpg',
      '/src/assets/images/listing_cinema_projector_1794103775797.jpg',
      '/src/assets/images/listing_lidar_drone_1794103777366.jpg',
    ],
    rentalFeeNear: 0.05,
    collateralNear: 0.2,
    officialRetailPriceUsd: 2800,
    nearUsdRateAtListing: 3.7,
    durationUnit: 'DAYS',
    exampleDuration: 3,
    minDuration: 1,
    maxDuration: 7,
    availabilityStatus: 'AVAILABLE',
    conditions:
      'Store in provided hard case. Returned item TIN/Serial (SN-SONY-3849201-CH) is verified before collateral release.',
    cancellationPolicy:
      '100% refund if cancelled prior to lender acceptance.',
    borrowerRequirements:
      'Connected NEAR wallet, receipt confirmation, and lender safe-return verification.',
    isDemoSeed: true,
    createdAtIso: '2026-10-15T10:00:00.000Z',
    ownerEstimatedValueNear: 0.32,
    itemCondition: 'Mint — Sensor clean, zero scratches.',
    includedAccessories: [
      '24-70mm f/2.8 GM II Lens',
      '2x NP-FZ100 Batteries & Charger',
      '128GB CFexpress Card',
      'Pelican Hard Case',
    ],
    pickupReturnInstructions:
      'Handover with one-time booking code and serial number verification.',
    handoverProcedure:
      'Borrower confirms receipt; lender confirms safe return of exact serial number.',
  },
  {
    id: 'lst-dig-weather-01',
    ownerWallet: 'atmo-telemetry.testnet',
    ownerDisplayName: 'AtmoNode Digital Vault',
    resourceType: 'DIGITAL',
    digitalAssetSubtype: 'API_COMPUTE',
    title: 'AtmoNode Weather & Telemetry API',
    brandAndModel: 'AtmoNode Enterprise v4 Gateway',
    tinOrSerialNumber: 'TIN-API-ATMO-9012',
    description:
      'Live meteorology and atmospheric telemetry API with automated temporary bearer token and 20-request quota.',
    category: 'Weather & Telemetry API',
    imageUrl: '/src/assets/images/listing_weather_api_1794103778935.jpg',
    images: [
      '/src/assets/images/listing_weather_api_1794103778935.jpg',
      '/src/assets/images/listing_gpu_compute_1794103779733.jpg',
    ],
    rentalFeeNear: 0.03,
    collateralNear: 0.05,
    officialRetailPriceUsd: 140,
    nearUsdRateAtListing: 3.7,
    durationUnit: 'HOURS',
    exampleDuration: 48,
    minDuration: 24,
    maxDuration: 168,
    availabilityStatus: 'AVAILABLE',
    conditions:
      'Auto-revokes token at 20 requests or 48h expiry. Collateral released upon clean completion.',
    cancellationPolicy:
      '100% refund if cancelled before activation.',
    borrowerRequirements:
      'Active NEAR escrow lock.',
    isDemoSeed: true,
    createdAtIso: '2026-10-18T12:00:00.000Z',
    digitalServiceType: 'REST Telemetry Gateway',
    accessScope: 'read:weather_telemetry (Read-Only)',
    usageQuotaRequests: 20,
    expirationBehavior:
      'Automatic token revocation at quota limit or deadline.',
    technicalRequirements:
      'HTTPS client with Bearer token header.',
    demoEndpointRef: '/api/demo-resource/weather',
    licensingRestrictions:
      'Temporary non-transferable access for the borrower wallet.',
  },
  {
    id: 'lst-dig-nft-03',
    ownerWallet: 'tensor-rack.testnet',
    ownerDisplayName: 'Alpine Compute & NFTs',
    resourceType: 'DIGITAL',
    digitalAssetSubtype: 'NFT_ASSET',
    title: 'NEAR Zero-G Utility NFT Pass & Pro Account',
    brandAndModel: 'Zero-G Genesis NFT #0418 + Cloud Pro Seat',
    tinOrSerialNumber: 'NFT-ZEROG.NEAR-#0418',
    description:
      'Rent verified utility NFT pass (#0418) and linked Pro Studio account with escrow-protected return verification.',
    category: 'NFTs & Digital Accounts',
    imageUrl: '/src/assets/images/listing_gpu_compute_1794103779733.jpg',
    images: [
      '/src/assets/images/listing_gpu_compute_1794103779733.jpg',
      '/src/assets/images/listing_weather_api_1794103778935.jpg',
    ],
    rentalFeeNear: 0.06,
    collateralNear: 0.08,
    officialRetailPriceUsd: 400,
    nearUsdRateAtListing: 3.7,
    durationUnit: 'HOURS',
    exampleDuration: 48,
    minDuration: 12,
    maxDuration: 96,
    availabilityStatus: 'AVAILABLE',
    conditions:
      'Delegated NFT/Account access for 48h. Token ID NFT-ZEROG.NEAR-#0418 is locked on BorrowBond.',
    cancellationPolicy: 'Full refund if cancelled before activation.',
    borrowerRequirements: 'Connected NEAR wallet confirmation.',
    isDemoSeed: true,
    createdAtIso: '2026-10-22T09:45:00.000Z',
    digitalServiceType: 'NFT Utility Pass & Delegated Account',
    accessScope: 'nft:delegated_access (#0418)',
    usageQuotaRequests: 50,
    expirationBehavior: 'Access automatically returns to owner at deadline.',
    technicalRequirements: 'NEAR Wallet verification.',
    demoEndpointRef: '/api/demo-resource/weather',
    licensingRestrictions: 'No credential sharing or account settings changes.',
  },
  {
    id: 'lst-phys-projector-02',
    ownerWallet: 'optics-lab.testnet',
    ownerDisplayName: 'Zurich Optics Studio',
    resourceType: 'PHYSICAL',
    title: '4K Laser Cinema Projector (3200 Lumens)',
    brandAndModel: 'Leica Cine Play 4K Laser UHD',
    tinOrSerialNumber: 'SN-PROJ-7741029-ZRH',
    description:
      '4K UHD laser projector with dual HDMI 2.1 ports and flight case for events and screenings.',
    category: 'Audio & Projection',
    imageUrl: '/src/assets/images/listing_cinema_projector_1794103775797.jpg',
    images: [
      '/src/assets/images/listing_cinema_projector_1794103775797.jpg',
      '/src/assets/images/listing_sony_camera_1794103774108.jpg',
    ],
    rentalFeeNear: 0.04,
    collateralNear: 0.16,
    officialRetailPriceUsd: 1800,
    nearUsdRateAtListing: 3.7,
    durationUnit: 'DAYS',
    exampleDuration: 3,
    minDuration: 1,
    maxDuration: 5,
    availabilityStatus: 'AVAILABLE',
    conditions:
      'Serial number SN-PROJ-7741029-ZRH verified at handover and return.',
    cancellationPolicy:
      'Full refund prior to acceptance.',
    borrowerRequirements:
      'Both-party optical lens check at pickup and return.',
    isDemoSeed: true,
    createdAtIso: '2026-10-20T15:30:00.000Z',
    ownerEstimatedValueNear: 0.25,
    itemCondition: 'Mint — Pristine optics.',
    includedAccessories: [
      'HDMI 2.1 Cable (3m)',
      'AC Power Brick',
      'Bluetooth Remote',
      'Flight Case',
    ],
    pickupReturnInstructions: 'Pickup with booking code and serial check.',
    handoverProcedure: 'Power-on test pattern check at handover and return.',
  },
  {
    id: 'lst-phys-drone-03',
    ownerWallet: 'aero-survey.testnet',
    ownerDisplayName: 'Helvetia Drone & Robotics',
    resourceType: 'PHYSICAL',
    title: 'DJI Matrice LiDAR Inspection Drone',
    brandAndModel: 'DJI Matrice 350 RTK + Zenmuse L2',
    tinOrSerialNumber: 'TIN-DJI-9920418-RTK',
    description:
      'Carbon-fiber inspection drone with 3-axis optical gimbal, obstacle avoidance, and 3 flight batteries.',
    category: 'Drones & Robotics',
    imageUrl: '/src/assets/images/listing_lidar_drone_1794103777366.jpg',
    images: [
      '/src/assets/images/listing_lidar_drone_1794103777366.jpg',
      '/src/assets/images/listing_sony_camera_1794103774108.jpg',
    ],
    rentalFeeNear: 0.08,
    collateralNear: 0.35,
    officialRetailPriceUsd: 3200,
    nearUsdRateAtListing: 3.7,
    durationUnit: 'DAYS',
    exampleDuration: 2,
    minDuration: 1,
    maxDuration: 5,
    availabilityStatus: 'AVAILABLE',
    conditions:
      'Operate within visual line-of-sight. Registered TIN-DJI-9920418-RTK verified on return.',
    cancellationPolicy: 'Full refund before lender acceptance.',
    borrowerRequirements: 'Pre-flight propeller and gimbal inspection photos.',
    isDemoSeed: true,
    createdAtIso: '2026-10-25T11:10:00.000Z',
    ownerEstimatedValueNear: 0.55,
    itemCondition: 'Excellent — Calibrated IMU and gimbal.',
    includedAccessories: [
      'RC Pro Controller',
      '3x Flight Batteries & Hub',
      'Hard Shell Case',
    ],
    pickupReturnInstructions: 'In-person handover with serial and flight log check.',
    handoverProcedure: 'Both parties verify gimbal, serial number, and rotors.',
  },
];

export const DEFAULT_SPENDING_POLICY: SpendingPolicy = {
  walletAccountId: 'alex-builder.testnet',
  maxRentalFeeNear: 0.25,
  maxCollateralNear: 0.5,
  maxTotalPaymentNear: 0.6,
  allowedCategories: [
    'Cameras & Optics',
    'Audio & Projection',
    'Drones & Robotics',
    'Mobile & Flagship Devices',
    'Weather & Telemetry API',
    'GPU & AI Compute',
    'NFTs & Digital Accounts',
    'Digital Products & Licenses',
    'Licensed Datasets',
  ],
  maxDurationDays: 7,
  approvedProviders: ['optics-lab.testnet', 'atmo-telemetry.testnet', 'tensor-rack.testnet', 'borrowbondtest.testnet'],
  excludedProviders: [],
  requireManualWalletConfirmation: true,
};

export function bootstrapDemoEnvironment(): {
  profiles: Record<string, ProviderProfile>;
  listings: MarketplaceListing[];
  policy: SpendingPolicy;
  escrowLedger: EscrowLedgerState;
  digitalGateway: DigitalGatewayStore;
  demoRawTokenForWeatherBooking: string;
} {
  const profiles = structuredClone(INITIAL_PROFILES);
  const listings = structuredClone(INITIAL_LISTINGS);
  const policy = structuredClone(DEFAULT_SPENDING_POLICY);
  const escrowLedger = createEscrowLedger('borrowbondtest.testnet', 'borrowbondtest.testnet');
  const digitalGateway = createDigitalGatewayStore();

  const now = Date.now();
  const isoMinus2h = new Date(now - 2 * 3600 * 1000).toISOString();
  const isoMinus1h = new Date(now - 1 * 3600 * 1000).toISOString();
  const isoPlus46h = new Date(now + 46 * 3600 * 1000).toISOString();
  const isoPlus72h = new Date(now + 72 * 3600 * 1000).toISOString();

  // 1. Active Digital Booking
  createBookingOnContract(escrowLedger, {
    bookingId: 'bk-demo-weather-101',
    listingId: 'lst-dig-weather-01',
    listingTitle: 'AtmoNode Weather & Telemetry API',
    lender: 'atmo-telemetry.testnet',
    borrower: 'alex-builder.testnet',
    resourceType: 'DIGITAL',
    productIdentity: {
      brandAndModel: 'AtmoNode Enterprise v4 Gateway',
      tinOrSerialNumber: 'TIN-API-ATMO-9012',
      digitalAssetSubtype: 'API_COMPUTE',
      photosCount: 2,
      photosSha256Hash: '7d865e959b2466918c9863afca942d0fb89d7c9ac0c99bafc3749504ded97730',
      returnVerifiedSameItem: false,
    },
    durationCount: 48,
    durationUnit: 'HOURS',
    rentalFeeNear: 0.03,
    collateralNear: 0.05,
    attachedPaymentNear: 0.08,
    nowIso: isoMinus2h,
    acceptanceDeadlineIso: isoPlus46h,
    rentalStartIso: isoMinus1h,
    rentalEndIso: isoPlus46h,
    txHash: null,
    isSimulatedTx: true,
  });

  const activeDigitalBooking = acceptBookingOnContract(
    escrowLedger,
    'bk-demo-weather-101',
    'atmo-telemetry.testnet',
    isoMinus1h
  );

  const issued = issueTemporaryCredential(digitalGateway, {
    booking: activeDigitalBooking,
    callerWallet: 'alex-builder.testnet',
    quotaLimit: 20,
    durationHours: 48,
    endpointPath: '/api/demo-resource/weather',
    nowIso: isoMinus1h,
    DeterministicTokenOverride: 'bb_temp_demo101_a8f9c2e4b1d70395e6a1',
  });

  // 2. Active Physical Camera Booking with Anti-Scam TIN/Serial Registry
  createBookingOnContract(escrowLedger, {
    bookingId: 'bk-demo-camera-102',
    listingId: 'lst-phys-camera-01',
    listingTitle: 'Sony Alpha A1 Full-Frame Cinema Kit',
    lender: 'optics-lab.testnet',
    borrower: 'alex-builder.testnet',
    resourceType: 'PHYSICAL',
    productIdentity: {
      brandAndModel: 'Sony Alpha 1 (ILCE-1) + 24-70mm GM II',
      tinOrSerialNumber: 'SN-SONY-3849201-CH',
      photosCount: 3,
      photosSha256Hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      returnVerifiedSameItem: false,
    },
    durationCount: 3,
    durationUnit: 'DAYS',
    rentalFeeNear: 0.05,
    collateralNear: 0.2,
    attachedPaymentNear: 0.25,
    nowIso: isoMinus2h,
    acceptanceDeadlineIso: isoPlus46h,
    rentalStartIso: isoMinus1h,
    rentalEndIso: isoPlus72h,
    txHash: null,
    isSimulatedTx: true,
  });

  acceptBookingOnContract(escrowLedger, 'bk-demo-camera-102', 'optics-lab.testnet', isoMinus1h);
  confirmHandoverOnContract(escrowLedger, 'bk-demo-camera-102', 'optics-lab.testnet', isoMinus1h);
  confirmHandoverOnContract(escrowLedger, 'bk-demo-camera-102', 'alex-builder.testnet', isoMinus1h);

  const camBooking = escrowLedger.bookings['bk-demo-camera-102'];
  camBooking.evidence.push({
    id: 'ev-seed-1',
    bookingId: 'bk-demo-camera-102',
    uploaderWallet: 'optics-lab.testnet',
    stage: 'HANDOVER_BEFORE',
    fileReference: 'handover_sony_alpha_sensor_clean.jpg',
    contentSha256Hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    conditionNotes: 'Verified TIN/Serial SN-SONY-3849201-CH: Sensor clean, 24-70mm lens spotless.',
    timestampIso: isoMinus1h,
  });

  return {
    profiles,
    listings,
    policy,
    escrowLedger,
    digitalGateway,
    demoRawTokenForWeatherBooking: issued.rawTokenOnce,
  };
}
