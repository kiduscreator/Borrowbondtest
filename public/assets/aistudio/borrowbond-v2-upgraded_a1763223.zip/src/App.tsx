import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence, LayoutGroup } from 'motion/react';
import { Navbar, type AppView, type ThemeMode } from './components/Navbar';
import { LandingPage } from './views/LandingPage';
import { MarketplaceView } from './views/MarketplaceView';
import { ListingDetailsView } from './views/ListingDetailsView';
import { CreateListingWizard } from './views/CreateListingWizard';
import { AiAgentView } from './views/AiAgentView';
import { CheckoutView } from './views/CheckoutView';
import { DashboardView, type EnrichedCredential } from './views/DashboardView';
import { TransactionDetailsView } from './views/TransactionDetailsView';
import { WhitepaperDocsView, type DocsSectionTab } from './views/WhitepaperDocsView';
import { ThreeLineSideDrawer, type UnifiedUserSession } from './components/UnifiedAccountModals';
import { SignInGate } from './components/SignInGate';
import { ConnectWalletModal, type SessionState } from './components/ConnectWalletModal';
import { BorrowBondBrandLogo, SocialBrandIcon } from './components/TokenIcons';
import { ExternalLink } from 'lucide-react';

import type {
  MarketplaceListing,
  ProviderProfile,
  SpendingPolicy,
} from './lib/security/policyEngine';
import type { OnChainBooking } from './lib/near/escrowStateMachine';
import type { DigitalUsageEvent } from './lib/digital/accessGateway';
import type { AgentOrchestrationResponse, BookingDraft } from './lib/ai/agentTools';
import { runDeterministicBorrowingAgent } from './lib/ai/agentTools';
import { bootstrapDemoEnvironment } from './lib/database/seedData';

const INITIAL_DEMO_ENV = bootstrapDemoEnvironment();

const SESSION_STORAGE_KEY = 'borrowbond_unified_session_v1';
const THEME_STORAGE_KEY = 'borrowbond_theme_mode_v1';

const SIGNED_OUT_SESSION: UnifiedUserSession = {
  authenticated: false,
  onboardingCompleted: false,
  fullName: '',
  age: 0,
  bio: '',
  avatarUrl: '',
  email: '',
  authMethod: 'WALLET',
  walletAccountId: '',
  nearNetwork: 'testnet',
  connectorName: '',
};

export function App() {
  const [currentView, setCurrentView] = useState<AppView>('LANDING');
  const [docsSection, setDocsSection] = useState<DocsSectionTab>('WHITEPAPER');

  // Who is signed in is decided by the SERVER (signed cookie), never by this browser.
  const [serverSession, setServerSession] = useState<SessionState | null>(null);
  const [userSession, setUserSession] = useState<UnifiedUserSession>(SIGNED_OUT_SESSION);

  const loadSession = useCallback(async () => {
    try {
      const res = await fetch('/api/session');
      if (res.ok) setServerSession(await res.json());
    } catch {
      // offline: stay signed out
    }
  }, []);
  useEffect(() => {
    void loadSession();
  }, [loadSession]);

  const connectedWallet = serverSession?.account ?? '';

  // Modals & Drawers
  const [walletModalOpen, setWalletModalOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [sideDrawerOpen, setSideDrawerOpen] = useState(false);

  // Night / Day / System Theme State
  const [themeMode, setThemeMode] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY) as ThemeMode | null;
      if (saved === 'night' || saved === 'day' || saved === 'system') return saved;
    } catch {
      // Ignore
    }
    return 'night';
  });

  useEffect(() => {
    try {
      localStorage.setItem(THEME_STORAGE_KEY, themeMode);
    } catch {
      // Ignore
    }

    const applyResolvedTheme = () => {
      let resolved: 'night' | 'day' = 'night';
      if (themeMode === 'day') {
        resolved = 'day';
      } else if (themeMode === 'system') {
        const prefersLight =
          typeof window !== 'undefined' &&
          window.matchMedia &&
          window.matchMedia('(prefers-color-scheme: light)').matches;
        resolved = prefersLight ? 'day' : 'night';
      }
      document.documentElement.setAttribute('data-theme', resolved);
    };

    applyResolvedTheme();

    if (themeMode === 'system' && typeof window !== 'undefined' && window.matchMedia) {
      const mql = window.matchMedia('(prefers-color-scheme: light)');
      const listener = () => applyResolvedTheme();
      mql.addEventListener('change', listener);
      return () => mql.removeEventListener('change', listener);
    }
  }, [themeMode]);

  // Server state pre-seeded for zero-latency first paint and synchronized with backend /api/state
  const [nearBlockHeight, setNearBlockHeight] = useState<number | null>(null);
  const [nearUsdRate, setNearUsdRate] = useState<number>(3.7);
  const [nearUsdLive, setNearUsdLive] = useState<boolean>(false);
  const [displayCurrency, setDisplayCurrency] = useState<'NEAR' | 'USDT'>('USDT');
  const [contractAddress, setContractAddress] = useState('');
  const [designatedResolver, setDesignatedResolver] = useState('resolver.borrowbond.testnet');
  const [profiles, setProfiles] = useState<Record<string, ProviderProfile>>(INITIAL_DEMO_ENV.profiles);
  const [listings, setListings] = useState<MarketplaceListing[]>(INITIAL_DEMO_ENV.listings);
  const [policy, setPolicy] = useState<SpendingPolicy>(INITIAL_DEMO_ENV.policy);
  const [bookings, setBookings] = useState<OnChainBooking[]>(
    Object.values(INITIAL_DEMO_ENV.escrowLedger.bookings)
  );
  const [claimableBalancesNear, setClaimableBalancesNear] = useState<Record<string, number>>(
    INITIAL_DEMO_ENV.escrowLedger.claimableBalancesNear
  );
  const [myCredentials, setMyCredentials] = useState<EnrichedCredential[]>(
    Object.values(INITIAL_DEMO_ENV.digitalGateway.credentialsById).map((c) => ({
      ...c,
      authorizedRawToken: INITIAL_DEMO_ENV.demoRawTokenForWeatherBooking,
    }))
  );
  const [myUsageEvents, setMyUsageEvents] = useState<DigitalUsageEvent[]>([]);
  const [notifications, setNotifications] = useState<
    { id: string; title: string; message: string; timestampIso: string; bookingId?: string }[]
  >([]);

  // Navigation context state
  const [marketplaceCategory, setMarketplaceCategory] = useState<'ALL' | 'PHYSICAL' | 'DIGITAL'>('ALL');
  const [selectedListingId, setSelectedListingId] = useState<string>('lst-phys-camera-01');
  const [checkoutDurationCount, setCheckoutDurationCount] = useState<number>(3);
  const [selectedBookingId, setSelectedBookingId] = useState<string>('bk-demo-camera-102');
  const [agentPromptSeed, setAgentPromptSeed] = useState<string>('');
  const [lastAgentResult, setLastAgentResult] = useState<AgentOrchestrationResponse | null>(null);

  const fetchState = useCallback(async (wallet = connectedWallet) => {
    try {
      const res = await fetch('/api/state');
      if (!res.ok) return;
      const data = await res.json();
      setNearBlockHeight(data.nearStatus?.latestBlockHeight ?? null);
      if (data.nearMarketPrice?.nearUsd) {
        setNearUsdRate(Number(data.nearMarketPrice.nearUsd));
        setNearUsdLive(Boolean(data.nearMarketPrice.live));
      }
      setContractAddress(data.contractAddress || '');
      setDesignatedResolver(data.designatedResolver || 'resolver.borrowbond.testnet');
      setProfiles(data.profiles || {});
      setListings(data.listings || []);
      if (data.policy) setPolicy(data.policy);
      setBookings(data.bookings || []);
      setClaimableBalancesNear(data.claimableBalancesNear || {});
      setMyCredentials(data.myDigitalCredentials || []);
      setMyUsageEvents(data.myDigitalUsageEvents || []);
      setNotifications(data.notifications || []);
    } catch {
      // Keep existing state on transient offline
    }
  }, [connectedWallet]);

  useEffect(() => {
    fetchState(connectedWallet);
  }, [connectedWallet, fetchState]);

  // Mirror the server session into the profile shown in the UI (names/avatars come from the profile, not the browser).
  useEffect(() => {
    const acct = serverSession?.account;
    if (!acct) {
      setUserSession(SIGNED_OUT_SESSION);
      return;
    }
    const prof = profiles[acct];
    setUserSession({
      authenticated: true,
      onboardingCompleted: true,
      fullName: prof?.displayName ?? acct.split('.')[0],
      age: prof?.age ?? 0,
      bio: prof?.bio ?? '',
      avatarUrl: prof?.avatarUrl ?? '',
      email: prof?.email ?? '',
      authMethod: 'WALLET',
      walletAccountId: acct,
      nearNetwork: 'testnet',
      connectorName: serverSession?.kind === 'demo' ? 'Demo persona (simulated)' : 'NEAR wallet (verified signature)',
    });
  }, [serverSession, profiles]);

  const handleSaveUnifiedSession = useCallback(
    async (updatedSession: UnifiedUserSession) => {
      setUserSession(updatedSession);

      // Sync with unified backend system (/api/user/profile)
      try {
        const res = await fetch('/api/user/profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            walletAccountId: updatedSession.walletAccountId,
            displayName: updatedSession.fullName,
            age: updatedSession.age,
            bio: updatedSession.bio,
            avatarUrl: updatedSession.avatarUrl,
            email: updatedSession.email,
            authMethod: updatedSession.authMethod,
            nearNetwork: updatedSession.nearNetwork,
          }),
        });
        if (res.ok) {
          await fetchState(updatedSession.walletAccountId);
        }
      } catch {
        // Keep local unified session on transient offline
      }
    },
    [fetchState]
  );

  const handleOpenDocsSection = (section: DocsSectionTab) => {
    setDocsSection(section);
    setCurrentView('WHITEPAPER');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenListing = (listingId: string) => {
    setSelectedListingId(listingId);
    setCurrentView('LISTING_DETAILS');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRunAgentPrompt = async (prompt: string) => {
    const immediateResult = runDeterministicBorrowingAgent(
      {
        callerWallet: connectedWallet,
        listings,
        profiles,
        policy,
        escrowLedger: INITIAL_DEMO_ENV.escrowLedger,
        digitalGateway: INITIAL_DEMO_ENV.digitalGateway,
        actionLogs: [],
        activeDrafts: {},
      },
      prompt
    );
    setLastAgentResult(immediateResult);

    try {
      const res = await fetch('/api/agent/assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callerWallet: connectedWallet,
          prompt,
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as AgentOrchestrationResponse;
        setLastAgentResult(data);
        await fetchState(connectedWallet);
      }
    } catch {
      // Keep immediate deterministic tool result if backend is still warming up
    }
  };

  const handleAskAgentFromHero = async (prompt: string) => {
    setAgentPromptSeed(prompt);
    setCurrentView('AI_AGENT');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    await handleRunAgentPrompt(prompt);
  };

  const handleUpdatePolicy = async (updated: Partial<SpendingPolicy>) => {
    const res = await fetch('/api/security/policy', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    });
    if (res.ok) {
      const data = await res.json();
      setPolicy(data.policy);
    }
  };

  const handleApproveDraftToCheckout = (draft: BookingDraft) => {
    setSelectedListingId(draft.listingId);
    setCheckoutDurationCount(draft.durationCount);
    setCurrentView('CHECKOUT');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleProceedToCheckout = (listingId: string, durationCount: number) => {
    setSelectedListingId(listingId);
    setCheckoutDurationCount(durationCount);
    setCurrentView('CHECKOUT');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleConfirmAndSignEscrow = async (params: {
    listingId: string;
    durationCount: number;
    explicitUserApproval: boolean;
  }) => {
    const res = await fetch('/api/bookings/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        listingId: params.listingId,
        borrowerWallet: connectedWallet,
        durationCount: params.durationCount,
        explicitUserApproval: params.explicitUserApproval,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to create on-chain booking');
    }
    await fetchState(connectedWallet);
    setSelectedBookingId(data.booking.bookingId);
    setCurrentView('TRANSACTION_DETAILS');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleWithdrawClaimable = async () => {
    await fetch('/api/escrow/withdraw', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ callerWallet: connectedWallet }),
    });
    await fetchState(connectedWallet);
  };

  const selectedListing =
    listings.find((l) => l.id === selectedListingId) || listings[0];
  const gate =
    !!serverSession &&
    !serverSession.account &&
    ['DASHBOARD', 'CREATE_LISTING', 'AI_AGENT', 'CHECKOUT', 'TRANSACTION_DETAILS'].includes(currentView);

  const selectedBooking =
    bookings.find((b) => b.bookingId === selectedBookingId) || bookings[0];

  return (
    <div className="min-h-screen flex flex-col bg-[#06080F] text-[#F5F8FF] pb-24">
      <Navbar
        currentView={currentView}
        onNavigate={(view) => {
          setCurrentView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        connectedWallet={connectedWallet}
        nearNetwork={userSession.nearNetwork}
        userDisplayName={userSession.fullName}
        userAvatarUrl={userSession.avatarUrl}
        onOpenWalletModal={() => setWalletModalOpen(true)}
        onOpenSideMenu={() => setSideDrawerOpen(true)}
        nearUsdRate={nearUsdRate}
        nearUsdLive={nearUsdLive}
        displayCurrency={displayCurrency}
        onToggleCurrency={setDisplayCurrency}
        themeMode={themeMode}
        onChangeThemeMode={setThemeMode}
      />

      {/* Main Content with Framer Motion Layout Animations */}
      <main className="flex-1 overflow-x-hidden">
        <LayoutGroup id="borrowbond-main-views">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={currentView === 'WHITEPAPER' ? `${currentView}-${docsSection}` : currentView}
              layout
              initial={{ opacity: 0, y: 12, scale: 0.992 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.992 }}
              transition={{
                duration: 0.2,
                ease: [0.22, 1, 0.36, 1],
                layout: { type: 'spring', stiffness: 360, damping: 34 },
              }}
              className="w-full"
            >
              {currentView === 'LANDING' && (
                <LandingPage
                  listings={listings}
                  nearBlockHeight={nearBlockHeight}
                  nearUsdRate={nearUsdRate}
                  nearUsdLive={nearUsdLive}
                  contractAddress={contractAddress}
                  onNavigate={(view) => {
                    setCurrentView(view);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onSelectCategory={(cat) => setMarketplaceCategory(cat)}
                  onOpenListing={handleOpenListing}
                  onAskAgent={handleAskAgentFromHero}
                  onOpenAuthModal={() => setAuthModalOpen(true)}
                  onOpenWalletModal={() => setWalletModalOpen(true)}
                  onOpenDocsSection={handleOpenDocsSection}
                />
              )}

              {currentView === 'WHITEPAPER' && (
                <WhitepaperDocsView
                  key={docsSection}
                  initialSection={docsSection}
                  nearUsdRate={nearUsdRate}
                  contractAddress={contractAddress}
                  connectedWallet={connectedWallet}
                  onNavigate={(view) => {
                    setCurrentView(view);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              )}

              {currentView === 'MARKETPLACE' && (
                <MarketplaceView
                  listings={listings}
                  profiles={profiles}
                  initialCategory={marketplaceCategory}
                  nearUsdRate={nearUsdRate}
                  displayCurrency={displayCurrency}
                  onToggleCurrency={setDisplayCurrency}
                  onOpenListing={handleOpenListing}
                  onNavigateCreate={() => setCurrentView('CREATE_LISTING')}
                  onOpenAiAgent={() => setCurrentView('AI_AGENT')}
                />
              )}

              {currentView === 'LISTING_DETAILS' && selectedListing && (
                <ListingDetailsView
                  listing={selectedListing}
                  provider={profiles[selectedListing.ownerWallet]}
                  borrowerProfile={profiles[connectedWallet]}
                  policy={policy}
                  nearUsdRate={nearUsdRate}
                  displayCurrency={displayCurrency}
                  onToggleCurrency={setDisplayCurrency}
                  onUpdatePolicy={handleUpdatePolicy}
                  onBack={() => setCurrentView('MARKETPLACE')}
                  onProceedToCheckout={handleProceedToCheckout}
                />
              )}

              {!gate && currentView === 'CREATE_LISTING' && (
                <CreateListingWizard
                  connectedWallet={connectedWallet}
                  nearUsdRate={nearUsdRate}
                  onChangeNearUsdRate={setNearUsdRate}
                  displayCurrency={displayCurrency}
                  onCreated={async (newListing) => {
                    setListings((prev) => [newListing, ...prev.filter((l) => l.id !== newListing.id)]);
                    await fetchState(connectedWallet);
                    setSelectedListingId(newListing.id);
                    setCurrentView('LISTING_DETAILS');
                  }}
                  onCancel={() => setCurrentView('MARKETPLACE')}
                />
              )}

              {!gate && currentView === 'AI_AGENT' && (
                <AiAgentView
                  connectedWallet={connectedWallet}
                  policy={policy}
                  initialPrompt={agentPromptSeed}
                  lastAgentResult={lastAgentResult}
                  onRunAgentPrompt={handleRunAgentPrompt}
                  onUpdatePolicy={handleUpdatePolicy}
                  onApproveDraftToCheckout={handleApproveDraftToCheckout}
                />
              )}

              {!gate && currentView === 'CHECKOUT' && selectedListing && (
                <CheckoutView
                  listing={selectedListing}
                  durationCount={checkoutDurationCount}
                  connectedWallet={connectedWallet}
                  contractAddress={contractAddress}
                  onBack={() => setCurrentView('LISTING_DETAILS')}
                  onConfirmAndSignEscrow={handleConfirmAndSignEscrow}
                />
              )}

              {gate && (
                <SignInGate
                  title="Sign in to continue"
                  onSignIn={() => setWalletModalOpen(true)}
                />
              )}
              {!gate && currentView === 'DASHBOARD' && (
                <DashboardView
                  connectedWallet={connectedWallet}
                  profile={profiles[connectedWallet]}
                  bookings={bookings}
                  listings={listings}
                  claimableBalancesNear={claimableBalancesNear}
                  myCredentials={myCredentials}
                  myUsageEvents={myUsageEvents}
                  notifications={notifications}
                  onOpenBookingDetails={(bookingId) => {
                    setSelectedBookingId(bookingId);
                    setCurrentView('TRANSACTION_DETAILS');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onOpenListing={handleOpenListing}
                  onWithdrawClaimable={handleWithdrawClaimable}
                  onRefreshState={() => fetchState(connectedWallet)}
                />
              )}

              {!gate && currentView === 'TRANSACTION_DETAILS' && selectedBooking && (
                <TransactionDetailsView
                  booking={selectedBooking}
                  connectedWallet={connectedWallet}
                  designatedResolver={designatedResolver}
                  onBack={() => setCurrentView('DASHBOARD')}
                  onRefreshState={() => fetchState(connectedWallet)}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </LayoutGroup>
      </main>

      {/* Luxury Footer with Official Brand Logo, Whitepaper/Roadmap/Terms & /Borrowbond Socials */}
      <footer className="border-t border-slate-800/80 bg-[#0D1322] px-4 sm:px-6 py-10 text-xs text-[#9BA8C0]">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <BorrowBondBrandLogo size={38} />
            <div className="space-y-0.5">
              <div className="font-bold font-display text-[#F5F8FF] text-sm">
                BorrowBond — Borrow anything. Secure every agreement.
              </div>
              <p>
                NEAR testnet prototype · Programmable escrow · Not audited
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <button
              type="button"
              onClick={() => handleOpenDocsSection('WHITEPAPER')}
              className="hover:text-[#00EC97] font-semibold cursor-pointer"
            >
              Whitepaper (4 Pages)
            </button>
            <button
              type="button"
              onClick={() => handleOpenDocsSection('ROADMAP')}
              className="hover:text-[#00EC97] font-semibold cursor-pointer"
            >
              Roadmap
            </button>
            <button
              type="button"
              onClick={() => handleOpenDocsSection('TERMS')}
              className="hover:text-[#00EC97] font-semibold cursor-pointer"
            >
              Terms & Agreements
            </button>
            <button
              type="button"
              onClick={() => handleOpenDocsSection('DEPLOYMENT')}
              className="hover:text-[#00EC97] font-semibold cursor-pointer"
            >
              Deploy & Testnet Guide
            </button>

            {/* Official /Borrowbond Social Links */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
              <a
                href="https://x.com/Borrowbond"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="BorrowBond on X (Twitter)"
                className="p-2 rounded-xl bg-[#06080F] border border-slate-800 hover:border-[#00EC97] text-[#F5F8FF] transition-colors"
                title="https://x.com/Borrowbond"
              >
                <SocialBrandIcon network="x" size={14} />
              </a>
              <a
                href="https://t.me/Borrowbond"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="BorrowBond on Telegram"
                className="p-2 rounded-xl bg-[#06080F] border border-slate-800 hover:border-[#17F1D1] text-[#17F1D1] transition-colors"
                title="https://t.me/Borrowbond"
              >
                <SocialBrandIcon network="telegram" size={14} />
              </a>
              <a
                href="https://linkedin.com/company/Borrowbond"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="BorrowBond on LinkedIn"
                className="p-2 rounded-xl bg-[#06080F] border border-slate-800 hover:border-[#00EC97] text-[#00EC97] transition-colors"
                title="https://linkedin.com/company/Borrowbond"
              >
                <SocialBrandIcon network="linkedin" size={14} />
              </a>
              <a
                href={
                  userSession.nearNetwork === 'mainnet'
                    ? 'https://nearblocks.io'
                    : 'https://testnet.nearblocks.io'
                }
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#00EC97] inline-flex items-center gap-1 ml-1"
              >
                <span>NEAR Explorer</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Sign in: real NEP-413 wallet signature, or a clearly labelled demo persona */}
      <ConnectWalletModal
        isOpen={walletModalOpen || authModalOpen}
        onClose={() => {
          setWalletModalOpen(false);
          setAuthModalOpen(false);
        }}
        session={serverSession}
        onSessionChanged={async () => {
          await loadSession();
        }}
        onOpenTerms={() => handleOpenDocsSection('TERMS')}
      />

      {/* 3. Compact Floating Three-Line (☰) Dropdown Menu:
          Platform, Resources/Whitepaper, Legal, Socials (/Borrowbond), Editable Profile & Wallet Info */}
      <ThreeLineSideDrawer
        isOpen={sideDrawerOpen}
        onClose={() => setSideDrawerOpen(false)}
        session={userSession}
        profile={profiles[connectedWallet]}
        contractAddress={contractAddress}
        designatedResolver={designatedResolver}
        nearUsdRate={nearUsdRate}
        themeMode={themeMode}
        onChangeThemeMode={setThemeMode}
        onSaveSession={handleSaveUnifiedSession}
        onOpenConnectWallet={() => {
          setSideDrawerOpen(false);
          setWalletModalOpen(true);
        }}
        onOpenAuthModal={() => {
          setSideDrawerOpen(false);
          setAuthModalOpen(true);
        }}
        onNavigateView={(view) => {
          setCurrentView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenDocsSection={handleOpenDocsSection}
      />
    </div>
  );
}

export default App;
