import React, { useEffect, useRef, useState } from 'react';
import { X, Wallet, FlaskConical, LogOut, ShieldCheck, Loader2 } from 'lucide-react';

export interface SessionState {
  account: string | null;
  kind: 'wallet' | 'demo' | null;
  demoModeEnabled: boolean;
  personas: { account: string; label: string; role: string }[];
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  session: SessionState | null;
  onSessionChanged: () => Promise<void> | void;
  onOpenTerms?: () => void;
}

async function post<T>(url: string, body?: unknown): Promise<T> {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
  return data as T;
}

/**
 * Real sign-in = a NEP-413 signature from the user's own NEAR testnet wallet, checked by the server.
 * Demo personas are simulated accounts and are labelled as such. Nothing here moves funds.
 */
export const ConnectWalletModal: React.FC<Props> = ({ isOpen, onClose, session, onSessionChanged, onOpenTerms }) => {
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const connectorRef = useRef<any>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    setError(null);
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const connectRealWallet = async () => {
    setBusy('wallet');
    setError(null);
    try {
      if (!connectorRef.current) {
        const { NearConnector } = await import('@hot-labs/near-connect');
        const c = new NearConnector({ network: 'testnet', features: { testnet: true }, footerBranding: null } as any);
        connectorRef.current = c;
        await (c as any).whenManifestLoaded;
      }
      const connector = connectorRef.current;
      const ch = await post<{ token: string; nonce: string; message: string; recipient: string }>('/api/auth/wallet/challenge');
      const wallet = await connector.connect();
      const accounts = await wallet.getAccounts({ network: 'testnet' });
      const accountId: string | undefined = accounts?.[0]?.accountId;
      if (!accountId) throw new Error('The wallet did not return an account.');
      const nonce = Uint8Array.from(atob(ch.nonce), (c) => c.charCodeAt(0));
      const signed = await wallet.signMessage({ message: ch.message, recipient: ch.recipient, nonce, network: 'testnet', signerId: accountId });
      await post('/api/auth/wallet/verify', { token: ch.token, accountId, publicKey: signed.publicKey, signature: signed.signature });
      await onSessionChanged();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not connect the wallet.');
    } finally {
      setBusy(null);
    }
  };

  const useDemo = async (account: string) => {
    setBusy(account);
    setError(null);
    try {
      await post('/api/session/demo', { account });
      await onSessionChanged();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not start the demo persona.');
    } finally {
      setBusy(null);
    }
  };

  const signOut = async () => {
    setBusy('logout');
    try {
      try { await connectorRef.current?.disconnect?.(); } catch { /* ignore */ }
      await post('/api/auth/logout');
      await onSessionChanged();
      onClose();
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4" role="presentation">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="connect-title"
        className="relative w-full sm:max-w-lg max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl border border-slate-700/70 bg-[#0B1020] p-5 sm:p-7 shadow-2xl"
      >
        <button
          ref={closeRef}
          onClick={onClose}
          aria-label="Close"
          className="absolute right-4 top-4 rounded-full p-2 text-[#9BA8C0] hover:bg-white/5 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00EC97]"
        >
          <X className="h-5 w-5" />
        </button>

        <h2 id="connect-title" className="text-xl font-bold text-[#F5F8FF]">Connect to BorrowBond</h2>
        <p className="mt-1 text-sm text-[#9BA8C0]">NEAR <strong className="text-[#00EC97]">testnet</strong> only. Signing in never moves funds.</p>

        {session?.account && (
          <div className="mt-5 flex items-center justify-between gap-3 rounded-2xl border border-[#00EC97]/30 bg-[#00EC97]/5 p-4">
            <div className="min-w-0">
              <div className="text-xs uppercase tracking-wider text-[#9BA8C0]">Signed in as</div>
              <div className="truncate font-mono text-sm text-[#F5F8FF]">{session.account}</div>
              <div className="mt-0.5 text-xs text-[#9BA8C0]">{session.kind === 'demo' ? 'Demo persona (simulated)' : 'Verified wallet signature'}</div>
            </div>
            <button
              onClick={signOut}
              disabled={busy !== null}
              className="inline-flex shrink-0 items-center gap-1.5 rounded-xl border border-slate-600 px-3 py-2 text-sm text-[#F5F8FF] hover:bg-white/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00EC97] disabled:opacity-50"
            >
              <LogOut className="h-4 w-4" /> Sign out
            </button>
          </div>
        )}

        <section className="mt-6" aria-labelledby="real-wallet">
          <h3 id="real-wallet" className="flex items-center gap-2 text-sm font-semibold text-[#F5F8FF]">
            <Wallet className="h-4 w-4 text-[#00EC97]" /> Real NEAR testnet wallet
          </h3>
          <p className="mt-1 text-sm text-[#9BA8C0]">
            You sign a free message in your own wallet. The server verifies the signature and checks on-chain that the key belongs to your account.
            A connected wallet proves you control that account, not who you are.
          </p>
          <button
            onClick={connectRealWallet}
            disabled={busy !== null}
            className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#00EC97] px-4 py-3 font-semibold text-[#04120C] hover:brightness-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-white disabled:opacity-60"
          >
            {busy === 'wallet' ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
            {busy === 'wallet' ? 'Waiting for your wallet…' : 'Connect testnet wallet'}
          </button>
        </section>

        {session?.demoModeEnabled && session.personas.length > 0 && (
          <section className="mt-7" aria-labelledby="demo-personas">
            <h3 id="demo-personas" className="flex items-center gap-2 text-sm font-semibold text-[#F5F8FF]">
              <FlaskConical className="h-4 w-4 text-amber-300" /> Try it with a demo persona
              <span className="rounded-full border border-amber-300/40 bg-amber-300/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-amber-200">Simulated</span>
            </h3>
            <p className="mt-1 text-sm text-[#9BA8C0]">
              Sample accounts with sample data. No wallet, no blockchain, no funds. Switch between them to walk through borrower, lender and resolver roles.
            </p>
            <ul className="mt-3 grid gap-2">
              {session.personas.map((p) => (
                <li key={p.account}>
                  <button
                    onClick={() => useDemo(p.account)}
                    disabled={busy !== null}
                    aria-current={session.account === p.account}
                    className="flex w-full flex-col items-start gap-1 rounded-xl border border-slate-700 bg-[#0D1322] px-4 py-3 text-left sm:flex-row sm:items-center sm:justify-between sm:gap-3 hover:border-[#00EC97]/50 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00EC97] disabled:opacity-60"
                  >
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold text-[#F5F8FF]">{p.label}</span>
                      <span className="block break-all font-mono text-xs text-[#9BA8C0]">{p.account}</span>
                    </span>
                    <span className="shrink-0 text-xs text-[#9BA8C0]">
                      {busy === p.account ? <Loader2 className="h-4 w-4 animate-spin" /> : p.role}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )}

        {error && (
          <p role="alert" className="mt-4 rounded-xl border border-red-400/40 bg-red-400/10 px-3 py-2 text-sm text-red-200">{error}</p>
        )}

        <p className="mt-6 text-xs text-[#6F7C96]">
          Prototype on NEAR testnet. Not audited. By continuing you accept the{' '}
          <button className="underline hover:text-[#00EC97]" onClick={() => { onOpenTerms?.(); onClose(); }}>terms</button>.
        </p>
      </div>
    </div>
  );
};
