import React, { useState, useEffect } from 'react';
import {
  X,
  Wallet,
  User,
  FileText,
  CheckCircle2,
  Upload,
  Sun,
  Moon,
  Monitor,
  LogIn,
  LogOut,
  ExternalLink,
  BookOpen,
  Milestone,
  Scale,
  Rocket,
  Compass,
  QrCode,
  Copy,
  Check,
  RefreshCw,
} from 'lucide-react';
import {
  BorrowBondBrandLogo,
  NearTokenIcon,
  UsdtTokenIcon,
  NearWalletConnectorIcon,
  SocialBrandIcon,
} from './TokenIcons';
import type { ProviderProfile } from '../lib/security/policyEngine';
import type { AppView, ThemeMode } from './Navbar';
import type { DocsSectionTab } from '../views/WhitepaperDocsView';

export interface UnifiedUserSession {
  authenticated: boolean;
  onboardingCompleted: boolean;
  fullName: string;
  age: number;
  bio: string;
  avatarUrl: string;
  email: string;
  authMethod: 'GOOGLE' | 'EMAIL' | 'WALLET';
  walletAccountId: string;
  nearNetwork: 'mainnet' | 'testnet';
  connectorName: string;
}

export const CURATED_NEAR_AVATARS = [
  `data:image/svg+xml;utf8,${encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">
      <defs>
        <linearGradient id="av1" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#00EC97"/>
          <stop offset="100%" stop-color="#0F172A"/>
        </linearGradient>
      </defs>
      <rect width="120" height="120" rx="60" fill="url(#av1)"/>
      <circle cx="60" cy="46" r="20" fill="#F8FAFC"/>
      <path d="M26 104C30 82 44 74 60 74C76 74 90 82 94 104" fill="#F8FAFC"/>
    </svg>
  `)}`,
  `data:image/svg+xml;utf8,${encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">
      <defs>
        <linearGradient id="av2" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#17F1D1"/>
          <stop offset="100%" stop-color="#1E1B4B"/>
        </linearGradient>
      </defs>
      <rect width="120" height="120" rx="60" fill="url(#av2)"/>
      <circle cx="60" cy="46" r="20" fill="#00EC97"/>
      <path d="M26 104C30 82 44 74 60 74C76 74 90 82 94 104" fill="#00EC97"/>
    </svg>
  `)}`,
  `data:image/svg+xml;utf8,${encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">
      <rect width="120" height="120" rx="60" fill="#0D1322"/>
      <circle cx="60" cy="60" r="54" stroke="#00EC97" stroke-width="4" fill="none"/>
      <text x="60" y="72" text-anchor="middle" fill="#00EC97" font-family="sans-serif" font-weight="800" font-size="38">N</text>
    </svg>
  `)}`,
];

// Sign-in and wallet connection live in ConnectWalletModal.tsx (real NEP-413 wallet sign-in + labelled demo personas).

interface ThreeLineSideDrawerProps {
  isOpen: boolean;
  session: UnifiedUserSession;
  profile?: ProviderProfile;
  contractAddress: string;
  designatedResolver: string;
  nearUsdRate: number;
  themeMode: ThemeMode;
  onChangeThemeMode: (mode: ThemeMode) => void;
  onSaveSession: (updated: UnifiedUserSession) => Promise<void>;
  onOpenConnectWallet: () => void;
  onOpenAuthModal: () => void;
  onNavigateView?: (view: AppView) => void;
  onOpenDocsSection?: (section: DocsSectionTab) => void;
  onClose: () => void;
}

export const ThreeLineSideDrawer: React.FC<ThreeLineSideDrawerProps> = ({
  isOpen,
  session,
  contractAddress,
  designatedResolver,
  nearUsdRate,
  themeMode,
  onChangeThemeMode,
  onSaveSession,
  onOpenConnectWallet,
  onOpenAuthModal,
  onNavigateView,
  onOpenDocsSection,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'MENU' | 'PROFILE' | 'WALLET'>('MENU');
  const [editName, setEditName] = useState(session.fullName);
  const [editAge, setEditAge] = useState(String(session.age));
  const [editBio, setEditBio] = useState(session.bio);
  const [editAvatar, setEditAvatar] = useState(session.avatarUrl);
  const [savedNotice, setSavedNotice] = useState(false);

  useEffect(() => {
    setEditName(session.fullName);
    setEditAge(String(session.age));
    setEditBio(session.bio);
    setEditAvatar(session.avatarUrl);
  }, [session]);

  if (!isOpen) return null;

  const handleSaveProfileInline = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveSession({
      ...session,
      fullName: editName.trim() || session.fullName,
      age: parseInt(editAge, 10) || session.age,
      bio: editBio.trim() || session.bio,
      avatarUrl: editAvatar,
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  const handleAvatarFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') setEditAvatar(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const goView = (view: AppView) => {
    onNavigateView?.(view);
    onClose();
  };

  const goDocs = (sec: DocsSectionTab) => {
    onOpenDocsSection?.(sec);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Account, Profile, Wallet & Agreements Menu"
      className="fixed inset-0 z-50 flex items-start justify-end bg-black/55 backdrop-blur-sm p-3 sm:p-5 pt-16 sm:pt-18"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="near-glow-card w-[min(94vw,395px)] max-h-[82vh] rounded-3xl p-5 overflow-y-auto flex flex-col justify-between space-y-4 border border-[#00EC97]/40 shadow-[0_24px_60px_rgba(0,0,0,0.85)]">
        <div className="space-y-4">
          {/* Compact Top Header */}
          <div className="flex items-center justify-between border-b border-slate-800/90 pb-3.5">
            <div className="flex items-center gap-2.5 min-w-0">
              <BorrowBondBrandLogo size={34} />
              <img
                src={session.avatarUrl}
                alt={session.fullName}
                className="w-8 h-8 rounded-full object-cover border border-[#00EC97]"
              />
              <div className="min-w-0">
                <h2 className="text-sm font-extrabold font-display text-[#F5F8FF] truncate">
                  {session.fullName}
                </h2>
                <code className="text-[11px] font-mono text-[#00EC97] block truncate">
                  {session.walletAccountId}
                </code>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Menu"
              className="p-1.5 rounded-xl bg-[#06080F] border border-slate-800 text-[#9BA8C0] hover:text-[#F5F8FF] cursor-pointer shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Theme Switcher */}
          <div className="flex items-center justify-between gap-2 px-3 py-2 rounded-2xl bg-[#06080F]/90 border border-slate-800">
            <span className="text-[11px] font-semibold text-[#9BA8C0]">Theme</span>
            <div className="flex items-center gap-1">
              {(
                [
                  { id: 'night', label: 'Night', icon: <Moon className="w-3 h-3" /> },
                  { id: 'day', label: 'Day', icon: <Sun className="w-3 h-3" /> },
                  { id: 'system', label: 'System', icon: <Monitor className="w-3 h-3" /> },
                ] as const
              ).map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => onChangeThemeMode(t.id)}
                  className={`py-1 px-2.5 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                    themeMode === t.id
                      ? 'bg-[#00EC97] text-[#04080E]'
                      : 'text-[#9BA8C0] hover:text-[#F5F8FF]'
                  }`}
                >
                  {t.icon}
                  <span>{t.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 3-Tab Switcher: Menu | Profile | Wallet Info */}
          <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-[#06080F] border border-slate-800 text-xs font-bold">
            <button
              type="button"
              onClick={() => setActiveTab('MENU')}
              className={`py-1.5 rounded-lg flex items-center justify-center gap-1 cursor-pointer ${
                activeTab === 'MENU' ? 'bg-[#00EC97] text-[#04080E]' : 'text-[#9BA8C0]'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Menu</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('PROFILE')}
              className={`py-1.5 rounded-lg flex items-center justify-center gap-1 cursor-pointer ${
                activeTab === 'PROFILE' ? 'bg-[#00EC97] text-[#04080E]' : 'text-[#9BA8C0]'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Profile</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('WALLET')}
              className={`py-1.5 rounded-lg flex items-center justify-center gap-1 cursor-pointer ${
                activeTab === 'WALLET' ? 'bg-[#00EC97] text-[#04080E]' : 'text-[#9BA8C0]'
              }`}
            >
              <Wallet className="w-3.5 h-3.5" />
              <span>Wallet Info</span>
            </button>
          </div>

          {activeTab === 'MENU' && (
            <div className="space-y-4 text-xs">
              <div className="space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#9BA8C0] px-2 block">
                  Platform
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => goView('MARKETPLACE')}
                    className="px-3 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800/90 hover:border-[#00EC97]/50 text-left font-bold text-[#F5F8FF] transition-colors cursor-pointer"
                  >
                    Marketplace
                  </button>
                  <button
                    type="button"
                    onClick={() => goView('AI_AGENT')}
                    className="px-3 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800/90 hover:border-[#00EC97]/50 text-left font-bold text-[#F5F8FF] transition-colors cursor-pointer"
                  >
                    AI Agent
                  </button>
                  <button
                    type="button"
                    onClick={() => goView('CREATE_LISTING')}
                    className="px-3 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800/90 hover:border-[#00EC97]/50 text-left font-bold text-[#F5F8FF] transition-colors cursor-pointer"
                  >
                    List Item
                  </button>
                  <button
                    type="button"
                    onClick={() => goView('DASHBOARD')}
                    className="px-3 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800/90 hover:border-[#00EC97]/50 text-left font-bold text-[#F5F8FF] transition-colors cursor-pointer"
                  >
                    Escrow & Deals
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#9BA8C0] px-2 block">
                  Resources & Whitepaper
                </span>
                <div className="space-y-1">
                  <button
                    type="button"
                    onClick={() => goDocs('WHITEPAPER')}
                    className="w-full px-3 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800/90 hover:border-[#00EC97]/50 flex items-center justify-between text-[#F5F8FF] font-semibold transition-colors cursor-pointer"
                  >
                    <span className="inline-flex items-center gap-2">
                      <BookOpen className="w-3.5 h-3.5 text-[#00EC97]" />
                      <span>Whitepaper (4 Pages)</span>
                    </span>
                    <span className="text-[10px] font-mono text-[#00EC97]">Read →</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => goDocs('ROADMAP')}
                    className="w-full px-3 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800/90 hover:border-[#00EC97]/50 flex items-center justify-between text-[#F5F8FF] font-semibold transition-colors cursor-pointer"
                  >
                    <span className="inline-flex items-center gap-2">
                      <Milestone className="w-3.5 h-3.5 text-[#17F1D1]" />
                      <span>Roadmap</span>
                    </span>
                    <span className="text-[10px] font-mono text-[#17F1D1]">4 Phases →</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => goDocs('DEPLOYMENT')}
                    className="w-full px-3 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800/90 hover:border-[#00EC97]/50 flex items-center justify-between text-[#F5F8FF] font-semibold transition-colors cursor-pointer"
                  >
                    <span className="inline-flex items-center gap-2">
                      <Rocket className="w-3.5 h-3.5 text-[#00EC97]" />
                      <span>Deploy & Testnet Guide</span>
                    </span>
                    <span className="text-[10px] font-mono text-[#00EC97]">Guide →</span>
                  </button>
                  <a
                    href={`https://${session.nearNetwork === 'mainnet' ? '' : 'testnet.'}nearblocks.io/address/${contractAddress}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full px-3 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800/90 hover:border-[#00EC97]/50 flex items-center justify-between text-[#F5F8FF] font-semibold transition-colors"
                  >
                    <span className="inline-flex items-center gap-2">
                      <NearTokenIcon size={14} />
                      <span>NEAR Blockchain Explorer</span>
                    </span>
                    <ExternalLink className="w-3 h-3 text-[#9BA8C0]" />
                  </a>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#9BA8C0] px-2 block">
                  Legal & Policies
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => goDocs('TERMS')}
                    className="px-3 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800/90 hover:border-[#00EC97]/50 text-left font-semibold text-[#F5F8FF] flex items-center gap-1.5 cursor-pointer"
                  >
                    <Scale className="w-3.5 h-3.5 text-[#00EC97] shrink-0" />
                    <span className="truncate">Terms & Policy</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => goDocs('TERMS')}
                    className="px-3 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800/90 hover:border-[#00EC97]/50 text-left font-semibold text-[#F5F8FF] flex items-center gap-1.5 cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-[#17F1D1] shrink-0" />
                    <span className="truncate">Escrow Rules</span>
                  </button>
                </div>
              </div>

              <div className="space-y-1.5 pt-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#9BA8C0] px-2 block">
                  Social • /Borrowbond
                </span>
                <div className="grid grid-cols-3 gap-1.5">
                  <a
                    href="https://x.com/Borrowbond"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2.5 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800 hover:border-[#00EC97] text-[#F5F8FF] font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <SocialBrandIcon network="x" size={13} />
                    <span>X</span>
                  </a>
                  <a
                    href="https://t.me/Borrowbond"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2.5 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800 hover:border-[#17F1D1] text-[#F5F8FF] font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <SocialBrandIcon network="telegram" size={13} />
                    <span>Telegram</span>
                  </a>
                  <a
                    href="https://linkedin.com/company/Borrowbond"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2.5 py-2 rounded-xl bg-[#06080F]/90 border border-slate-800 hover:border-[#00EC97] text-[#F5F8FF] font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <SocialBrandIcon network="linkedin" size={13} />
                    <span>LinkedIn</span>
                  </a>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'PROFILE' && (
            <form onSubmit={handleSaveProfileInline} className="space-y-3">
              <div className="flex items-center gap-3">
                <img
                  src={editAvatar}
                  alt="Avatar preview"
                  className="w-12 h-12 rounded-full object-cover border border-[#00EC97]"
                />
                <label className="btn-near-secondary px-3 py-1.5 text-xs cursor-pointer">
                  <Upload className="w-3.5 h-3.5 text-[#00EC97]" />
                  <span>Change Avatar</span>
                  <input type="file" accept="image/*" onChange={handleAvatarFile} className="hidden" />
                </label>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="block text-[11px] font-semibold text-[#9BA8C0] mb-1">Full Name</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-[#06080F] border border-slate-800 rounded-xl text-[#F5F8FF]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-[#9BA8C0] mb-1">Age</label>
                  <input
                    type="number"
                    value={editAge}
                    onChange={(e) => setEditAge(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs font-mono bg-[#06080F] border border-slate-800 rounded-xl text-[#F5F8FF]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#9BA8C0] mb-1">
                  Biography
                </label>
                <textarea
                  rows={2}
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-[#06080F] border border-slate-800 rounded-xl text-[#F5F8FF]"
                />
              </div>

              {savedNotice && (
                <div className="p-2 rounded-xl bg-[#00EC97]/15 border border-[#00EC97]/40 text-xs text-[#00EC97] flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Profile saved!</span>
                </div>
              )}

              <button type="submit" className="btn-near-primary w-full py-2 text-xs">
                <CheckCircle2 className="w-4 h-4" />
                <span>Save Profile</span>
              </button>
            </form>
          )}

          {activeTab === 'WALLET' && (
            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-2xl bg-[#06080F]/90 border border-slate-800 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-[#9BA8C0]">Connected Wallet</span>
                  <code className="font-mono font-bold text-[#00EC97]">{session.walletAccountId}</code>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#9BA8C0]">Network</span>
                  <span className="font-mono font-bold uppercase text-[#F5F8FF]">
                    NEAR {session.nearNetwork}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#9BA8C0]">Connector</span>
                  <span className="font-semibold text-[#F5F8FF]">{session.connectorName}</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-slate-800">
                  <span className="text-[#9BA8C0] flex items-center gap-1">
                    <NearTokenIcon size={14} />
                    <span>Live NEAR / USDT</span>
                  </span>
                  <span className="font-mono font-bold text-[#00EC97] flex items-center gap-1">
                    <UsdtTokenIcon size={14} />
                    <span>${nearUsdRate.toFixed(2)} USDT</span>
                  </span>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#06080F]/90 border border-slate-800 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-[#9BA8C0]">Escrow Contract:</span>
                  <code className="font-mono text-[#F5F8FF]">{contractAddress}</code>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9BA8C0]">BorrowBond Team:</span>
                  <code className="font-mono text-[#F5F8FF]">{designatedResolver}</code>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenConnectWallet();
                }}
                className="btn-near-secondary w-full py-2 text-xs"
              >
                <Wallet className="w-3.5 h-3.5 text-[#00EC97]" />
                <span>Switch NEAR Wallet</span>
              </button>
            </div>
          )}
        </div>

        <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenAuthModal();
            }}
            className="btn-near-secondary flex-1 py-2 text-xs"
          >
            <LogIn className="w-3.5 h-3.5 text-[#00EC97]" />
            <span>Sign In / Up</span>
          </button>
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenConnectWallet();
            }}
            className="btn-near-primary px-3 py-2 text-xs"
          >
            <span>Connect</span>
          </button>
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenAuthModal();
            }}
            className="p-2 rounded-xl bg-[#F87171]/15 text-[#F87171] hover:bg-[#F87171]/25 cursor-pointer"
            title="Switch Account"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
