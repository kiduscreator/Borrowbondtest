import React from 'react';
import { Lock, Wallet } from 'lucide-react';

/** Shown instead of pages that act on behalf of an account until the server confirms who is signed in. */
export const SignInGate: React.FC<{ title: string; onSignIn: () => void }> = ({ title, onSignIn }) => (
  <section className="mx-auto flex max-w-xl flex-col items-center px-6 py-24 text-center" aria-labelledby="gate-title">
    <div className="mb-5 grid h-14 w-14 place-items-center rounded-2xl border border-[#00EC97]/30 bg-[#00EC97]/10">
      <Lock className="h-6 w-6 text-[#00EC97]" aria-hidden="true" />
    </div>
    <h1 id="gate-title" className="text-2xl font-bold text-[#F5F8FF]">{title}</h1>
    <p className="mt-2 text-[#9BA8C0]">
      Connect a NEAR testnet wallet, or pick a clearly labelled demo persona to explore with sample data. Nothing is paid or signed by signing in.
    </p>
    <button
      onClick={onSignIn}
      className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#00EC97] px-5 py-3 font-semibold text-[#04120C] hover:brightness-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
    >
      <Wallet className="h-4 w-4" aria-hidden="true" /> Connect or choose a demo persona
    </button>
  </section>
);
