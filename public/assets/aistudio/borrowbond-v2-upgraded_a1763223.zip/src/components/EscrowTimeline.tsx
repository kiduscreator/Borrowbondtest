import React, { useEffect, useState } from 'react';
import { Check, Circle, Clock, Gavel, XCircle } from 'lucide-react';
import type { OnChainBooking, BookingStatus } from '../lib/near/escrowStateMachine';
import type { ViewerRole } from './MoneyFlow';

const PATH: { status: BookingStatus; label: string }[] = [
  { status: 'REQUESTED', label: 'Requested' },
  { status: 'ACCEPTED', label: 'Accepted' },
  { status: 'ACTIVE', label: 'Active' },
  { status: 'RETURN_REQUESTED', label: 'Return requested' },
  { status: 'COMPLETED', label: 'Completed' },
];
const ORDER: Record<string, number> = { REQUESTED: 0, ACCEPTED: 1, ACTIVE: 2, RETURN_REQUESTED: 3, COMPLETED: 4, RESOLVED: 4 };

function useNow(intervalMs = 30_000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

export function countdown(targetIso: string, now: number): string {
  const ms = new Date(targetIso).getTime() - now;
  if (!Number.isFinite(ms)) return '';
  if (ms <= 0) return 'deadline passed';
  const m = Math.floor(ms / 60_000);
  const d = Math.floor(m / 1440);
  const h = Math.floor((m % 1440) / 60);
  const mm = m % 60;
  return d > 0 ? `${d}d ${h}h left` : h > 0 ? `${h}h ${mm}m left` : `${mm}m left`;
}

/** Who must act next, in plain words, for this viewer. */
export function nextStep(b: OnChainBooking, role: ViewerRole, now: number): { actor: string; text: string; deadline?: string } {
  const me = (who: 'lender' | 'borrower' | 'both') => (who === 'both' ? (role === 'lender' || role === 'borrower' ? 'You and the other party' : 'Lender and borrower') : role === who ? 'You' : who === 'lender' ? 'The lender' : 'The borrower');
  switch (b.status) {
    case 'REQUESTED':
      return { actor: me('lender'), text: 'must accept or reject this request. If nobody responds before the deadline, it expires and the borrower is refunded in full.', deadline: countdown(b.acceptanceDeadlineIso, now) };
    case 'ACCEPTED':
      return b.resourceType === 'PHYSICAL'
        ? { actor: me('both'), text: `confirm the handover (lender ${b.lenderHandoverConfirmed ? 'done' : 'pending'}, borrower ${b.borrowerHandoverConfirmed ? 'done' : 'pending'}). The rental starts when both confirm.` }
        : { actor: me('lender'), text: 'activates access. A temporary credential is issued to the borrower.' };
    case 'ACTIVE':
      return { actor: me('borrower'), text: 'uses the item or access, then requests the return.', deadline: countdown(b.rentalEndIso, now) };
    case 'RETURN_REQUESTED':
      return { actor: me('both'), text: `confirm the return (lender ${b.lenderReturnConfirmed ? 'done' : 'pending'}, borrower ${b.borrowerReturnConfirmed ? 'done' : 'pending'}). Either side can open a dispute instead.` };
    case 'DISPUTED':
      return { actor: 'The designated resolver', text: 'reviews the evidence from both sides and splits the frozen funds, with a written note.' };
    case 'COMPLETED': return { actor: 'Nobody', text: 'The agreement is settled. Fee paid to the lender, collateral returned to the borrower.' };
    case 'RESOLVED': return { actor: 'Nobody', text: 'The dispute was resolved by the human resolver. See the settlement note.' };
    case 'CANCELLED': return { actor: 'Nobody', text: 'Cancelled before the rental began. The borrower was refunded in full.' };
    case 'EXPIRED': return { actor: 'Nobody', text: 'The lender did not respond in time. The borrower was refunded in full.' };
  }
}

export const EscrowTimeline: React.FC<{ booking: OnChainBooking; viewerRole: ViewerRole }> = ({ booking, viewerRole }) => {
  const now = useNow();
  const s = booking.status;
  const branched = s === 'DISPUTED' || s === 'RESOLVED' || s === 'CANCELLED' || s === 'EXPIRED';
  const idx = ORDER[s] ?? (s === 'DISPUTED' ? 2 : -1);
  const step = nextStep(booking, viewerRole, now);

  return (
    <section aria-labelledby="timeline-title" className="rounded-2xl border border-slate-800 bg-[#172338] p-5">
      <h2 id="timeline-title" className="font-display text-lg font-bold text-[#F3F6FC]">Escrow progress</h2>

      <ol className="mt-4 grid grid-cols-5 gap-1" aria-label="Booking progress">
        {PATH.map((p, i) => {
          const done = !branched ? i < idx || s === 'COMPLETED' : s === 'RESOLVED' ? i <= 2 || false : i < idx;
          const current = !branched && i === idx && s !== 'COMPLETED';
          return (
            <li key={p.status} aria-current={current ? 'step' : undefined} className="flex flex-col items-center gap-1.5 text-center">
              <span className={`grid h-8 w-8 place-items-center rounded-full border text-xs ${done ? 'border-[#00EC97] bg-[#00EC97] text-[#04120C]' : current ? 'border-[#00EC97] bg-[#00EC97]/10 text-[#00EC97] shadow-[0_0_18px_-4px_rgba(0,236,151,0.8)]' : 'border-slate-600 text-slate-500'}`}>
                {done ? <Check className="h-4 w-4" aria-hidden="true" /> : current ? <Clock className="h-4 w-4" aria-hidden="true" /> : <Circle className="h-3 w-3" aria-hidden="true" />}
              </span>
              <span className={`text-[10px] leading-tight sm:text-xs ${done || current ? 'text-[#F3F6FC]' : 'text-[#7C8AA5]'}`}>
                {p.label}
                <span className="sr-only">{done ? ' (done)' : current ? ' (current step)' : ' (upcoming)'}</span>
              </span>
            </li>
          );
        })}
      </ol>

      {branched && (
        <div className={`mt-4 flex items-center gap-2 rounded-xl border px-3 py-2 text-sm ${s === 'DISPUTED' ? 'border-red-400/40 bg-red-400/10 text-red-100' : s === 'RESOLVED' ? 'border-[#00EC97]/40 bg-[#00EC97]/10 text-[#D1FAE5]' : 'border-amber-300/40 bg-amber-300/10 text-amber-100'}`}>
          {s === 'DISPUTED' || s === 'RESOLVED' ? <Gavel className="h-4 w-4" aria-hidden="true" /> : <XCircle className="h-4 w-4" aria-hidden="true" />}
          <span>{s === 'DISPUTED' ? 'Disputed: funds frozen' : s === 'RESOLVED' ? 'Resolved by the human resolver' : s === 'CANCELLED' ? 'Cancelled: refunded' : 'Expired: refunded'}</span>
        </div>
      )}

      <div className="mt-4 rounded-xl border border-slate-700/70 bg-[#0D1322]/70 p-4" aria-live="polite">
        <div className="text-xs font-semibold uppercase tracking-wider text-[#9BA8C0]">What happens next</div>
        <p className="mt-1 text-sm text-[#F3F6FC]">
          <strong className="text-[#5EEAD4]">{step.actor}</strong> {step.text}
        </p>
        {step.deadline && <p className="mt-1 font-mono text-xs text-amber-200">{step.deadline}</p>}
      </div>
    </section>
  );
};
