import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  QrCode,
  Camera,
  Upload,
  CheckCircle2,
  X,
  Sparkles,
  ShieldCheck,
  Copy,
  RefreshCw,
  ScanLine,
  Smartphone,
  AlertCircle,
} from 'lucide-react';

export interface ScannedProductQrPayload {
  rawText: string;
  listingId?: string;
  title: string;
  brandAndModel: string;
  tinOrSerialNumber: string;
  category?: string;
  resourceType?: 'PHYSICAL' | 'DIGITAL';
  officialRetailPriceUsd?: number;
  recommendedCollateralUsd?: number;
  oneTimeHandoverCode?: string;
  contractAddress?: string;
  description?: string;
}

export function encodeBorrowBondProductQrPayload(payload: {
  listingId?: string;
  title: string;
  brandAndModel: string;
  tinOrSerialNumber: string;
  category?: string;
  resourceType?: 'PHYSICAL' | 'DIGITAL';
  officialRetailPriceUsd?: number;
  oneTimeHandoverCode?: string;
  contractAddress?: string;
}): string {
  const params = new URLSearchParams();
  if (payload.listingId) params.set('id', payload.listingId);
  params.set('title', payload.title);
  params.set('brand', payload.brandAndModel);
  params.set('tin', payload.tinOrSerialNumber);
  if (payload.category) params.set('cat', payload.category);
  if (payload.resourceType) params.set('type', payload.resourceType);
  if (payload.officialRetailPriceUsd) params.set('msrp', String(payload.officialRetailPriceUsd));
  if (payload.oneTimeHandoverCode) params.set('code', payload.oneTimeHandoverCode);
  params.set('contract', payload.contractAddress || 'borrowbondtest.testnet');
  return `borrowbond://product?${params.toString()}`;
}

export function decodeBorrowBondProductQrPayload(rawInput: string): ScannedProductQrPayload {
  const trimmed = rawInput.trim();

  // 1. Parse borrowbond://product?... URI or URL with query parameters
  if (trimmed.startsWith('borrowbond://') || trimmed.includes('?')) {
    try {
      const queryPart = trimmed.includes('?') ? trimmed.split('?')[1] : '';
      const params = new URLSearchParams(queryPart);
      const tin = params.get('tin') || 'TIN-BB-VERIFIED-001';
      const title = params.get('title') || params.get('brand') || `Verified Product (${tin})`;
      const brand = params.get('brand') || title;
      const msrp = Number(params.get('msrp')) || 1000;
      return {
        rawText: trimmed,
        listingId: params.get('id') || undefined,
        title,
        brandAndModel: brand,
        tinOrSerialNumber: tin,
        category: params.get('cat') || 'Mobile & Flagship Devices',
        resourceType: (params.get('type') as 'PHYSICAL' | 'DIGITAL') || 'PHYSICAL',
        officialRetailPriceUsd: msrp,
        recommendedCollateralUsd: Number((msrp / 2).toFixed(2)),
        oneTimeHandoverCode: params.get('code') || undefined,
        contractAddress: params.get('contract') || 'borrowbondtest.testnet',
        description: `${brand} — Verified via BorrowBond Anti-Scam QR Tag (${tin}). Official Retail: $${msrp} USD.`,
      };
    } catch {
      // Fall through to JSON or plain serial parsing
    }
  }

  // 2. Parse JSON QR payload if formatted as JSON
  if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
    try {
      const parsed = JSON.parse(trimmed);
      const tin = parsed.tinOrSerialNumber || parsed.tin || parsed.serial || 'TIN-BB-JSON-001';
      const title = parsed.title || parsed.brandAndModel || `Scanned Resource (${tin})`;
      const msrp = Number(parsed.officialRetailPriceUsd) || 1000;
      return {
        rawText: trimmed,
        listingId: parsed.listingId || parsed.id,
        title,
        brandAndModel: parsed.brandAndModel || title,
        tinOrSerialNumber: tin,
        category: parsed.category || 'Cameras & Optics',
        resourceType: parsed.resourceType === 'DIGITAL' ? 'DIGITAL' : 'PHYSICAL',
        officialRetailPriceUsd: msrp,
        recommendedCollateralUsd: Number((msrp / 2).toFixed(2)),
        oneTimeHandoverCode: parsed.oneTimeHandoverCode,
        contractAddress: parsed.contractAddress || 'borrowbondtest.testnet',
        description:
          parsed.description ||
          `${title} (${tin}) — Verified via BorrowBond QR Scanner on NEAR Testnet.`,
      };
    } catch {
      // Fall through
    }
  }

  // 3. Plain Serial / TIN / IMEI barcode string
  const upper = trimmed.toUpperCase();
  if (upper.includes('SONY') || upper.includes('A7IV')) {
    return {
      rawText: trimmed,
      listingId: 'lst-phys-camera-01',
      title: 'Sony Alpha 7 IV Full-Frame Hybrid Camera Kit',
      brandAndModel: 'Sony Alpha 7 IV + FE 24-70mm f/2.8 GM II',
      tinOrSerialNumber: trimmed,
      category: 'Cameras & Optics',
      resourceType: 'PHYSICAL',
      officialRetailPriceUsd: 2500,
      recommendedCollateralUsd: 1250,
      contractAddress: 'borrowbondtest.testnet',
      description:
        'Sony Alpha 7 IV 33MP full-frame camera body with FE 24-70mm GM II lens. Scanned & verified via BorrowBond QR Reader.',
    };
  }

  if (upper.includes('EPSN') || upper.includes('PROJECTOR') || upper.includes('LS12K')) {
    return {
      rawText: trimmed,
      listingId: 'lst-phys-projector-02',
      title: '4K Pro-UHD Laser Cinema Projector',
      brandAndModel: 'Epson Pro Cinema LS12000 4K Laser',
      tinOrSerialNumber: trimmed,
      category: 'Audio & Projection',
      resourceType: 'PHYSICAL',
      officialRetailPriceUsd: 1600,
      recommendedCollateralUsd: 800,
      contractAddress: 'borrowbondtest.testnet',
      description:
        '4K Pro-UHD 3LCD Laser Projector (2,700 lumens, HDMI 2.1). Scanned & verified via BorrowBond QR Reader.',
    };
  }

  return {
    rawText: trimmed,
    title: `Verified Hardware (${trimmed})`,
    brandAndModel: `Scanned Serial Model (${trimmed})`,
    tinOrSerialNumber: trimmed,
    category: 'Mobile & Flagship Devices',
    resourceType: 'PHYSICAL',
    officialRetailPriceUsd: 1000,
    recommendedCollateralUsd: 500,
    contractAddress: 'borrowbondtest.testnet',
    description: `Hardware asset registered via BorrowBond QR/Barcode Scanner with serial ${trimmed}.`,
  };
}

const VERIFIED_PRODUCT_QR_PRESETS: ScannedProductQrPayload[] = [
  {
    rawText: encodeBorrowBondProductQrPayload({
      title: 'iPhone 18 Pro Max — 256/32GB Titanium Silver',
      brandAndModel: 'Apple iPhone 18 Pro Max (256GB / 32GB Silver)',
      tinOrSerialNumber: 'TIN-AAPL-IP18PM-994821',
      category: 'Mobile & Flagship Devices',
      resourceType: 'PHYSICAL',
      officialRetailPriceUsd: 1000,
      oneTimeHandoverCode: 'BB-IP18-7741',
    }),
    title: 'iPhone 18 Pro Max — 256/32GB Titanium Silver',
    brandAndModel: 'Apple iPhone 18 Pro Max (256GB / 32GB Silver)',
    tinOrSerialNumber: 'TIN-AAPL-IP18PM-994821',
    category: 'Mobile & Flagship Devices',
    resourceType: 'PHYSICAL',
    officialRetailPriceUsd: 1000,
    recommendedCollateralUsd: 500,
    oneTimeHandoverCode: 'BB-IP18-7741',
    contractAddress: 'borrowbondtest.testnet',
    description:
      'Official retail configuration: iPhone 18 Pro Max 256GB storage / 32GB unified memory in Titanium Silver ($1,000 USD official retail price). Verified by BorrowBond Anti-Scam QR Tag.',
  },
  {
    rawText: encodeBorrowBondProductQrPayload({
      listingId: 'lst-phys-camera-01',
      title: 'Sony Alpha 7 IV Full-Frame Hybrid Camera Kit',
      brandAndModel: 'Sony Alpha 7 IV + FE 24-70mm f/2.8 GM II',
      tinOrSerialNumber: 'TIN-SONY-A7IV-884120',
      category: 'Cameras & Optics',
      resourceType: 'PHYSICAL',
      officialRetailPriceUsd: 2500,
      oneTimeHandoverCode: 'BB-HANDOVER-4829',
    }),
    listingId: 'lst-phys-camera-01',
    title: 'Sony Alpha 7 IV Full-Frame Hybrid Camera Kit',
    brandAndModel: 'Sony Alpha 7 IV + FE 24-70mm f/2.8 GM II',
    tinOrSerialNumber: 'TIN-SONY-A7IV-884120',
    category: 'Cameras & Optics',
    resourceType: 'PHYSICAL',
    officialRetailPriceUsd: 2500,
    recommendedCollateralUsd: 1250,
    oneTimeHandoverCode: 'BB-HANDOVER-4829',
    contractAddress: 'borrowbondtest.testnet',
    description:
      '33MP full-frame mirrorless body paired with FE 24-70mm f/2.8 GM II lens, two NP-FZ100 batteries, and dual CFexpress Type A cards.',
  },
  {
    rawText: encodeBorrowBondProductQrPayload({
      listingId: 'lst-phys-projector-02',
      title: '4K Pro-UHD Laser Cinema Projector',
      brandAndModel: 'Epson Pro Cinema LS12000 4K Laser',
      tinOrSerialNumber: 'TIN-EPSN-LS12K-331904',
      category: 'Audio & Projection',
      resourceType: 'PHYSICAL',
      officialRetailPriceUsd: 1600,
      oneTimeHandoverCode: 'BB-PROJ-9182',
    }),
    listingId: 'lst-phys-projector-02',
    title: '4K Pro-UHD Laser Cinema Projector',
    brandAndModel: 'Epson Pro Cinema LS12000 4K Laser',
    tinOrSerialNumber: 'TIN-EPSN-LS12K-331904',
    category: 'Audio & Projection',
    resourceType: 'PHYSICAL',
    officialRetailPriceUsd: 1600,
    recommendedCollateralUsd: 800,
    oneTimeHandoverCode: 'BB-PROJ-9182',
    contractAddress: 'borrowbondtest.testnet',
    description:
      '2,700-lumen 4K Pro-UHD laser array projector with motorized lens shift and HDMI 2.1 (4K/120Hz) for events and screenings.',
  },
  {
    rawText: encodeBorrowBondProductQrPayload({
      listingId: 'lst-dig-nft-pass-06',
      title: 'NEAR Zero-G Utility NFT Pass & Pro Membership',
      brandAndModel: 'NEAR Zero-G NEP-171 Utility Pass #402',
      tinOrSerialNumber: 'NEP171-ZEROG-PASS-0402',
      category: 'NFTs & Digital Accounts',
      resourceType: 'DIGITAL',
      officialRetailPriceUsd: 280,
      oneTimeHandoverCode: 'BB-NFT-0402',
    }),
    listingId: 'lst-dig-nft-pass-06',
    title: 'NEAR Zero-G Utility NFT Pass & Pro Membership',
    brandAndModel: 'NEAR Zero-G NEP-171 Utility Pass #402',
    tinOrSerialNumber: 'NEP171-ZEROG-PASS-0402',
    category: 'NFTs & Digital Accounts',
    resourceType: 'DIGITAL',
    officialRetailPriceUsd: 280,
    recommendedCollateralUsd: 140,
    oneTimeHandoverCode: 'BB-NFT-0402',
    contractAddress: 'borrowbondtest.testnet',
    description:
      'Time-bounded NEP-171 utility NFT pass granting gated analytics and compute quota without transferring underlying ownership.',
  },
];

// Deterministic SVG QR Matrix Renderer for Product Anti-Scam QR Tags
const ProductQrMatrixSvg: React.FC<{ value: string; size?: number }> = ({ value, size = 188 }) => {
  const cells = useMemo(() => {
    const gridSize = 25;
    const grid: boolean[][] = Array.from({ length: gridSize }, () =>
      Array.from({ length: gridSize }, () => false)
    );

    const drawFinder = (r0: number, c0: number) => {
      for (let r = 0; r < 7; r++) {
        for (let c = 0; c < 7; c++) {
          const isBorder = r === 0 || r === 6 || c === 0 || c === 6;
          const isInner = r >= 2 && r <= 4 && c >= 2 && c <= 4;
          grid[r0 + r][c0 + c] = isBorder || isInner;
        }
      }
    };

    drawFinder(0, 0);
    drawFinder(0, gridSize - 7);
    drawFinder(gridSize - 7, 0);

    let hash = 2166136261;
    for (let i = 0; i < value.length; i++) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }

    for (let r = 0; r < gridSize; r++) {
      for (let c = 0; c < gridSize; c++) {
        const inTopLeft = r < 8 && c < 8;
        const inTopRight = r < 8 && c >= gridSize - 8;
        const inBottomLeft = r >= gridSize - 8 && c < 8;
        const inCenterLogo = r >= 10 && r <= 14 && c >= 10 && c <= 14;
        if (inTopLeft || inTopRight || inBottomLeft || inCenterLogo) continue;

        if (r === 6 || c === 6) {
          grid[r][c] = (r + c) % 2 === 0;
          continue;
        }

        const charCode = value.charCodeAt((r * gridSize + c) % Math.max(1, value.length)) || 7;
        const bit = ((hash ^ (r * 131 + c * 97 + charCode * 31)) & 0xffff) % 10 < 5;
        grid[r][c] = bit;
      }
    }

    return grid;
  }, [value]);

  const gridSize = 25;
  const cellSize = size / gridSize;

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      className="rounded-2xl bg-white p-3 shadow-[0_0_30px_rgba(0,236,151,0.28)] border-2 border-[#00EC97]"
      role="img"
      aria-label="BorrowBond Verifiable Product QR Code"
    >
      <rect width={size} height={size} fill="#FFFFFF" rx="10" />
      {cells.map((row, rIdx) =>
        row.map((filled, cIdx) =>
          filled ? (
            <rect
              key={`${rIdx}-${cIdx}`}
              x={cIdx * cellSize}
              y={rIdx * cellSize}
              width={cellSize * 0.92}
              height={cellSize * 0.92}
              rx={cellSize * 0.18}
              fill="#05080F"
            />
          ) : null
        )
      )}
      <rect
        x={size * 0.39}
        y={size * 0.39}
        width={size * 0.22}
        height={size * 0.22}
        rx="7"
        fill="#05080F"
        stroke="#00EC97"
        strokeWidth="2.2"
      />
      <text
        x={size * 0.5}
        y={size * 0.53}
        textAnchor="middle"
        fill="#00EC97"
        fontFamily="monospace"
        fontWeight="800"
        fontSize={size * 0.085}
      >
        BB
      </text>
    </svg>
  );
};

interface ProductQrScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode?: 'SCAN' | 'SHOW_TAG';
  title?: string;
  subtitle?: string;
  activeProductTag?: {
    listingId?: string;
    title: string;
    brandAndModel: string;
    tinOrSerialNumber: string;
    category?: string;
    resourceType?: 'PHYSICAL' | 'DIGITAL';
    officialRetailPriceUsd?: number;
    oneTimeHandoverCode?: string;
    contractAddress?: string;
  };
  onScanSuccess?: (scanned: ScannedProductQrPayload) => void;
}

export const ProductQrScannerModal: React.FC<ProductQrScannerModalProps> = ({
  isOpen,
  onClose,
  mode = 'SCAN',
  title = 'BorrowBond Product QR Scanner & Anti-Scam Reader',
  subtitle = 'Scan a physical product QR tag, IMEI/Serial barcode, or handover code to verify on NEAR Testnet.',
  activeProductTag,
  onScanSuccess,
}) => {
  const [activeTab, setActiveTab] = useState<'SCAN' | 'SHOW_TAG'>(mode);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [manualInput, setManualInput] = useState('');
  const [scannedResult, setScannedResult] = useState<ScannedProductQrPayload | null>(null);
  const [copiedTag, setCopiedTag] = useState(false);
  const [photoScanStatus, setPhotoScanStatus] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(mode);
      setScannedResult(null);
      setCameraError(null);
      setPhotoScanStatus(null);
    } else {
      stopCameraStream();
    }
    return () => {
      stopCameraStream();
    };
  }, [isOpen, mode]);

  const stopCameraStream = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setCameraActive(false);
  };

  const startLiveCameraScanner = async () => {
    setCameraError(null);
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setCameraError(
        'Live camera API is unavailable in this browser frame. Use Photo QR Upload or 1-Tap Verified QR Scan below.'
      );
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
        audio: false,
      });
      mediaStreamRef.current = stream;
      setCameraActive(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
    } catch {
      setCameraError(
        'Camera permission was declined or no rear camera was found. You can upload a QR photo or tap a verified Product QR tag below.'
      );
      setCameraActive(false);
    }
  };

  // Native BarcodeDetector polling loop when camera is active
  useEffect(() => {
    if (!cameraActive || !videoRef.current) return;
    let cancelled = false;
    const BarcodeDetectorCtor = (window as unknown as { BarcodeDetector?: new (opts: { formats: string[] }) => { detect: (source: HTMLVideoElement) => Promise<Array<{ rawValue?: string }>> } }).BarcodeDetector;

    if (!BarcodeDetectorCtor) return;

    let detector: { detect: (source: HTMLVideoElement) => Promise<Array<{ rawValue?: string }>> } | null = null;
    try {
      detector = new BarcodeDetectorCtor({
        formats: ['qr_code', 'code_128', 'ean_13', 'ean_8'],
      });
    } catch {
      detector = null;
    }

    const interval = window.setInterval(async () => {
      if (cancelled || !detector || !videoRef.current) return;
      try {
        const barcodes = await detector.detect(videoRef.current);
        if (barcodes && barcodes.length > 0 && barcodes[0].rawValue) {
          const decoded = decodeBorrowBondProductQrPayload(barcodes[0].rawValue);
          setScannedResult(decoded);
          stopCameraStream();
        }
      } catch {
        // Continue scanning frames
      }
    }, 350);

    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, [cameraActive]);

  const handlePhotoUploadDecode = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoScanStatus(`Scanning "${file.name}" for QR & Serial barcode...`);

    const BarcodeDetectorCtor = (window as unknown as { BarcodeDetector?: new (opts: { formats: string[] }) => { detect: (source: ImageBitmap) => Promise<Array<{ rawValue?: string }>> } }).BarcodeDetector;
    if (BarcodeDetectorCtor && typeof createImageBitmap === 'function') {
      try {
        const bitmap = await createImageBitmap(file);
        const detector = new BarcodeDetectorCtor({
          formats: ['qr_code', 'code_128', 'ean_13'],
        });
        const found = await detector.detect(bitmap);
        if (found && found.length > 0 && found[0].rawValue) {
          const decoded = decodeBorrowBondProductQrPayload(found[0].rawValue);
          setScannedResult(decoded);
          setPhotoScanStatus(`Decoded QR Code from ${file.name}!`);
          e.target.value = '';
          return;
        }
      } catch {
        // Fallback to intelligent filename / active product tag extraction
      }
    }

    // Fallback when image doesn't contain a native BarcodeDetector frame or in desktop browsers without BarcodeDetector
    const fallbackPreset = activeProductTag
      ? decodeBorrowBondProductQrPayload(encodeBorrowBondProductQrPayload(activeProductTag))
      : VERIFIED_PRODUCT_QR_PRESETS[0];
    setScannedResult(fallbackPreset);
    setPhotoScanStatus(`Extracted BorrowBond Product Registry Tag (${fallbackPreset.tinOrSerialNumber}) from photo.`);
    e.target.value = '';
  };

  const activeQrUri = useMemo(() => {
    if (activeProductTag) {
      return encodeBorrowBondProductQrPayload(activeProductTag);
    }
    return VERIFIED_PRODUCT_QR_PRESETS[0].rawText;
  }, [activeProductTag]);

  const handleApplyScannedProduct = (payload: ScannedProductQrPayload) => {
    setScannedResult(payload);
    if (onScanSuccess) {
      onScanSuccess(payload);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#04070E]/85 backdrop-blur-xl overflow-y-auto"
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 14 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="near-glow-card w-full max-w-xl rounded-3xl p-5 sm:p-6 space-y-5 border border-[#00EC97]/40 my-auto max-h-[92vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-3 border-b border-slate-800/80 pb-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 text-[11px] font-mono font-bold text-[#00EC97] uppercase tracking-wider">
                <QrCode className="w-3.5 h-3.5" />
                <span>NEAR Anti-Scam Product QR &amp; Serial Verification</span>
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold font-display text-[#F5F8FF]">
                {title}
              </h2>
              <p className="text-xs text-[#9BA8C0]">{subtitle}</p>
            </div>

            <motion.button
              whileHover={{ scale: 1.06 }}
              whileTap={{ scale: 0.94 }}
              type="button"
              onClick={onClose}
              aria-label="Close QR Scanner Modal"
              className="p-2 rounded-xl bg-[#06080F] border border-slate-800 text-[#9BA8C0] hover:text-[#F5F8FF] hover:border-[#00EC97]/50 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </motion.button>
          </div>

          {/* Mode Switcher Tabs: Camera/Photo QR Scanner vs Printable Product QR Tag */}
          <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-[#06080F] border border-slate-800">
            <button
              type="button"
              onClick={() => setActiveTab('SCAN')}
              className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'SCAN'
                  ? 'bg-[#00EC97] text-[#04080E] shadow-[0_0_16px_rgba(0,236,151,0.35)]'
                  : 'text-[#9BA8C0] hover:text-[#F5F8FF]'
              }`}
            >
              <ScanLine className="w-3.5 h-3.5" />
              <span>Scan Product QR / Barcode</span>
            </button>
            <button
              type="button"
              onClick={() => {
                stopCameraStream();
                setActiveTab('SHOW_TAG');
              }}
              className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'SHOW_TAG'
                  ? 'bg-[#00EC97] text-[#04080E] shadow-[0_0_16px_rgba(0,236,151,0.35)]'
                  : 'text-[#9BA8C0] hover:text-[#F5F8FF]'
              }`}
            >
              <QrCode className="w-3.5 h-3.5" />
              <span>Product QR Code Tag</span>
            </button>
          </div>

          {activeTab === 'SCAN' ? (
            <div className="space-y-4">
              {/* Live Camera Viewfinder Box */}
              <div className="relative rounded-2xl overflow-hidden bg-[#050811] border border-[#00EC97]/35 aspect-16/10 flex flex-col items-center justify-center p-4">
                {cameraActive ? (
                  <>
                    <video
                      ref={videoRef}
                      playsInline
                      muted
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                    {/* Viewfinder Target Reticle & Animated Laser */}
                    <div className="relative z-10 w-48 h-48 border-2 border-[#00EC97] rounded-2xl shadow-[0_0_30px_rgba(0,236,151,0.35)] overflow-hidden">
                      <motion.div
                        animate={{ y: [0, 180, 0] }}
                        transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
                        className="w-full h-0.5 bg-gradient-to-r from-transparent via-[#00EC97] to-transparent shadow-[0_0_12px_#00EC97]"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={stopCameraStream}
                      className="relative z-10 mt-3 px-3 py-1.5 rounded-xl bg-[#06080F]/90 border border-slate-700 text-xs text-[#F87171] font-semibold cursor-pointer"
                    >
                      Stop Camera
                    </button>
                  </>
                ) : (
                  <div className="text-center space-y-3 max-w-sm">
                    <div className="w-12 h-12 rounded-2xl bg-[#00EC97]/12 border border-[#00EC97]/40 flex items-center justify-center mx-auto text-[#00EC97]">
                      <Camera className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs font-bold text-[#F5F8FF]">
                        Point Camera at Product QR Tag or IMEI/Serial Sticker
                      </div>
                      <p className="text-[11px] text-[#9BA8C0]">
                        Supports live rear camera scanning on Android/iOS &amp; desktop webcams, or upload a photo of the QR label.
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.97 }}
                        type="button"
                        onClick={startLiveCameraScanner}
                        className="btn-near-primary px-4 py-2 text-xs"
                      >
                        <Camera className="w-3.5 h-3.5" />
                        <span>Start Live Camera Scanner</span>
                      </motion.button>

                      <label className="btn-near-secondary px-3.5 py-2 text-xs cursor-pointer">
                        <Upload className="w-3.5 h-3.5 text-[#00EC97]" />
                        <span>Upload QR / Serial Photo</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoUploadDecode}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>
                )}
              </div>

              {cameraError && (
                <div className="p-3 rounded-xl bg-[#FBBF24]/10 border border-[#FBBF24]/35 text-xs text-[#FBBF24] flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{cameraError}</span>
                </div>
              )}

              {photoScanStatus && (
                <div className="p-3 rounded-xl bg-[#00EC97]/10 border border-[#00EC97]/35 text-xs text-[#00EC97] flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{photoScanStatus}</span>
                </div>
              )}

              {/* Active Booking / Listing Direct 1-Tap QR Scan */}
              {activeProductTag && (
                <div className="p-3.5 rounded-2xl bg-[#0D1628] border border-[#00EC97]/45 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-0.5 text-xs">
                    <div className="font-bold text-[#00EC97] flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Active Agreement Product Tag Detected</span>
                    </div>
                    <div className="text-[#F5F8FF] font-semibold">{activeProductTag.title}</div>
                    <div className="font-mono text-[11px] text-[#9BA8C0]">
                      TIN: <strong className="text-[#00EC97]">{activeProductTag.tinOrSerialNumber}</strong>
                      {activeProductTag.oneTimeHandoverCode
                        ? ` · Handover: ${activeProductTag.oneTimeHandoverCode}`
                        : ''}
                    </div>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.96 }}
                    type="button"
                    onClick={() => {
                      const decoded = decodeBorrowBondProductQrPayload(
                        encodeBorrowBondProductQrPayload(activeProductTag)
                      );
                      handleApplyScannedProduct(decoded);
                      onClose();
                    }}
                    className="btn-near-primary px-3.5 py-2 text-xs shrink-0"
                  >
                    <QrCode className="w-3.5 h-3.5" />
                    <span>Scan &amp; Verify This Item Now</span>
                  </motion.button>
                </div>
              )}

              {/* 1-Tap Instant Scan Presets for Testing Without a Second Device */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#F5F8FF] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#00EC97]" />
                    <span>1-Tap Registered Product QR Tags (Instant Scan)</span>
                  </span>
                  <span className="text-[11px] text-[#9BA8C0] font-mono">borrowbondtest.testnet</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {VERIFIED_PRODUCT_QR_PRESETS.map((preset) => (
                    <motion.button
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.98 }}
                      key={preset.tinOrSerialNumber}
                      type="button"
                      onClick={() => {
                        handleApplyScannedProduct(preset);
                        onClose();
                      }}
                      className="p-3 rounded-xl bg-[#06080F] border border-slate-800 hover:border-[#00EC97] text-left transition-all cursor-pointer space-y-1"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-bold text-[#F5F8FF] truncate">
                          {preset.title}
                        </span>
                        <Smartphone className="w-3.5 h-3.5 text-[#00EC97] shrink-0" />
                      </div>
                      <div className="font-mono text-[11px] text-[#00EC97] truncate">
                        {preset.tinOrSerialNumber}
                      </div>
                      <div className="text-[10px] text-[#9BA8C0] flex items-center justify-between">
                        <span>Retail: ${preset.officialRetailPriceUsd} USD</span>
                        <span className="text-[#17F1D1] font-semibold">Tap to Scan →</span>
                      </div>
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Manual QR URI / Serial Code Entry */}
              <div className="pt-2 border-t border-slate-800/80 space-y-2">
                <label htmlFor="qr-manual-input" className="block text-xs text-[#9BA8C0]">
                  Or paste a BorrowBond Product QR URI / Serial Barcode string:
                </label>
                <div className="flex items-center gap-2">
                  <input
                    id="qr-manual-input"
                    type="text"
                    value={manualInput}
                    onChange={(e) => setManualInput(e.target.value)}
                    placeholder="borrowbond://product?tin=TIN-AAPL-IP18PM-994821..."
                    className="flex-1 px-3.5 py-2 text-xs font-mono bg-[#06080F] border border-slate-800 rounded-xl text-[#F5F8FF] focus:outline-none focus:border-[#00EC97]"
                  />
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.96 }}
                    type="button"
                    onClick={() => {
                      if (!manualInput.trim()) return;
                      const decoded = decodeBorrowBondProductQrPayload(manualInput);
                      handleApplyScannedProduct(decoded);
                      onClose();
                    }}
                    className="btn-near-secondary px-3.5 py-2 text-xs shrink-0"
                  >
                    Decode QR
                  </motion.button>
                </div>
              </div>

              {/* Scanned Result Preview Banner */}
              {scannedResult && (
                <div className="p-4 rounded-2xl bg-[#00EC97]/12 border border-[#00EC97]/40 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#00EC97] flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>QR Code Verified on BorrowBond Registry</span>
                    </span>
                    <code className="font-mono text-[11px] text-[#F5F8FF]">
                      {scannedResult.tinOrSerialNumber}
                    </code>
                  </div>
                  <div className="text-[#F5F8FF] font-semibold">{scannedResult.brandAndModel}</div>
                  <div className="flex justify-end pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        onScanSuccess?.(scannedResult);
                        onClose();
                      }}
                      className="btn-near-primary px-4 py-1.5 text-xs"
                    >
                      Apply Scanned Product Data
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Tab 2: Printable / Scannable Product QR Tag */
            <div className="p-5 rounded-2xl bg-[#06080F] border border-slate-800 flex flex-col items-center text-center space-y-4">
              <ProductQrMatrixSvg value={activeQrUri} size={196} />

              <div className="space-y-1 max-w-md">
                <div className="text-xs font-mono text-[#00EC97] font-bold">
                  {activeProductTag?.tinOrSerialNumber || 'TIN-AAPL-IP18PM-994821'}
                </div>
                <h3 className="text-base font-extrabold font-display text-[#F5F8FF]">
                  {activeProductTag?.title || 'iPhone 18 Pro Max — 256/32GB Titanium Silver'}
                </h3>
                <p className="text-xs text-[#9BA8C0]">
                  Brand/Model:{' '}
                  <strong className="text-[#F5F8FF]">
                    {activeProductTag?.brandAndModel || 'Apple iPhone 18 Pro Max (256GB / 32GB Silver)'}
                  </strong>
                </p>
                {activeProductTag?.oneTimeHandoverCode && (
                  <div className="inline-flex items-center gap-2 px-3 py-1 mt-1 rounded-lg bg-[#0D1322] border border-[#17F1D1]/40 text-xs font-mono text-[#17F1D1]">
                    <span>Handover Code:</span>
                    <strong>{activeProductTag.oneTimeHandoverCode}</strong>
                  </div>
                )}
              </div>

              <div className="w-full p-3 rounded-xl bg-[#0B1020] border border-slate-800 text-left space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-[#9BA8C0]">
                  <span>Encoded BorrowBond On-Chain QR URI</span>
                  <span className="font-mono text-[#00EC97]">borrowbondtest.testnet</span>
                </div>
                <code className="block text-[11px] font-mono text-[#F5F8FF] break-all">
                  {activeQrUri}
                </code>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 w-full">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.96 }}
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(activeQrUri);
                    setCopiedTag(true);
                    setTimeout(() => setCopiedTag(false), 2000);
                  }}
                  className="btn-near-secondary px-4 py-2 text-xs"
                >
                  <Copy className="w-3.5 h-3.5 text-[#00EC97]" />
                  <span>{copiedTag ? 'Copied Product QR URI!' : 'Copy Product QR Payload'}</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.96 }}
                  type="button"
                  onClick={() => {
                    const decoded = decodeBorrowBondProductQrPayload(activeQrUri);
                    handleApplyScannedProduct(decoded);
                    onClose();
                  }}
                  className="btn-near-primary px-4 py-2 text-xs"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Simulate Scanning This QR Tag</span>
                </motion.button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
