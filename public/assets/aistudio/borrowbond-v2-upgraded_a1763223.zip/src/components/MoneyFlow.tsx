import React from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { ArrowRight, Landmark, Lock, UserRound, Store, ShieldAlert } from 'lucide-react';
import type { BookingStatus, SettlementRecord } from '../lib/near/escrowStateMachine';

export type ViewerRole = 'borrower' | 'lender' | 'resolver' | 'observer';

interface Props {
  status: BookingStatus | 'PREVIEW';
  rentalFeeNear: number;
  collateralNear: number;
  settlement?: SettlementRecord | null;
  viewerRole?: ViewerRole;
  simulated?: boolean;
}

const fmt = (n: number) => `${Number(n.toFixed(6))} NEAR`;

type Place = 'wallet' | 'escrow' | 'split' | 'refund' | 'frozen';

function placeFor(status: Props['status']): Place {
  switch (status) {
    case 'PREVIEW': return 'wallet';
    case 'COMPLETED':
    case 'RESOLVED': return 'split';
    case 'CANCELLED':
    case 'EXPIRED': return 'refund';
    case 'DISPUTED': return 'frozen';
    default: return 'escrow';
  }
}

/** One plain sentence about what happens to the money, written for whoever is looking. */
function explain(p: Props, place: Place): string {
  const { rentalFeeNear: fee, collateralNear: col, viewerRole: role = 'observer' } = p;
  const total = fmt(fee + col);
  if (place === 'wallet') return `Approving locks ${total} in escrow: ${fmt(fee)} rental fee plus ${fmt(col)} refundable collateral. Nothing moves until you approve and sign yourself.`;
  if (place === 'escrow') {
    if (role === 'lender') return `${total} is held by the escrow contract. You earn the ${fmt(fee)} fee when the item or access is returned and both sides confirm. The ${fmt(col)} collateral is only released to you if a human resolver decides it.`;
    return `${total} is held by the escrow contract. The ${fmt(fee)} fee goes to the lender and your ${fmt(col)} collateral comes back to you once the return is confirmed by both sides.`;
  }
  if (place === 'frozen') return `A dispute froze all ${total}. Neither side can withdraw it. A designated human resolver reviews the evidence and decides the split, with a written note.`;
  if (place === 'refund') return `The booking did not go ahead, so the full ${total} goes back to the borrower. Nobody earned a fee.`;
  const s = p.settlement;
  if (s) return `Settled. Lender receives ${fmt(s.lenderPayoutNear)} and the borrower receives ${fmt(s.borrowerRefundNear)}. ${s.resolutionNote ? `Note: ${s.resolutionNote}` : ''}`.trim();
  return `Settled: the ${fmt(fee)} fee went to the lender and the ${fmt(col)} collateral returned to the borrower.`;
}

const Station: React.FC<{ icon: React.ReactNode; label: string; sub?: string; active: boolean; tone?: 'ok' | 'warn' | 'bad' }> = ({ icon, label, sub, active, tone = 'ok' }) => {
  const ring = !active ? 'border-slate-700/70 opacity-60' : tone === 'bad' ? 'border-red-400/60 shadow-[0_0_24px_-6px_rgba(248,113,113,0.6)]' : tone === 'warn' ? 'border-amber-300/60' : 'border-[#00EC97]/60 shadow-[0_0_24px_-6px_rgba(0,236,151,0.7)]';
  return (
    <div className={`flex min-w-0 flex-1 flex-col items-center gap-1 rounded-2xl border bg-[#0D1322]/80 px-2 py-3 text-center transition ${ring}`} aria-current={active ? 'true' : undefined}>
      <span aria-hidden="true" className="text-[#00EC97]">{icon}</span>
      <span className="text-xs font-semibold text-[#F5F8FF]">{label}</span>
      {sub && <span className="text-[11px] leading-tight text-[#9BA8C0]">{sub}</span>}
    </div>
  );
};

export const MoneyFlow: React.FC<Props> = (props) => {
  const reduce = useReducedMotion();
  const { rentalFeeNear: fee, collateralNear: col, status, settlement } = props;
  const total = fee + col || 1;
  const feePct = Math.min(88, Math.max(12, (fee / total) * 100));
  const place = placeFor(status);
  const text = explain(props, place);
  const lenderGets = place === 'split' ? (settlement?.lenderPayoutNear ?? fee) : undefined;
  const borrowerGets = place === 'split' ? (settlement?.borrowerRefundNear ?? col) : place === 'refund' ? fee + col : undefined;

  return (
    <section aria-labelledby="money-flow-title" className="rounded-2xl border border-slate-800 bg-[#172338] p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 id="money-flow-title" className="font-display text-lg font-bold text-[#F3F6FC]">Where the money is</h2>
        <span className="font-mono text-sm text-[#5EEAD4]">{fmt(fee + col)} total</span>
      </div>

      <div
        role="img"
        aria-label={`Rental fee ${fmt(fee)} (goes to the lender) and refundable collateral ${fmt(col)} (returns to the borrower)`}
        className="mt-4 flex h-9 w-full overflow-hidden rounded-xl border border-slate-700/70"
      >
        <motion.div
          initial={reduce ? false : { width: 0 }}
          animate={{ width: `${feePct}%` }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="flex items-center justify-center bg-[#2DD4BF]/90 px-2 text-xs font-bold text-[#04201B]"
        >
          <span className="truncate">Fee {fmt(fee)}</span>
        </motion.div>
        <motion.div
          initial={reduce ? false : { width: 0 }}
          animate={{ width: `${100 - feePct}%` }}
          transition={{ duration: 0.7, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
          className="flex items-center justify-center bg-[#34D399]/30 px-2 text-xs font-bold text-[#D1FAE5]"
          style={{ backgroundImage: 'repeating-linear-gradient(135deg, transparent 0 8px, rgba(255,255,255,0.08) 8px 16px)' }}
        >
          <span className="truncate">Refundable collateral {fmt(col)}</span>
        </motion.div>
      </div>
      <div className="mt-1 flex justify-between text-[11px] text-[#9BA8C0]">
        <span>Fee: yours to pay, lender's to earn</span>
        <span>Collateral: a deposit, not a cost</span>
      </div>

      <div className="mt-5 flex items-stretch gap-1.5 sm:gap-2" aria-label="Money flow">
        <Station icon={<UserRound className="h-5 w-5" />} label="Borrower wallet" sub={place === 'wallet' ? 'Funds still yours' : place === 'refund' ? `Got back ${fmt(borrowerGets ?? 0)}` : place === 'split' ? `Got back ${fmt(borrowerGets ?? 0)}` : undefined} active={place === 'wallet' || place === 'refund'} />
        <ArrowRight aria-hidden="true" className="mt-8 h-4 w-4 shrink-0 text-[#9BA8C0]" />
        <Station icon={place === 'frozen' ? <ShieldAlert className="h-5 w-5" /> : <Lock className="h-5 w-5" />} label={place === 'frozen' ? 'Frozen in escrow' : 'Escrow contract'} sub={place === 'escrow' ? 'Held until return' : place === 'frozen' ? 'Awaiting resolver' : undefined} active={place === 'escrow' || place === 'frozen'} tone={place === 'frozen' ? 'bad' : 'ok'} />
        <ArrowRight aria-hidden="true" className="mt-8 h-4 w-4 shrink-0 text-[#9BA8C0]" />
        <Station icon={<Store className="h-5 w-5" />} label="Lender" sub={lenderGets !== undefined ? `Received ${fmt(lenderGets)}` : 'Earns the fee on return'} active={place === 'split'} />
      </div>

      <p className="mt-4 flex gap-2 text-sm leading-relaxed text-[#D6DEEC]">
        <Landmark aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-[#5EEAD4]" />
        <span>{text}</span>
      </p>
      {props.simulated && (
        <p className="mt-2 text-xs font-semibold uppercase tracking-wider text-amber-200">Simulated: no real blockchain transaction or funds</p>
      )}
    </section>
  );
};
