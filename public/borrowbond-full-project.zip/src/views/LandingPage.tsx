import React, { useState } from 'react';
import {
  Search,
  ArrowRight,
  ShieldCheck,
  Lock,
  Cpu,
  Camera,
  Sparkles,
  ChevronDown,
  Scale,
  KeyRound,
  UserCheck,
  Wallet,
  BookOpen,
  Milestone,
  CheckCircle2,
  Rocket,
  Fingerprint,
} from 'lucide-react';
import type { MarketplaceListing } from '../lib/security/policyEngine';
import type { AppView } from '../components/Navbar';
import type { DocsSectionTab } from './WhitepaperDocsView';
import { ROADMAP_PHASES } from './WhitepaperDocsView';
import { ResilientImage } from '../components/ResilientImage';
import {
  BorrowBondBrandLogo,
  NearTokenIcon,
  UsdtTokenIcon,
} from '../components/TokenIcons';

interface LandingPageProps {
  listings: MarketplaceListing[];
  nearBlockHeight: number | null;
  nearUsdRate?: number;
  contractAddress: string;
  onNavigate: (view: AppView) => void;
  onSelectCategory: (cat: 'ALL' | 'PHYSICAL' | 'DIGITAL') => void;
  onOpenListing: (listingId: string) => void;
  onAskAgent: (prompt: string) => void;
  onOpenAuthModal?: () => void;
  onOpenWalletModal?: () => void;
  onOpenDocsSection?: (section: DocsSectionTab) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  listings,
  nearBlockHeight,
  nearUsdRate = 3.7,
  contractAddress,
  onNavigate,
  onSelectCategory,
  onOpenListing,
  onAskAgent,
  onOpenAuthModal,
  onOpenWalletModal,
  onOpenDocsSection,
}) => {
  const [heroPrompt, setHeroPrompt] = useState(
    'I need a camera for three days. My total budget is 0.5 NEAR. Find a reliable offer with reasonable collateral.'
  );
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const handleHeroSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!heroPrompt.trim()) return;
    onAskAgent(heroPrompt.trim());
  };

  const featuredListings = listings.slice(0, 3);

  const faqs = [
    {
      q: 'How does NEAR escrow lock and release funds?',
      a: 'Rental Fee + Collateral are locked together in borrowbondtest.testnet. Neither lender nor borrower can unilaterally touch locked funds. Once the borrower confirms receipt and the lender confirms safe return, the contract pays the Rental Fee to the lender and refunds 100% of the Collateral to the borrower.',
    },
    {
      q: 'How does BorrowBond prevent product-swap scams?',
      a: 'Every listing stores the exact Brand & Model, TIN / Serial / IMEI / NFT Token ID, and SHA-256 hash of 2–10 photos on BorrowBond. Upon return, the lender verifies the returned serial matches the registered TIN before releasing collateral.',
    },
    {
      q: 'What happens if an item is damaged after the deadline?',
      a: 'The BorrowBond Team (borrowbondtest.testnet / resolver.borrowbond.testnet) reviews evidence with both parties and determines the exact damage cost. The smart contract deducts Rental Fee + Damage Cost for the lender and automatically refunds the remaining collateral to the borrower.',
    },
    {
      q: 'Can users lend digital products, accounts, NFTs, and APIs?',
      a: 'Yes. Users can lend physical hardware as well as Digital Accounts, NFTs, Digital Licenses, and metered APIs/GPUs under the same NEAR escrow and anti-scam verification rules.',
    },
  ];

  return (
    <div className="space-y-12 pb-14">
      {/* Live NEAR Network & Market Rate Bar */}
      <div className="bg-[#0D1322] border-b border-slate-800/80 px-4 sm:px-6 py-2.5 text-xs text-[#9BA8C0]">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 font-semibold text-[#00EC97]">
              <NearTokenIcon size={15} />
              <span>NEAR Protocol (Mainnet & Testnet)</span>
            </span>
            <span aria-hidden="true">·</span>
            <span>Contract: <code className="font-mono text-[#F5F8FF]">{contractAddress}</code></span>
            {nearBlockHeight && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">Block #{nearBlockHeight.toLocaleString()}</span>
              </>
            )}
          </div>
          <div className="flex items-center gap-3 font-mono">
            <span className="inline-flex items-center gap-1.5 text-[#00EC97] font-bold">
              <UsdtTokenIcon size={15} />
              <span>1 NEAR = ${nearUsdRate.toFixed(2)} USDT</span>
            </span>
          </div>
        </div>
      </div>

      {/* Section 1: Concise Luxury Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-2">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-[#0D1322] border border-[#00EC97]/35 text-xs font-mono font-bold tracking-wide text-[#00EC97]">
                <BorrowBondBrandLogo size={20} />
                <span>BORROWBOND • NEAR ESCROW PROTOCOL</span>
              </div>
              <h1
                className="font-display font-extrabold tracking-tight text-[#F5F8FF] leading-[1.08]"
                style={{ fontSize: 'clamp(2.1rem, 3.8vw, 3.4rem)', textWrap: 'balance' }}
              >
                Borrow physical gear, digital accounts &amp; NFTs on NEAR.
              </h1>
              <p className="text-sm sm:text-base text-[#9BA8C0] leading-relaxed max-w-xl">
                Lock 50% AI-benchmarked collateral in NEAR escrow, protect every item with TIN/Serial &amp; 2–10 photo hashes, and settle automatically upon verified return.
              </p>
            </div>

            {/* Natural-Language AI Search Bar */}
            <form
              onSubmit={handleHeroSearchSubmit}
              className="near-glass-card rounded-2xl p-4 space-y-2.5"
            >
              <label
                htmlFor="hero-ai-input"
                className="block text-xs font-medium text-[#9BA8C0]"
              >
                Ask the BorrowBond AI Agent to match listings &amp; calculate collateral:
              </label>
              <div className="flex flex-col sm:flex-row gap-2.5">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-[#9BA8C0] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="hero-ai-input"
                    type="text"
                    value={heroPrompt}
                    onChange={(e) => setHeroPrompt(e.target.value)}
                    placeholder="I need a camera for 3 days under 0.5 NEAR..."
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-[#06080F] border border-slate-800 rounded-xl text-[#F5F8FF] placeholder:text-slate-500 focus:outline-none focus:border-[#00EC97]"
                  />
                </div>
                <button
                  type="submit"
                  className="btn-near-primary px-5 py-2.5 text-sm whitespace-nowrap shrink-0"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Find Offers</span>
                </button>
              </div>
              <div className="flex flex-wrap items-center gap-2 pt-0.5 text-xs text-[#9BA8C0]">
                <span>Quick search:</span>
                <button
                  type="button"
                  onClick={() =>
                    setHeroPrompt(
                      'I need a camera for three days. My total budget is 0.5 NEAR. Find a reliable offer with reasonable collateral.'
                    )
                  }
                  className="underline hover:text-[#00EC97] cursor-pointer"
                >
                  3-Day Camera (0.5 NEAR)
                </button>
                <span aria-hidden="true">·</span>
                <button
                  type="button"
                  onClick={() =>
                    setHeroPrompt(
                      'I need a digital API for my project for two days. My total budget is 0.15 NEAR. Find the best option.'
                    )
                  }
                  className="underline hover:text-[#00EC97] cursor-pointer"
                >
                  48h Digital Access (0.15 NEAR)
                </button>
              </div>
            </form>

            {/* Primary CTAs */}
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() => onNavigate('MARKETPLACE')}
                className="btn-near-primary px-5 py-2.5 text-xs whitespace-nowrap shrink-0"
              >
                <span>Explore Marketplace</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => onNavigate('CREATE_LISTING')}
                className="btn-near-secondary px-4 py-2.5 text-xs whitespace-nowrap shrink-0"
              >
                <span>List Item / Digital Asset</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onOpenDocsSection) onOpenDocsSection('WHITEPAPER');
                  else onNavigate('WHITEPAPER');
                }}
                className="btn-near-secondary px-4 py-2.5 text-xs whitespace-nowrap shrink-0"
              >
                <BookOpen className="w-3.5 h-3.5 text-[#00EC97]" />
                <span>Whitepaper &amp; Terms</span>
              </button>
              {onOpenAuthModal && (
                <button
                  type="button"
                  onClick={onOpenAuthModal}
                  className="btn-near-secondary px-4 py-2.5 text-xs whitespace-nowrap shrink-0"
                >
                  <UserCheck className="w-3.5 h-3.5 text-[#00EC97]" />
                  <span>Sign In</span>
                </button>
              )}
              {onOpenWalletModal && (
                <button
                  type="button"
                  onClick={onOpenWalletModal}
                  className="btn-near-secondary px-4 py-2.5 text-xs whitespace-nowrap shrink-0"
                >
                  <Wallet className="w-3.5 h-3.5 text-[#17F1D1]" />
                  <span>Connect Wallet</span>
                </button>
              )}
            </div>
          </div>

          {/* Right Column: Two Concise Category Cards */}
          <div className="lg:col-span-5 grid grid-cols-1 gap-4">
            {/* Physical Marketplace Card */}
            <div className="near-glass-card rounded-2xl p-5 flex flex-col justify-between space-y-3">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-[#9BA8C0]">
                  <span>01 · Physical Belongings</span>
                  <Camera className="w-4 h-4 text-[#00EC97]" />
                </div>
                <h2 className="text-lg font-bold font-display text-[#F5F8FF]">
                  Hardware &amp; Flagship Devices
                </h2>
                <p className="text-xs text-[#9BA8C0] leading-relaxed">
                  iPhones, cameras, projectors &amp; drones. Protected by 50% collateral, TIN/IMEI serial registry, and 2–10 inspection photos.
                </p>
              </div>
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs text-[#9BA8C0] font-mono tabular-nums inline-flex items-center gap-1.5">
                  <NearTokenIcon size={14} />
                  <span>From 0.05 NEAR fee</span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    onSelectCategory('PHYSICAL');
                    onNavigate('MARKETPLACE');
                  }}
                  className="text-xs font-semibold text-[#00EC97] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Browse Hardware</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Digital Marketplace Card */}
            <div className="near-glass-card rounded-2xl p-5 flex flex-col justify-between space-y-3">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-[#9BA8C0]">
                  <span>02 · Digital Products, Accounts &amp; NFTs</span>
                  <Cpu className="w-4 h-4 text-[#17F1D1]" />
                </div>
                <h2 className="text-lg font-bold font-display text-[#F5F8FF]">
                  Accounts, NFTs, Licenses &amp; APIs
                </h2>
                <p className="text-xs text-[#9BA8C0] leading-relaxed">
                  Lend digital accounts, utility NFTs, software seats, GPU slots, and metered APIs with time-bound access and automatic revocation.
                </p>
              </div>
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs text-[#9BA8C0] font-mono tabular-nums inline-flex items-center gap-1.5">
                  <NearTokenIcon size={14} />
                  <span>From 0.03 NEAR fee</span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    onSelectCategory('DIGITAL');
                    onNavigate('MARKETPLACE');
                  }}
                  className="text-xs font-semibold text-[#17F1D1] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Browse Digital</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: Featured Marketplace Listings */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <p className="text-xs text-[#00EC97] font-mono uppercase">Verified Catalog</p>
            <h2 className="text-xl font-bold font-display text-[#F5F8FF] mt-0.5">
              Featured Physical &amp; Digital Listings
            </h2>
          </div>
          <button
            type="button"
            onClick={() => {
              onSelectCategory('ALL');
              onNavigate('MARKETPLACE');
            }}
            className="text-xs font-semibold text-[#00EC97] hover:underline flex items-center gap-1.5 cursor-pointer"
          >
            <span>View All {listings.length} Listings</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {featuredListings.map((item) => {
            const feeUsdt = Number((item.rentalFeeNear * nearUsdRate).toFixed(2));
            const colUsdt = Number((item.collateralNear * nearUsdRate).toFixed(2));
            return (
              <article
                key={item.id}
                className="near-glass-card rounded-2xl overflow-hidden flex flex-col justify-between transition-transform duration-150 hover:-translate-y-1"
              >
                <div>
                  <div className="p-3 pb-0">
                    <div className="glass-image-frame aspect-4/3 w-full">
                      <ResilientImage
                        src={item.images?.[0] || item.imageUrl}
                        alt={item.title}
                        resourceType={item.resourceType}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                  <div className="p-4 space-y-2">
                    <div className="flex items-center justify-between gap-2 text-[11px] text-[#9BA8C0]">
                      <span className="font-semibold text-[#00EC97]">
                        {item.resourceType === 'PHYSICAL' ? 'Physical Hardware' : 'Digital Asset'}
                      </span>
                      {item.tinOrSerialNumber && (
                        <span className="font-mono text-[#17F1D1] truncate">
                          ID: {item.tinOrSerialNumber}
                        </span>
                      )}
                    </div>

                    <h3 className="text-sm font-bold font-display text-[#F5F8FF] line-clamp-1">
                      {item.title}
                    </h3>
                    <p className="text-xs text-[#9BA8C0] line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>

                <div className="px-4 pb-4 pt-3 border-t border-slate-800/80 space-y-3">
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-[#9BA8C0] block">Rental Fee</span>
                      <span className="font-mono font-bold text-[#F5F8FF] tabular-nums text-sm inline-flex items-center gap-1 mt-0.5">
                        <NearTokenIcon size={13} />
                        <span>{item.rentalFeeNear} NEAR</span>
                      </span>
                      <span className="font-mono text-[11px] text-[#9BA8C0] block">
                        ≈ ${feeUsdt.toFixed(2)} USDT
                      </span>
                    </div>
                    <div>
                      <span className="text-[#9BA8C0] block">Collateral</span>
                      <span className="font-mono font-bold text-[#00EC97] tabular-nums text-sm inline-flex items-center gap-1 mt-0.5">
                        <NearTokenIcon size={13} />
                        <span>{item.collateralNear} NEAR</span>
                      </span>
                      <span className="font-mono text-[11px] text-[#17F1D1] block">
                        ≈ ${colUsdt.toFixed(2)} USDT
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onOpenListing(item.id)}
                    className="btn-near-secondary w-full py-2 px-4 text-xs"
                  >
                    Borrow Now
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Section 3: Four Concise Security & Escrow Pillars */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-5">
        <div className="border-b border-slate-800 pb-3">
          <p className="text-xs text-[#00EC97] font-mono uppercase">Escrow &amp; Anti-Scam Architecture</p>
          <h2 className="text-xl font-bold font-display text-[#F5F8FF] mt-0.5">
            How BorrowBond Protects Lenders &amp; Borrowers
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="near-glass-card rounded-2xl p-5 space-y-2">
            <Lock className="w-5 h-5 text-[#00EC97]" />
            <h3 className="text-sm font-bold font-display text-[#F5F8FF]">
              01. Locked NEAR Escrow
            </h3>
            <p className="text-xs text-[#9BA8C0] leading-relaxed">
              Holds Rental Fee + 50% Collateral on NEAR Testnet (<code className="font-mono text-[#F5F8FF]">borrowbondtest.testnet</code>). Neither party can touch locked funds during the rental.
            </p>
          </div>

          <div className="near-glass-card rounded-2xl p-5 space-y-2">
            <Fingerprint className="w-5 h-5 text-[#17F1D1]" />
            <h3 className="text-sm font-bold font-display text-[#F5F8FF]">
              02. Anti-Scam Serial Registry
            </h3>
            <p className="text-xs text-[#9BA8C0] leading-relaxed">
              Records Brand, TIN/Serial/IMEI or NFT ID, and 2–10 photo SHA-256 hashes on BorrowBond to block item-swap scammers on return.
            </p>
          </div>

          <div className="near-glass-card rounded-2xl p-5 space-y-2">
            <ShieldCheck className="w-5 h-5 text-[#00EC97]" />
            <h3 className="text-sm font-bold font-display text-[#F5F8FF]">
              03. Dual Handover &amp; Return
            </h3>
            <p className="text-xs text-[#9BA8C0] leading-relaxed">
              Borrower confirms receipt and Lender confirms safe return of the matching TIN/serial before the contract releases payment and collateral.
            </p>
          </div>

          <div className="near-glass-card rounded-2xl p-5 space-y-2">
            <Scale className="w-5 h-5 text-[#FBBF24]" />
            <h3 className="text-sm font-bold font-display text-[#F5F8FF]">
              04. BorrowBond Team Arbitration
            </h3>
            <p className="text-xs text-[#9BA8C0] leading-relaxed">
              If damaged, the BorrowBond Team deducts repair cost + rental fee for the lender and automatically refunds the remaining collateral to the borrower.
            </p>
          </div>
        </div>
      </section>

      {/* Section 4: Compact Interactive Roadmap */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <p className="text-xs text-[#00EC97] font-mono uppercase flex items-center gap-1.5">
              <Milestone className="w-3.5 h-3.5" />
              <span>Roadmap &amp; Whitepaper</span>
            </p>
            <h2 className="text-xl font-bold font-display text-[#F5F8FF] mt-0.5">
              Protocol Roadmap
            </h2>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                if (onOpenDocsSection) onOpenDocsSection('WHITEPAPER');
                else onNavigate('WHITEPAPER');
              }}
              className="btn-near-primary px-4 py-2 text-xs"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Whitepaper</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if (onOpenDocsSection) onOpenDocsSection('DEPLOYMENT');
                else onNavigate('WHITEPAPER');
              }}
              className="btn-near-secondary px-3.5 py-2 text-xs"
            >
              <Rocket className="w-3.5 h-3.5 text-[#00EC97]" />
              <span>Deploy Guide</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {ROADMAP_PHASES.map((phase) => {
            const isLive = phase.status.includes('LIVE');
            return (
              <div
                key={phase.phase}
                onClick={() => {
                  if (onOpenDocsSection) onOpenDocsSection('WHITEPAPER');
                  else onNavigate('WHITEPAPER');
                }}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    if (onOpenDocsSection) onOpenDocsSection('WHITEPAPER');
                    else onNavigate('WHITEPAPER');
                  }
                }}
                className={`rounded-2xl p-4 flex flex-col justify-between space-y-3 transition-all duration-200 hover:-translate-y-1 cursor-pointer ${
                  isLive ? 'near-glow-card' : 'near-glass-card hover:border-[#00EC97]/50'
                }`}
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono font-bold text-[#00EC97]">
                      {phase.phase} • {phase.quarter}
                    </span>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                        isLive ? 'bg-[#00EC97] text-[#04080E]' : 'bg-slate-800 text-[#9BA8C0]'
                      }`}
                    >
                      {phase.status}
                    </span>
                  </div>
                  <h3 className="text-sm font-extrabold font-display text-[#F5F8FF]">
                    {phase.title}
                  </h3>
                  <ul className="space-y-1.5 text-xs text-[#9BA8C0]">
                    {phase.items.map((it) => (
                      <li key={it} className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#00EC97] shrink-0 mt-0.5" />
                        <span>{it}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-[#00EC97]">
                  <span>Read Whitepaper</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Section 5: Short FAQ */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 space-y-4">
        <div className="border-b border-slate-800 pb-3">
          <p className="text-xs text-[#00EC97] font-mono uppercase">Protocol Rules</p>
          <h2 className="text-xl font-bold font-display text-[#F5F8FF] mt-0.5">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="space-y-2.5">
          {faqs.map((faq, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div
                key={faq.q}
                className="near-glass-card rounded-2xl overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                  aria-expanded={isOpen}
                  className="w-full px-5 py-3.5 text-left flex items-center justify-between gap-4 text-xs sm:text-sm font-semibold text-[#F5F8FF] hover:bg-[#141D33]/60 transition-colors cursor-pointer"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#9BA8C0] shrink-0 transition-transform ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-4 text-xs text-[#9BA8C0] leading-relaxed border-t border-slate-800/60 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
