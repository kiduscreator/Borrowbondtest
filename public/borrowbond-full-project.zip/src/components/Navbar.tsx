import React from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  Wallet,
  PlusCircle,
  LayoutGrid,
  Shield,
  Menu,
  Home,
  Sun,
  Moon,
  Monitor,
  BookOpen,
  HelpCircle,
} from 'lucide-react';
import { BorrowBondBrandLogo, NearTokenIcon, UsdtTokenIcon } from './TokenIcons';
import { PWAInstallButton } from './PwaAndOnboardingControls';

export type AppView =
  | 'LANDING'
  | 'MARKETPLACE'
  | 'LISTING_DETAILS'
  | 'CREATE_LISTING'
  | 'AI_AGENT'
  | 'CHECKOUT'
  | 'DASHBOARD'
  | 'TRANSACTION_DETAILS'
  | 'WHITEPAPER';

export type ThemeMode = 'night' | 'day' | 'system';

interface NavbarProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  connectedWallet: string | null;
  nearNetwork?: 'mainnet' | 'testnet';
  userDisplayName?: string;
  userAvatarUrl?: string;
  onOpenWalletModal: () => void;
  onOpenSideMenu?: () => void;
  onOpenBeginnerGuide?: () => void;
  nearUsdRate?: number;
  displayCurrency?: 'NEAR' | 'USDT';
  onToggleCurrency?: (currency: 'NEAR' | 'USDT') => void;
  themeMode?: ThemeMode;
  onChangeThemeMode?: (mode: ThemeMode) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  connectedWallet,
  nearNetwork = 'testnet',
  userDisplayName,
  userAvatarUrl,
  onOpenWalletModal,
  onOpenSideMenu,
  onOpenBeginnerGuide,
  nearUsdRate = 3.7,
  displayCurrency = 'USDT',
  onToggleCurrency,
  themeMode = 'night',
  onChangeThemeMode,
}) => {
  const dockItems: { label: string; shortLabel: string; view: AppView; icon: React.ReactNode }[] = [
    { label: 'Home', shortLabel: 'Home', view: 'LANDING', icon: <Home className="w-[18px] h-[18px]" /> },
    { label: 'Marketplace', shortLabel: 'Market', view: 'MARKETPLACE', icon: <LayoutGrid className="w-[18px] h-[18px]" /> },
    { label: 'AI Agent', shortLabel: 'AI Agent', view: 'AI_AGENT', icon: <Sparkles className="w-[18px] h-[18px]" /> },
    { label: 'List Resource', shortLabel: 'List Item', view: 'CREATE_LISTING', icon: <PlusCircle className="w-[18px] h-[18px]" /> },
    { label: 'Dashboard', shortLabel: 'Dashboard', view: 'DASHBOARD', icon: <Shield className="w-[18px] h-[18px]" /> },
  ];

  // Resolve active index for smooth side-to-side Telegram glass pill animation
  const resolvedActiveIndex = (() => {
    const idx = dockItems.findIndex((i) => i.view === currentView);
    if (idx !== -1) return idx;
    if (currentView === 'LISTING_DETAILS' || currentView === 'CHECKOUT') return 1;
    if (currentView === 'TRANSACTION_DETAILS') return 4;
    return 0;
  })();

  return (
    <>
      {/* Top Luxury Bar: Real BorrowBond Brand Logo + Live 2D NEAR/USDT Ticker + Connect Wallet + 3-Line Menu (☰) */}
      <header className="sticky top-0 z-40 px-3.5 sm:px-6 py-3 bg-[#06080F]/85 backdrop-blur-2xl border-b border-[#00EC97]/20">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-3">
          {/* Zone 1: Brand Wordmark with User's Real BorrowBond Brand Logo */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            type="button"
            onClick={() => onNavigate('LANDING')}
            className="group flex items-center gap-2.5 text-left focus-visible:outline-2 focus-visible:outline-[#00EC97] cursor-pointer shrink-0"
          >
            <BorrowBondBrandLogo size={38} />
            <div>
              <span className="text-base sm:text-lg font-extrabold tracking-tight text-[#F5F8FF] font-display block leading-none">
                BorrowBond
              </span>
              <span className="text-[10px] font-mono text-[#00EC97] tracking-wider uppercase block mt-0.5">
                NEAR {nearNetwork.toUpperCase()} ESCROW
              </span>
            </div>
          </motion.button>

          {/* Zone 2: Live NEAR/USDT Ticker + Whitepaper Quick Button + Theme + Connect Wallet + 3-Line Menu (☰) */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            {/* Live NEAR / USDT Price Pill with Official 2D NEAR & USDT Icons */}
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#0D1322]/90 border border-slate-800 text-xs">
              <span className="inline-flex items-center gap-1.5 font-mono text-[11px] text-[#9BA8C0] whitespace-nowrap">
                <NearTokenIcon size={15} />
                <span>1 NEAR =</span>
                <UsdtTokenIcon size={15} />
                <strong className="text-[#00EC97]">${nearUsdRate.toFixed(2)}</strong>
              </span>

              {onToggleCurrency && (
                <div className="flex items-center bg-[#06080F] rounded-lg p-0.5 border border-slate-800/80 ml-1">
                  <motion.button
                    whileTap={{ scale: 0.94 }}
                    type="button"
                    onClick={() => onToggleCurrency('NEAR')}
                    className={`px-2 py-0.5 text-[11px] font-mono font-bold rounded-md transition-colors flex items-center gap-1 cursor-pointer ${
                      displayCurrency === 'NEAR'
                        ? 'bg-[#00EC97] text-[#04080E]'
                        : 'text-[#9BA8C0] hover:text-[#F5F8FF]'
                    }`}
                  >
                    <NearTokenIcon size={12} />
                    <span>NEAR</span>
                  </motion.button>
                  <motion.button
                    whileTap={{ scale: 0.94 }}
                    type="button"
                    onClick={() => onToggleCurrency('USDT')}
                    className={`px-2 py-0.5 text-[11px] font-mono font-bold rounded-md transition-colors flex items-center gap-1 cursor-pointer ${
                      displayCurrency === 'USDT'
                        ? 'bg-[#26A17B] text-white'
                        : 'text-[#9BA8C0] hover:text-[#F5F8FF]'
                    }`}
                  >
                    <UsdtTokenIcon size={12} />
                    <span>USDT</span>
                  </motion.button>
                </div>
              )}
            </div>

            {/* PWA Install Button (only visible if installable on browser/device) */}
            <PWAInstallButton compact />

            {/* Beginner Wallet & Escrow Explainer Button */}
            {onOpenBeginnerGuide && (
              <motion.button
                whileHover={{ scale: 1.02, y: -1 }}
                whileTap={{ scale: 0.96 }}
                type="button"
                onClick={onOpenBeginnerGuide}
                aria-label="Open beginner guide for NEAR wallets and escrow"
                className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-2 rounded-xl text-xs font-semibold bg-[#0D1322]/90 border border-slate-800 text-[#9BA8C0] hover:text-[#F5F8FF] hover:border-[#00EC97]/50 transition-all cursor-pointer"
              >
                <HelpCircle className="w-3.5 h-3.5 text-[#00EC97]" />
                <span className="hidden xl:inline">How Escrow Works</span>
              </motion.button>
            )}

            {/* Whitepaper & Roadmap Quick Pill */}
            <motion.button
              whileHover={{ scale: 1.02, y: -1 }}
              whileTap={{ scale: 0.96 }}
              type="button"
              onClick={() => onNavigate('WHITEPAPER')}
              className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                currentView === 'WHITEPAPER'
                  ? 'bg-[#00EC97]/20 border-[#00EC97] text-[#00EC97]'
                  : 'bg-[#0D1322]/90 border-slate-800 text-[#9BA8C0] hover:text-[#F5F8FF] hover:border-[#00EC97]/50'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-[#00EC97]" />
              <span>Whitepaper</span>
            </motion.button>

            {/* Theme Quick Cycle (Night / Day / System) */}
            {onChangeThemeMode && (
              <div
                role="group"
                aria-label="Theme Mode"
                className="hidden lg:flex items-center bg-[#0D1322]/90 p-1 rounded-xl border border-slate-800"
              >
                <motion.button
                  whileTap={{ scale: 0.92 }}
                  type="button"
                  onClick={() => onChangeThemeMode('night')}
                  title="Night Mode"
                  aria-label="Night Mode"
                  className={`p-1.5 rounded-lg text-xs cursor-pointer transition-colors ${
                    themeMode === 'night' ? 'bg-[#00EC97] text-[#04080E]' : 'text-[#9BA8C0]'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5" />
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.92 }}
                  type="button"
                  onClick={() => onChangeThemeMode('day')}
                  title="Day Mode"
                  aria-label="Day Mode"
                  className={`p-1.5 rounded-lg text-xs cursor-pointer transition-colors ${
                    themeMode === 'day' ? 'bg-[#00EC97] text-[#04080E]' : 'text-[#9BA8C0]'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5" />
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.92 }}
                  type="button"
                  onClick={() => onChangeThemeMode('system')}
                  title="System Theme"
                  aria-label="System Theme"
                  className={`p-1.5 rounded-lg text-xs cursor-pointer transition-colors ${
                    themeMode === 'system' ? 'bg-[#00EC97] text-[#04080E]' : 'text-[#9BA8C0]'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5" />
                </motion.button>
              </div>
            )}

            {/* Connect Wallet Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              type="button"
              onClick={onOpenWalletModal}
              className="btn-near-primary px-3 sm:px-4 py-2 text-xs whitespace-nowrap shrink-0 max-w-[155px] sm:max-w-none truncate"
            >
              <Wallet className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{connectedWallet ? connectedWallet : 'Connect Wallet'}</span>
            </motion.button>

            {/* 3-Line Dropdown / Menu Button (☰) Next to Wallet Bar */}
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.95 }}
              type="button"
              aria-label="Open Account, Profile & Agreements Menu"
              onClick={onOpenSideMenu}
              className="btn-near-secondary px-2.5 py-2 text-xs flex items-center gap-1.5 shrink-0"
              title="Menu, Profile, Docs, Legal & Socials"
            >
              {userAvatarUrl && (
                <img
                  src={userAvatarUrl}
                  alt={userDisplayName || 'User'}
                  className="w-5 h-5 rounded-full object-cover border border-[#00EC97]/60"
                />
              )}
              <Menu className="w-4 h-4 text-[#00EC97]" />
            </motion.button>
          </div>
        </div>
      </header>

      {/* Telegram-Style Floating Liquid Glass Bottom Dock:
          - Fits 100% inside mobile & desktop frames (`w-[min(94vw,460px)] rounded-full`)
          - Upper Icon + Lower Label structure (`flex-col items-center`)
          - Smooth Framer Motion spring sliding glassy indicator */}
      <nav
        aria-label="Primary Bottom Dock Navigation"
        className="fixed bottom-3 left-1/2 -translate-x-1/2 z-50 w-[min(94vw,460px)] p-1.5 rounded-full liquid-glass-dock select-none"
      >
        <div className="relative grid grid-cols-5 items-center">
          {/* Smooth Side-to-Side Sliding Glassy Pill Indicator */}
          <motion.div
            aria-hidden="true"
            animate={{ x: `${resolvedActiveIndex * 100}%` }}
            transition={{ type: 'spring', stiffness: 420, damping: 32 }}
            className="pointer-events-none absolute top-0 bottom-0 left-0 w-1/5 rounded-full bg-gradient-to-b from-[#00EC97]/28 via-[#17F1D1]/18 to-[#00EC97]/12 border border-[#00EC97]/50 shadow-[0_4px_20px_rgba(0,236,151,0.32),inset_0_1px_1px_rgba(255,255,255,0.4)] backdrop-blur-xl"
          />

          {dockItems.map((item, idx) => {
            const isActive = resolvedActiveIndex === idx;
            return (
              <motion.button
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.92 }}
                key={item.view}
                type="button"
                aria-label={item.label}
                onClick={() => onNavigate(item.view)}
                className={`relative z-10 py-1.5 px-1 rounded-full flex flex-col items-center justify-center gap-0.5 transition-colors duration-200 cursor-pointer ${
                  isActive
                    ? 'text-[#00EC97] font-extrabold'
                    : 'text-[#9BA8C0] hover:text-[#F5F8FF] font-semibold'
                }`}
              >
                <span
                  className={`transition-transform duration-200 ${
                    isActive ? 'scale-110 text-[#00EC97] drop-shadow-[0_0_8px_rgba(0,236,151,0.6)]' : ''
                  }`}
                >
                  {item.icon}
                </span>
                <span className="text-[10px] sm:text-[11px] leading-tight tracking-tight truncate max-w-full">
                  {item.shortLabel}
                </span>
                {/* Screen-reader / Playwright full label */}
                <span className="sr-only">{item.label}</span>
              </motion.button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
